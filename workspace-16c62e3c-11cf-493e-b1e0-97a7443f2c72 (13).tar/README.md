# 🧠 Codebase Brain

> A living, interactive neural-brain visualization that maps your actual codebase to brain anatomy — clusters are brain regions, neurons are files, and synapses are imports. Watch firing pulses travel along import edges in real time.

![Codebase Brain](https://z-cdn.chatglm.cn/z-ai/static/logo.svg)

---

## Table of Contents

1. [Overview](#overview)
2. [Quick Start](#quick-start)
3. [How to Use — Full Walkthrough](#how-to-use--full-walkthrough)
   - [Navigation & Camera](#navigation--camera)
   - [Exploring Neurons (Files)](#exploring-neurons-files)
   - [Search](#search)
   - [Right-Click Radial Menu](#right-click-radial-menu)
   - [Path Finder (Shift-Click)](#path-finder-shift-click)
   - [Cluster Focus & Isolate](#cluster-focus--isolate)
   - [Dependency Matrix](#dependency-matrix)
   - [Recently Changed Panel](#recently-changed-panel)
   - [Code Preview](#code-preview)
   - [Git Heat Map](#git-heat-map)
   - [Region Flow Arrows](#region-flow-arrows)
   - [Orbital Module Nodes](#orbital-module-nodes)
   - [Force-Directed Layout](#force-directed-layout)
   - [Keyboard Navigation](#keyboard-navigation)
   - [Export & Share](#export--share)
   - [Theme Toggle](#theme-toggle)
   - [Audio Feedback](#audio-feedback)
   - [Onboarding Tour](#onboarding-tour)
4. [Keyboard Shortcuts Reference](#keyboard-shortcuts-reference)
5. [Visual Layers Reference](#visual-layers-reference)
6. [Brain Region Map](#brain-region-map)
7. [Architecture](#architecture)
8. [API Reference](#api-reference)
9. [Troubleshooting](#troubleshooting)
10. [Development](#development)

---

## Overview

Codebase Brain scans your project tree in real time and renders it as a living brain on an HTML5 canvas. Each directory maps to a brain region (cluster), each file becomes a glowing neuron, and each `import` statement becomes a synapse connecting them. The brain is alive — neurons pulse, synapses fire with traveling signal pulses, a central particle vortex swirls, and a perspective grid floor grounds the scene in 3D space.

### Key Features

- **Living brain canvas** — particle vortex core, perspective grid floor, film-grain noise, breathing cluster membranes, pulsing neurons with additive bloom
- **Interactive exploration** — click neurons to inspect files, hover to fire synapses, right-click for a radial action menu
- **Path finder** — shift-click two neurons to find the shortest import path between them (animated amber line)
- **Dependency matrix** — heatmap grid of import counts between all cluster pairs
- **Git heat map** — recently-committed files glow brighter; commit sparklines per cluster in the footer
- **Circular dependency detection** — cycles are flagged with pulsing rose rings + ⚠ badges
- **Health score** — a structural integrity gauge factoring in coupling, diversity, and circular deps
- **Audio feedback** — synthesized sounds for selection, focus, trace, and ambient firing
- **Light/dark theme** — full light palette with CSS variable overrides
- **Onboarding tour** — 7-step first-visit guided walkthrough
- **Export PNG + shareable links** — download screenshots or copy deep links to neurons

---

## Quick Start

```bash
# Install dependencies
bun install

# Start the dev server
bun run dev

# Open http://localhost:3000
```

The app runs on **port 3000**. The first load compiles the codebase scan (~5 seconds), then the brain renders at 60fps.

### Prerequisites

- [Node.js](https://nodejs.org/) 18+ or [Bun](https://bun.sh/) runtime
- A modern browser with Canvas 2D + Web Audio API support

### Environment

No environment variables are required. The app scans the project tree at `<project-root>/src/`, `prisma/`, and `mini-services/` automatically via the `/api/codebase` endpoint. Git history is read via `git log` (optional — the app works without git, just without the heat map and commit sparklines).

---

## How to Use — Full Walkthrough

### Navigation & Camera

| Action | Input | Result |
|--------|-------|--------|
| **Pan** | Drag on empty canvas space | Moves the brain in any direction |
| **Zoom** | Mouse wheel | Zooms toward the cursor position (0.5×–2.8×) |
| **Reset view** | `R` key or "Reset view" button | Returns to default position + zoom |
| **Parallax** | Move mouse around | Subtle depth shift (toggleable via `P`) |

The camera animates smoothly when focusing clusters or neurons — it eases pan + zoom over ~0.3 seconds.

A **mini-map** appears in the bottom-right corner when you've panned or zoomed away from the default view. It shows the whole brain overview with a white rectangle indicating the currently visible region. Click the mini-map to reset the view.

### Exploring Neurons (Files)

1. **Hover** any neuron → its connected synapses highlight bright + the cursor changes to a pointer. A tooltip appears showing the file name, path, LOC, and cluster.
2. **Click** a neuron → it becomes selected (white selection ring + expanding shockwave). The **InfoPanel** slides in from the right showing:
   - File name + full path
   - Cluster label with color dot
   - LOC, Imports, Used-by stats
   - Kind badge (component, hook, api, etc.)
   - Circular dependency badge (⚠ if part of a cycle)
   - Last git commit timestamp (relative, e.g. "2h ago")
   - Last modified on disk (relative)
   - **Code Preview** — syntax-highlighted first ~200 lines with line numbers + copy button
   - Outgoing synapses list (clickable — navigates to the target neuron)
   - Incoming synapses list (clickable)
   - Cluster anatomy description
3. **Click empty space** → deselects the neuron. If you click inside a cluster's empty area, it focuses that cluster.

### Search

Type in the search box (or press `/` to focus it) to find neurons by file name:

- **Matching neurons** get a white pulsing ring
- **Non-matching neurons** dim to ~18% opacity
- **Synapses between two matching neurons** light up as bright "spotlight" pathways
- Clear the search with the `X` button or by pressing `Esc`

### Right-Click Radial Menu

Right-click any neuron to open a **radial pie menu** with 4 actions:

| Action | Icon | Description |
|--------|------|-------------|
| **Focus** | 🎯 | Animates the camera to center this neuron at 2× zoom |
| **Trace** | ⚡ | Fires an "electrical storm" — all the neuron's synapses fire intensely for 3.5 seconds (brighter, faster pulses with extra glow) |
| **Isolate** | 📑 | Hides all other clusters + focuses this neuron's cluster |
| **Copy path** | 📋 | Copies the file's relative path to the clipboard |

The radial menu closes on outside-click, `Esc`, or action selection.

### Path Finder (Shift-Click)

Find the shortest import path between two files:

1. **Click** a neuron to select it as the **source**
2. **Shift-click** another neuron to set it as the **target**
3. The BFS algorithm finds the shortest directed import path (source → target)
4. The path renders as an **animated amber polyline** with a traveling bright dot
5. Path neurons get amber rings
6. A toast confirms: "Path found: N hops"

If no import path exists, a toast shows "No import path found" and the endpoint clears after 600ms.

Shift-click the same neuron again to toggle the endpoint off.

### Cluster Focus & Isolate

- **Click a cluster's empty area** → focuses that cluster (camera animates to center it at ~42% viewport fill). The breadcrumb in the header updates: `🏠 Codebase Brain › 🟢 Visual Cortex ✕`
- **Click a cluster's focus button** (🎯 icon, appears on hover in the ControlPanel region list) → same as above
- **Click an orbital chip** (the 7 chips orbiting the vortex core) → focuses that cluster
- **Isolate** (via radial menu or matrix header click) → hides all other clusters + focuses this one
- **Exit focus** → click the Home button in the breadcrumb, press `Esc`, or click `R`

### Dependency Matrix

Press `M` or click the "Matrix" button in the top-right toolbar to open a **heatmap grid** of import counts between all cluster pairs:

- **Rows** = importing cluster (source)
- **Columns** = imported cluster (target)
- **Cell color intensity** ∝ import count / max count
- **Diagonal** is hidden (same-cluster imports)
- **Hover** a cell → tooltip shows "Source → Target: N"
- **Click a cell** → highlights all corresponding cross-cluster synapses on the brain canvas (bright amber lines)
- **Click a row/column header** → isolates that cluster (hides all others + focuses camera)
- Click the same cell again to toggle the filter off

### Recently Changed Panel

Click the "Recent" button in the top-right toolbar to open a **slide-in panel** (bottom-right) listing the top 12 most-recently-committed files:

- Each row shows: colored heat dot (cluster color, glow ∝ recency), file name, Clock icon, relative time ("now", "1h", "2d")
- Click a row to select that neuron on the brain
- Requires git history (if unavailable, shows "no git history available")

### Code Preview

When a neuron is selected, the InfoPanel includes a collapsible **Code Preview** section:

- Shows the first ~200 lines of the actual file content
- Syntax-highlighted using Prism (oneDark theme)
- Line numbers on the left
- Copy-code button (top-right of the preview)
- Truncation indicator (⌧) if the file exceeds 64 KB
- Header shows `lines/totalLines` count
- Loading spinner while fetching, error message if the file can't be read

The preview is fetched from `/api/file?path=...` which enforces path-traversal protection (blocks `..`, null bytes, non-allowlisted paths like `.env`).

### Git Heat Map

Toggle "Git Heat" (`G` key) to enable the **git recency heat map**:

- Recently-committed files glow brighter (larger glow radius, higher alpha)
- Files committed within the last 30 days get a **white-hot core** lerp (additive bloom)
- Heat decays exponentially: files from today glow bright white, files from 2 weeks ago glow dimly, old files have no extra glow
- The footer shows **per-cluster commit sparklines** — 8 vertical bars per cluster representing commit frequency over the last 30 days (colored by cluster color, height ∝ count)
- Falls back gracefully if git isn't available (no heat, no sparklines)

### Region Flow Arrows

Toggle "Region Flow" (`V` key) to draw **thick animated arrows** between cluster centers:

- Arrow width ∝ aggregate import count between the two clusters
- Gradient stroke (source cluster color → target cluster color)
- Animated dashes flowing toward the target (additive bloom)
- Arrowheads at the target end
- Only shows cross-cluster synapses (same-cluster imports excluded)

### Orbital Module Nodes

Toggle "Orbital" (`O` key) to render **7 circular icon chips** orbiting the vortex core:

- Each chip represents a brain region (labeled: App, API, Lib, UI, Hooks, Database, Config)
- Chips rotate slowly around the center (0.08 rad/s)
- Each chip is connected to the core by a faint curved Bézier "gravity" edge
- **Click a chip** → focuses that cluster (same as clicking a cluster's empty area)
- A faint dashed orbit guide ring shows the orbital path

### Force-Directed Layout

Toggle "Force Layout" (on by default) to use a **Barnes-Hut force simulation** for the focused cluster's neurons:

- **Repulsion** between all neuron pairs (prevents overlap)
- **Spring attraction** along synapse edges (pulls connected neurons together)
- **Centering force** keeps neurons within the cluster radius
- The transition from Fibonacci spiral → force-directed is **animated over ~1 second** with ease-in-out cubic interpolation (neurons smoothly morph to their new positions)
- When force layout is off, neurons use the default Fibonacci spiral packing
- Best seen when focusing a large cluster (e.g., Visual Cortex with 49 neurons)

### Keyboard Navigation

When a neuron is selected, use **arrow keys** (↑↓←→) to navigate between connected neurons:

- The system finds the nearest connected neuron (via synapse edges) in the given direction using cosine similarity (dot product / distance)
- A **cyan dashed arrow** draws briefly from the old neuron to the new one (additive blend, decays over ~0.4s)
- Each navigation fires a "select" sound if audio is enabled
- Allows traversing the entire import graph purely with the keyboard

### Export & Share

The top-right toolbar has 4 action buttons:

| Button | Description |
|--------|-------------|
| **Export** | Downloads the current canvas view as a PNG file (`codebase-brain-<timestamp>.png`). Composites over a dark background so transparent areas look correct. Toast confirms dimensions. |
| **Share** | Copies a URL with `?n=<path>` query param to the clipboard. When someone opens that URL, the app auto-selects that neuron + shows a "Loaded from share link" toast. |
| **Recent** | Toggles the Recently Changed panel. |
| **Matrix** | Toggles the Dependency Matrix modal. |

### Theme Toggle

Click the **Sun/Moon** button in the top-right toolbar to switch between dark and light mode:

- **Dark mode** (default): deep space void background, white text, dark glassmorphic panels
- **Light mode**: soft lavender background, dark text, light glassmorphic panels
- The canvas rendering itself stays dark in both modes (it's a space void)
- Choice is persisted in localStorage (`codebase-brain:theme:v1`)

### Audio Feedback

Toggle "Audio" in the ControlPanel to enable **synthesized sound feedback** (uses Web Audio API — no audio files needed):

| Sound | Trigger | Description |
|-------|---------|-------------|
| **Select** | Click a neuron | Rising two-tone triangle chime (660→990Hz) |
| **Whoosh** | Focus a cluster | Filtered noise sweep (bandpass 1200→300Hz) |
| **Trace** | Start trace mode | Electrical buzz (sawtooth 120Hz + 18Hz vibrato) |
| **Isolate** | Isolate a cluster | Low thump (sine 100→50Hz) |
| **Click** | Ambient pulse spawns | Short sine blip (880→440Hz) — creates a subtle background rhythm |

Audio is off by default (browsers block autoplay). The AudioContext is lazily created on first user interaction. Master volume is 0.15 (subtle).

### Onboarding Tour

On first visit, a **7-step guided tour** appears:

1. Welcome to Codebase Brain
2. Find any file (search)
3. Click to explore (selection + radial menu)
4. Trace & path-find (shift-click)
5. Dependency matrix (M key)
6. Keyboard shortcuts
7. You're all set

Features:
- Animated progress bar (violet→fuchsia gradient)
- Clickable step dots (jump to any step)
- Back/Next/Skip navigation
- localStorage persistence — only shows once
- **Replay** via the ShortcutsHint dialog → "Replay onboarding tour" button

---

## Keyboard Shortcuts Reference

| Key | Action |
|-----|--------|
| `/` | Focus the search input |
| `↑` `↓` `←` `→` | Navigate between connected neurons |
| `R` | Reset view (clear search, unhide clusters, reset camera) |
| `F` | Toggle ambient firing pulses |
| `S` | Toggle synapse edges |
| `L` | Toggle cluster labels |
| `P` | Toggle mouse parallax |
| `G` | Toggle git heat map |
| `O` | Toggle orbital module chips |
| `V` | Toggle region flow arrows |
| `M` | Toggle dependency matrix |
| `Esc` | Deselect neuron / exit cluster focus / close dialog |
| `Shift+Click` | Set path-finder endpoint |
| `Right-Click` | Open radial context menu |
| `Scroll` | Zoom toward cursor |
| `Drag` (empty space) | Pan the camera |

Click the **Shortcuts** button (bottom-left) to open the full shortcuts reference dialog at any time.

---

## Visual Layers Reference

The brain is rendered on a single HTML5 canvas with ~15 layered draw passes:

| # | Layer | Description |
|---|-------|-------------|
| 1 | **Background gradient** | Deep-space radial gradient (#0d0826 → #02010a) |
| 2 | **Stars** (320) | Twinkling parallax-depth stars with sparkle crosses |
| 3 | **Nebulae** (5) | Drifting colored radial-gradient clouds |
| 4 | **Perspective grid** | Cyan wave-distorted horizon floor with converging lines |
| 5 | **Brain silhouette** | Organic wobbly ellipse outline with glow + central fissure |
| 6 | **Vortex core** (2800 particles) | 3-arm galaxy spiral with additive bloom + white-hot nucleus |
| 7 | **Clusters** (7) | Breathing organic membranes with halos + inner fill |
| 8 | **Region flow** (optional) | Thick animated arrows between cluster centers |
| 9 | **Synapses** | Gradient quadratic-curve edges (highlighted on hover/select) |
| 10 | **Path highlight** (optional) | Amber polyline + traveling dot for path-finder |
| 11 | **Neuron glows** | Additive-blend radial gradient halos (+ git heat white-hot cores) |
| 12 | **Neuron cores** | Solid colored circles with white highlight + selection/circular/path rings |
| 13 | **Firing pulses** | Traveling signal trails (ambient + hover + trace modes) |
| 14 | **Shockwaves** | Expanding rings on neuron selection |
| 15 | **Nav arrow** | Cyan dashed directional indicator on arrow-key navigation |
| 16 | **Orbital chips** (optional) | 7 circular icon nodes orbiting the vortex |
| 17 | **Cluster labels** | Region names + domain subtitles |
| 18 | **Neuron labels** | File names (semantic zoom: visible when zoom > 1.4×) |
| 19 | **Vignette** | Radial darkening at screen edges |
| 20 | **Activation flash** | Brief white-magenta bloom on focus/trace/select events |
| 21 | **Film-grain noise** | 128×128 tiled noise overlay (drifts slowly) |

---

## Brain Region Map

Each codebase directory maps to a brain region:

| Brain Region | Domain | Color | Directory |
|-------------|--------|-------|-----------|
| **Prefrontal Cortex** | App Pages | Violet `#a855f7` | `src/app/` (pages) |
| **Motor Cortex** | API Routes | Cyan `#22d3ee` | `src/app/api/` |
| **Frontal Lobe** | Lib & Utils | Fuchsia `#d946ef` | `src/lib/` |
| **Visual Cortex** | UI Components | Emerald `#34d399` | `src/components/` |
| **Parietal Lobe** | Hooks | Rose `#fb7185` | `src/hooks/` |
| **Temporal Lobe** | Database & Schema | Amber `#fbbf24` | `prisma/` |
| **Cerebellum** | Config & Tooling | Light-violet `#c084fc` | Root config files |

Cluster positions are determined by normalized anchors inside the brain silhouette. Neurons within each cluster are spread via a Fibonacci (golden-angle) spiral by default, or a force-directed simulation when focused + Force Layout is enabled.

---

## Architecture

```
src/
├── app/
│   ├── api/
│   │   ├── codebase/route.ts    # GET /api/codebase — scans project tree, returns NeuralGraph
│   │   └── file/route.ts        # GET /api/file?path=... — returns file preview (safe, truncated)
│   ├── layout.tsx                # Root layout with Providers + Toaster
│   ├── page.tsx                  # Main page — composes all brain components + state management
│   └── globals.css               # Tailwind + dark/light theme variables
├── components/
│   ├── brain/
│   │   ├── BrainCanvas.tsx       # Core canvas renderer (~2000 lines, 20+ draw passes)
│   │   ├── BrainFooter.tsx       # Sticky footer: stats, health gauge, sparklines, commit bars
│   │   ├── BrainHeader.tsx      # Centered pill header with breadcrumb navigation
│   │   ├── CodePreview.tsx      # Syntax-highlighted file preview (Prism + oneDark)
│   │   ├── ControlPanel.tsx     # Left sidebar: search, 10 toggles, cluster list with LOC bars
│   │   ├── DependencyMatrix.tsx # Heatmap modal of cross-cluster import counts
│   │   ├── ExportShare.tsx      # Top-right toolbar: Export PNG, Share link, Recent, Matrix, Theme
│   │   ├── HoverTooltip.tsx     # Floating tooltip following cursor on neuron hover
│   │   ├── InfoPanel.tsx        # Right panel: file details, code preview, synapse lists
│   │   ├── MiniMap.tsx          # Bottom-right overview with viewport rectangle
│   │   ├── OnboardingTour.tsx   # 7-step first-visit guided walkthrough
│   │   ├── RadialMenu.tsx       # Right-click pie menu (Focus, Trace, Isolate, Copy)
│   │   ├── RecentlyChanged.tsx  # Bottom-right panel: top 12 recently-committed files
│   │   ├── ShortcutsHint.tsx    # Bottom-left button + shortcuts dialog + replay tour
│   │   ├── ThemeToggle.tsx      # Sun/Moon theme switcher with localStorage
│   │   └── types.ts             # Shared TypeScript types (NeuralGraph, Neuron, Synapse, etc.)
│   └── providers.tsx             # TanStack Query provider
├── hooks/
│   ├── use-audio.ts              # Web Audio API synthesizer (5 sound types)
│   ├── use-file-preview.ts       # Fetch hook for /api/file with React state pattern
│   ├── use-mobile.ts             # Mobile detection hook
│   └── use-toast.ts              # Toast hook (shadcn/ui)
├── lib/
│   └── brain/
│       ├── anatomy.ts           # Brain region → codebase directory mapping (7 clusters)
│       ├── graph.ts             # Filesystem scanner + import resolver + circular detection + git
│       ├── layout.ts            # Fibonacci spiral + force-directed layout engine
│       └── pathfind.ts          # BFS shortest-path finder over the synapse graph
└── prisma/
    └── schema.prisma            # Prisma schema (SQLite)
```

### Data Flow

```
Filesystem → /api/codebase → buildNeuralGraph()
  ├── walk() — recursively scan src/, prisma/, mini-services/
  ├── resolveImport() — resolve @/ aliases + relative imports to absolute paths
  ├── detectCircular() — DFS with WHITE/GRAY/BLACK coloring
  └── fetchGitActivity() — git log --name-only --format=%aI

→ NeuralGraph JSON → React Query → BrainCanvas (canvas render loop)
                                   → ControlPanel (toggles, cluster list)
                                   → InfoPanel (file details, code preview)
                                   → BrainFooter (stats, sparklines)
                                   → DependencyMatrix (heatmap)
                                   → RecentlyChanged (git panel)
```

### Performance Optimizations

- **Viewport culling** — offscreen neurons and synapses are skipped (except hovered/selected/path-highlighted)
- **rAF throttling** — when the tab is hidden, rendering drops to ~2fps (saves CPU)
- **DPR capping** — device pixel ratio capped at 2 (prevents excessive pixel count on high-DPI displays)
- **Stable animation loop** — created once via useCallback + renderRef pattern (never restarts)
- **Props mirrored via refs** — ctxRef.current updated in useEffect so the render loop reads latest values without re-creating
- **Pre-computed noise tile** — 128×128 film-grain noise canvas generated once, tiled each frame

---

## API Reference

### `GET /api/codebase`

Scans the project tree and returns the full neural graph.

**Response:**
```json
{
  "clusters": [
    { "id": "prefrontal", "label": "Prefrontal Cortex", "domain": "App Pages", "color": "#a855f7", "anatomy": "...", "anchor": { "x": 0.5, "y": 0.26 }, "weight": 1.15 }
  ],
  "neurons": [
    { "id": "src/app/page.tsx", "path": "src/app/page.tsx", "name": "page.tsx", "cluster": "prefrontal", "loc": 300, "imports": 5, "importedBy": 0, "kind": "page", "lastCommit": "2026-09-10T16:00:00Z", "circular": false }
  ],
  "synapses": [
    { "source": 0, "target": 5, "weight": 1 }
  ],
  "stats": { "files": 73, "edges": 68, "clusters": 7, "avgDegree": 0.93, "circularCount": 0 }
}
```

### `GET /api/file?path=<relative-path>`

Returns a truncated preview of a file's content.

**Security:**
- Path traversal (`..`) → 400
- Non-allowlisted paths (`.env`, etc.) → 403
- Allowed prefixes: `src/`, `prisma/`, `mini-services/`
- Allowed root files: `next.config.ts`, `package.json`, `tsconfig.json`, etc.
- Truncated to 64 KB / 200 lines

**Response:**
```json
{
  "path": "src/app/page.tsx",
  "language": "tsx",
  "content": "\"use client\";\n...",
  "lines": 200,
  "totalLines": 300,
  "bytes": 12000,
  "truncated": false,
  "mtime": "2026-09-10T16:00:00.000Z"
}
```

---

## Troubleshooting

### The brain canvas is blank / not rendering

**Possible causes:**

1. **Dev server not running** — Ensure `bun run dev` is running and `http://localhost:3000` returns HTTP 200.
2. **API error** — Check `/api/codebase` returns JSON (not an error). If the project has no `src/` directory, the graph will be empty but clusters will still render.
3. **JavaScript error** — Open the browser console (F12 → Console). Look for red errors. Common fixes:
   - Clear the browser cache (Ctrl+Shift+R for hard reload)
   - Delete `.next/` directory and restart: `rm -rf .next && bun run dev`
4. **Canvas context not available** — Ensure your browser supports Canvas 2D (all modern browsers do).
5. **Scoping bug** — If you see `ReferenceError: isVisible is not defined` in the console, ensure the `isVisible` helper is defined at the render-function scope (not inside a draw helper).

### The page loads but shows "Failed to scan codebase"

This means `/api/codebase` returned an error. Check:

1. The project root is correct (the API uses `process.cwd()`)
2. The `src/` directory exists and contains files
3. File permissions allow reading
4. Check the server terminal for the error stack trace

### Git heat map / commit sparklines not showing

The git heat map requires git history. Verify:

```bash
git log --name-only --format=%aI --no-renames --diff-filter=AM | head -5
```

If this returns nothing, the repo has no commits. The app gracefully falls back (no heat, no sparklines) — this is expected behavior, not a bug.

If you see commit data in `git log` but sparklines don't appear:
- The sparklines only show on **large screens** (lg breakpoint, ≥1024px)
- The sparklines only render when `maxCommit > 0` (at least one commit in the last 30 days)

### Circular dependency count is 0

This is correct for a healthy codebase! Circular dependencies are detected via DFS with WHITE/GRAY/BACK coloring. If you believe there should be cycles, verify:

1. The imports are between files in the scanned directories (`src/`, `prisma/`, `mini-services/`)
2. The imports use `@/` aliases or relative paths (bare module imports like `react` are not resolved)
3. The cycle is within the scanned files (not through node_modules)

### Audio doesn't play

Audio is **off by default** — toggle the "Audio" switch in the ControlPanel. If it's on but you don't hear anything:

1. **Browser autoplay policy** — The AudioContext is created lazily on first user interaction. Click somewhere on the page first, then try selecting a neuron.
2. **System volume** — Check your OS volume + browser tab volume (right-click the tab → Unmute).
3. **AudioContext suspended** — Open the browser console and check `audioContext.state`. If "suspended", call `audioContext.resume()` or interact with the page more.
4. **No ambient firing** — If the "Firing" toggle is off, no ambient pulses spawn, so no ambient sounds. Toggle "Firing" on.

### Light mode doesn't look right

Light mode uses CSS variable overrides + targeted selectors for hardcoded dark colors. If some elements still appear dark:

1. Hard-refresh the page (Ctrl+Shift+R) — the CSS may be cached
2. Check that `<html>` has the `light` class (inspect element → `<html class="light">`)
3. The **canvas** intentionally stays dark in light mode (it's a space void). This is by design.
4. If panels still have dark backgrounds, the targeted CSS override may be missing for that specific class. Check `globals.css` under `html.light` and add the needed override.

### Onboarding tour keeps showing

The tour shows once per browser (stored in localStorage). If it keeps appearing:

1. Check localStorage: `localStorage.getItem("codebase-brain:onboarded:v1")` — should return `"1"`
2. If null, the key was cleared (incognito mode, localStorage disabled, etc.)
3. To manually dismiss: `localStorage.setItem("codebase-brain:onboarded:v1", "1")` + refresh

### Performance is slow / frame rate is low

1. **Close other tabs** — the dev server (Turbopack) is memory-intensive
2. **Reduce layers** — toggle off Firing, Region Flow, Orbital, Git Heat to reduce per-frame draw calls
3. **Zoom in** — viewport culling kicks in when zoomed, skipping offscreen neurons/synapses
4. **Check DPR** — on high-DPI displays, the canvas may be rendering at 2× resolution. The DPR is capped at 2 but can still be heavy on 4K displays
5. **Background tab throttling** — when you switch away from the tab, rendering drops to ~2fps automatically
6. **Dev server OOM** — if the Next.js dev server crashes (Turbopack OOM), restart with `bun run dev`. This is a known sandbox memory issue, not a code bug.

### The dependency matrix shows all zeros

This means there are no cross-cluster imports. Verify:

1. Files in different clusters actually import each other (e.g., `src/app/page.tsx` importing from `src/components/`)
2. The imports use resolvable paths (`@/` aliases or relative paths)
3. The diagonal is intentionally hidden (same-cluster imports)

### Share link doesn't auto-select

The `?n=<path>` share link auto-selects on page load. If it doesn't work:

1. Verify the URL contains `?n=` (e.g., `http://localhost:3000/?n=src/app/page.tsx`)
2. The path must match a neuron's `path` field exactly (case-sensitive, forward slashes)
3. The auto-select only runs once (when the graph first loads). If a neuron was already selected, it won't override

### Export PNG downloads a black image

This can happen if the canvas hasn't rendered yet. Ensure:

1. The brain is visible on screen before clicking Export
2. Wait for the initial compilation (~5 seconds on first load)
3. The Export function composites the canvas over a dark background — the result should show the brain, not pure black

---

## Development

### Commands

```bash
bun run dev        # Start dev server on port 3000
bun run lint       # Run ESLint
bun run db:push    # Push Prisma schema to SQLite
bun run db:generate # Generate Prisma client
bun run build      # Production build
```

### Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 16 (App Router, Turbopack) |
| Language | TypeScript 5 |
| Styling | Tailwind CSS 4 + shadcn/ui (New York) |
| Canvas | Native HTML5 Canvas 2D |
| State | React Query (server) + useState/useRef (client) |
| Animation | Framer Motion (UI) + requestAnimationFrame (canvas) |
| Audio | Web Audio API (native, no files) |
| Icons | Lucide React |
| Syntax | react-syntax-highlighter (Prism + oneDark) |
| Toasts | Sonner |
| ORM | Prisma (SQLite) |

### Adding a New Brain Region

1. Edit `src/lib/brain/anatomy.ts`
2. Add a new entry to the `CLUSTERS` array with `id`, `label`, `domain`, `color`, `anatomy`, `anchor` (0..1 x/y), and `weight`
3. Add a classification rule in `classifyFile()` for the directory pattern
4. The brain will automatically render the new region on next load

### Code Style

- **Refs over re-renders** — the BrainCanvas uses a `ctxRef` pattern to mirror props into a ref (updated in useEffect) so the stable render callback always reads latest values without restarting the animation loop
- **No setState in effects** — uses lazy `useState` initializers or the "adjust state during render" pattern to satisfy ESLint's `react-hooks/set-state-in-effect` rule
- **Destructured props** — ControlPanel/InfoPanel props are destructured (not accessed via `props.*`) to satisfy ESLint's `react-hooks/refs` rule
- **Inner closures for draw helpers** — all draw functions are declared inside the `render` callback to avoid "accessed before declared" lint errors and to close over current values

---

*Codebase Brain — built with Next.js 16, TypeScript, Tailwind CSS, shadcn/ui, and the Web Audio API. No external visualization libraries — everything is hand-rendered on HTML5 Canvas.*
