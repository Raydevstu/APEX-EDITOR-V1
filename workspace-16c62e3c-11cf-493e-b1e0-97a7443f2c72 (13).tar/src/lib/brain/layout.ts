import type { BrainLayout, NeuralGraph } from "@/components/brain/types";

/**
 * Deterministic PRNG (mulberry32) so layout is stable across renders.
 */
function mulberry32(seed: number) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/**
 * Compute pixel positions for clusters and neurons inside a brain silhouette.
 *
 * The brain is drawn into a `width` x `height` canvas. The silhouette occupies
 * a centered ellipse ~ 0.86w x 0.78h. Each cluster gets a center computed from
 * its normalized anchor and a radius derived from its weight and the number of
 * neurons it owns. Neurons are spread around the cluster center using a
 * sunflower / Fibonacci spiral for organic packing.
 */
export function computeLayout(
  graph: NeuralGraph,
  width: number,
  height: number
): BrainLayout {
  const cx = width / 2;
  const cy = height / 2;
  const brainW = width * 0.86;
  const brainH = height * 0.78;
  const rx = brainW / 2;
  const ry = brainH / 2;

  // Count neurons per cluster (excluding virtual placeholders).
  const counts: Record<string, number> = {};
  for (const n of graph.neurons) {
    if (n.kind === "virtual") continue;
    counts[n.cluster] = (counts[n.cluster] ?? 0) + 1;
  }

  // Cluster centers in canvas space.
  const centers: BrainLayout["centers"] = {};
  for (const c of graph.clusters) {
    const ax = c.anchor.x;
    const ay = c.anchor.y;
    // anchor (0.5, 0.5) -> brain center; offset (0.5, 0) -> right edge of brain.
    const x = cx + (ax - 0.5) * 2 * rx * 0.86;
    const y = cy + (ay - 0.5) * 2 * ry * 0.86;
    const n = counts[c.id] ?? 0;
    // radius scales with sqrt(neuron count) and the cluster's weight.
    const r = Math.max(38, Math.min(130, 28 + Math.sqrt(n + 1) * 14 * c.weight));
    centers[c.id] = { x, y, r };
  }

  // Neuron positions via Fibonacci spiral inside each cluster.
  const neurons: BrainLayout["neurons"] = new Array(graph.neurons.length);
  // group indices by cluster
  const byCluster: Record<string, number[]> = {};
  graph.neurons.forEach((n, i) => {
    (byCluster[n.cluster] ??= []).push(i);
  });
  for (const c of graph.clusters) {
    const idxs = byCluster[c.id] ?? [];
    const center = centers[c.id];
    if (!center) continue;
    const real = idxs.filter((i) => graph.neurons[i].kind !== "virtual");
    real.sort((a, b) => {
      // push high-degree neurons toward the center of the cluster
      const da = graph.neurons[a].imports + graph.neurons[a].importedBy;
      const db = graph.neurons[b].imports + graph.neurons[b].importedBy;
      return db - da;
    });
    const golden = Math.PI * (3 - Math.sqrt(5));
    real.forEach((idx, k) => {
      const t = real.length === 1 ? 0.5 : k / (real.length - 1 || 1);
      // radius from 0.15 .. 0.95 of cluster radius
      const radius = center.r * (0.18 + 0.78 * Math.sqrt(t));
      const angle = k * golden;
      const jitter = (mulberry32(hashStr(graph.neurons[idx].id))() - 0.5) * 0.4;
      const x = center.x + Math.cos(angle + jitter) * radius;
      const y = center.y + Math.sin(angle + jitter) * radius;
      const deg = graph.neurons[idx].imports + graph.neurons[idx].importedBy;
      const nr = 2 + Math.min(4, deg * 0.45);
      const phase = mulberry32(hashStr(graph.neurons[idx].id + "phase"))() * Math.PI * 2;
      neurons[idx] = { x, y, r: nr, phase };
    });
    // virtual neurons: place quietly at cluster center with tiny radius
    for (const idx of idxs) {
      if (!neurons[idx]) {
        neurons[idx] = { x: center.x, y: center.y, r: 0.5, phase: 0 };
      }
    }
  }

  return {
    centers,
    neurons,
    synapses: graph.synapses,
  };
}

/** Returns true if a point (px,py) is inside the brain silhouette ellipse. */
export function isInsideBrain(
  px: number,
  py: number,
  width: number,
  height: number
): boolean {
  const cx = width / 2;
  const cy = height / 2;
  const rx = (width * 0.86) / 2;
  const ry = (height * 0.78) / 2;
  const nx = (px - cx) / rx;
  const ny = (py - cy) / ry;
  return nx * nx + ny * ny <= 1;
}

/**
 * Compute a force-directed sub-graph layout for a single cluster's neurons.
 * Runs a simplified Barnes-Hut simulation: repulsion between all neuron pairs,
 * spring attraction along synapses, and a mild centering force. Returns new
 * positions that can replace the Fibonacci-spiral positions for the focused
 * cluster, making intra-cluster imports more legible.
 *
 * @param graph The full neural graph
 * @param clusterId The cluster to re-layout
 * @param baseLayout The existing layout (used for cluster center + radius)
 * @param iterations Number of simulation steps (default 80)
 */
export function computeForceDirectedLayout(
  graph: NeuralGraph,
  clusterId: string,
  baseLayout: BrainLayout,
  iterations = 80
): { x: number; y: number }[] {
  const center = baseLayout.centers[clusterId];
  if (!center) return [];

  // Collect neuron indices belonging to this cluster
  const indices: number[] = [];
  for (let i = 0; i < graph.neurons.length; i++) {
    if (graph.neurons[i].cluster === clusterId && graph.neurons[i].kind !== "virtual") {
      indices.push(i);
    }
  }
  if (indices.length === 0) return [];

  // Initialize positions from the base layout (Fibonacci spiral)
  const positions = indices.map((idx) => {
    const n = baseLayout.neurons[idx];
    return { x: n?.x ?? center.x, y: n?.y ?? center.y };
  });

  // Collect intra-cluster synapses (both endpoints in this cluster)
  const edges: [number, number][] = [];
  for (const s of graph.synapses) {
    const na = graph.neurons[s.source];
    const nb = graph.neurons[s.target];
    if (na?.cluster === clusterId && nb?.cluster === clusterId) {
      const li = indices.indexOf(s.source);
      const ri = indices.indexOf(s.target);
      if (li >= 0 && ri >= 0) edges.push([li, ri]);
    }
  }

  // Simulation parameters
  const repulsionK = center.r * center.r * 0.8;
  const springK = 0.02;
  const springLen = center.r * 0.35;
  const centeringK = 0.008;
  const damping = 0.85;

  const vel = positions.map(() => ({ x: 0, y: 0 }));

  for (let iter = 0; iter < iterations; iter++) {
    const forces = positions.map(() => ({ x: 0, y: 0 }));

    // Repulsion between all pairs
    for (let i = 0; i < positions.length; i++) {
      for (let j = i + 1; j < positions.length; j++) {
        const dx = positions[i].x - positions[j].x;
        const dy = positions[i].y - positions[j].y;
        const d2 = dx * dx + dy * dy + 0.01;
        const d = Math.sqrt(d2);
        const f = repulsionK / d2;
        const fx = (dx / d) * f;
        const fy = (dy / d) * f;
        forces[i].x += fx;
        forces[i].y += fy;
        forces[j].x -= fx;
        forces[j].y -= fy;
      }
    }

    // Spring attraction along edges
    for (const [a, b] of edges) {
      const dx = positions[b].x - positions[a].x;
      const dy = positions[b].y - positions[a].y;
      const d = Math.sqrt(dx * dx + dy * dy) + 0.01;
      const f = springK * (d - springLen);
      const fx = (dx / d) * f;
      const fy = (dy / d) * f;
      forces[a].x += fx;
      forces[a].y += fy;
      forces[b].x -= fx;
      forces[b].y -= fy;
    }

    // Centering force + apply velocity
    for (let i = 0; i < positions.length; i++) {
      forces[i].x += (center.x - positions[i].x) * centeringK;
      forces[i].y += (center.y - positions[i].y) * centeringK;
      vel[i].x = (vel[i].x + forces[i].x) * damping;
      vel[i].y = (vel[i].y + forces[i].y) * damping;
      positions[i].x += vel[i].x;
      positions[i].y += vel[i].y;
    }
  }

  // Clamp positions to stay within the cluster radius
  for (let i = 0; i < positions.length; i++) {
    const dx = positions[i].x - center.x;
    const dy = positions[i].y - center.y;
    const d = Math.sqrt(dx * dx + dy * dy);
    const maxR = center.r * 0.85;
    if (d > maxR) {
      positions[i].x = center.x + (dx / d) * maxR;
      positions[i].y = center.y + (dy / d) * maxR;
    }
  }

  return positions;
}
