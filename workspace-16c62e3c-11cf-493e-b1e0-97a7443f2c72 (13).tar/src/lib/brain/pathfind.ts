import type { NeuralGraph, PathResult } from "@/components/brain/types";

/**
 * Compute the shortest import path between two neurons using BFS over the
 * directed synapse graph (source → target = "imports"). Returns the ordered
 * list of neuron indices from `fromIdx` to `toIdx` (inclusive), or an empty
 * path if unreachable.
 *
 * The graph is directed: an edge a→b means "a imports b". So a path from
 * `from` to `to` represents the chain of imports leading from `from` to `to`.
 */
export function shortestPath(
  graph: NeuralGraph,
  fromIdx: number,
  toIdx: number
): PathResult {
  if (fromIdx < 0 || toIdx < 0 || fromIdx >= graph.neurons.length || toIdx >= graph.neurons.length) {
    return { path: [], hops: -1 };
  }
  if (fromIdx === toIdx) return { path: [fromIdx], hops: 0 };

  // build adjacency list from synapses (directed: source → target)
  const adj = new Map<number, number[]>();
  for (const s of graph.synapses) {
    const arr = adj.get(s.source);
    if (arr) arr.push(s.target);
    else adj.set(s.source, [s.target]);
  }

  // BFS
  const visited = new Uint8Array(graph.neurons.length);
  const prev = new Int32Array(graph.neurons.length).fill(-1);
  const queue: number[] = [fromIdx];
  visited[fromIdx] = 1;
  let found = false;
  while (queue.length > 0) {
    const cur = queue.shift()!;
    if (cur === toIdx) {
      found = true;
      break;
    }
    const neighbors = adj.get(cur);
    if (!neighbors) continue;
    for (const next of neighbors) {
      if (!visited[next]) {
        visited[next] = 1;
        prev[next] = cur;
        queue.push(next);
      }
    }
  }

  if (!found) return { path: [], hops: -1 };

  // reconstruct path
  const path: number[] = [];
  let cur: number = toIdx;
  while (cur !== -1) {
    path.push(cur);
    if (cur === fromIdx) break;
    cur = prev[cur];
  }
  path.reverse();
  return { path, hops: path.length - 1 };
}
