import { promises as fs, statSync } from "node:fs";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import path from "node:path";
import type { NeuralGraph, Neuron, Synapse } from "@/components/brain/types";
import { CLUSTERS, classifyFile, kindOf } from "./anatomy";

const execFileAsync = promisify(execFile);

const PROJECT_ROOT = path.resolve(process.cwd());

const SCAN_DIRS = ["src", "prisma", "mini-services"];
const SCAN_EXTS = new Set([
  ".ts", ".tsx", ".js", ".jsx", ".prisma", ".json", ".mjs", ".cjs",
]);

const SKIP_DIRS = new Set([
  "node_modules", ".next", ".git", "dist", "build", "out",
  "coverage", ".turbo", ".cache", "tests",
]);

const SKIP_FILES = new Set([
  "bun.lock", "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
  "tsconfig.tsbuildinfo",
]);

async function walk(dir: string, root: string, acc: string[]) {
  let entries: import("node:fs").Dirent[];
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const e of entries) {
    if (e.isDirectory()) {
      if (SKIP_DIRS.has(e.name)) continue;
      // skip the brain's own components to avoid self-recursion noise
      if (path.relative(root, path.join(dir, e.name)).startsWith("src/components/brain")) continue;
      await walk(path.join(dir, e.name), root, acc);
    } else if (e.isFile()) {
      if (SKIP_FILES.has(e.name)) continue;
      const ext = path.extname(e.name);
      if (!SCAN_EXTS.has(ext)) continue;
      acc.push(path.join(dir, e.name));
    }
  }
}

const ALIAS: Record<string, string> = {
  "@/": "src/",
  "~/": "src/",
};

/** Resolve a TypeScript import string to an absolute file path. */
function resolveImport(spec: string, importerAbs: string): string | null {
  // skip bare module imports (react, next, etc.)
  if (!spec.startsWith(".") && !spec.startsWith("@/") && !spec.startsWith("~/")) {
    return null;
  }
  let target = spec;
  for (const [from, to] of Object.entries(ALIAS)) {
    if (spec.startsWith(from)) {
      target = path.join(PROJECT_ROOT, to, spec.slice(from.length));
      break;
    }
  }
  if (spec.startsWith(".")) {
    target = path.resolve(path.dirname(importerAbs), spec);
  }
  // try several extensions
  const candidates = [
    target,
    target + ".ts",
    target + ".tsx",
    target + ".js",
    target + ".jsx",
    target + ".mjs",
    target + ".cjs",
    path.join(target, "index.ts"),
    path.join(target, "index.tsx"),
    path.join(target, "index.js"),
  ];
  for (const c of candidates) {
    // normalize and only return files inside PROJECT_ROOT
    if (c.startsWith(PROJECT_ROOT)) {
      try {
        if (statSync(c).isFile()) return c;
      } catch {
        // ignore
      }
    }
  }
  return null;
}

const IMPORT_RE =
  /(?:^|[\s;])(?:import|export)(?:\s+[\s\S]*?\s+from)?\s*['"`]([^'"`]+)['"`]/g;

async function readFileSafe(p: string): Promise<string> {
  try {
    return await fs.readFile(p, "utf8");
  } catch {
    return "";
  }
}

/** Build the full neural graph by scanning the project tree. */
export async function buildNeuralGraph(): Promise<NeuralGraph> {
  const files: string[] = [];
  for (const d of SCAN_DIRS) {
    const abs = path.join(PROJECT_ROOT, d);
    await walk(abs, PROJECT_ROOT, files);
  }
  // include root-level config files for the cerebellum cluster
  for (const f of [
    "next.config.ts", "tailwind.config.ts", "postcss.config.mjs",
    "tsconfig.json", "eslint.config.mjs", "components.json",
    "package.json", "Caddyfile",
  ]) {
    const abs = path.join(PROJECT_ROOT, f);
    try {
      if (statSync(abs).isFile()) files.push(abs);
    } catch {
      // ignore missing
    }
  }

  const neurons: Neuron[] = [];
  const pathToIndex = new Map<string, number>();

  for (const abs of files) {
    const rel = path.relative(PROJECT_ROOT, abs).replace(/\\/g, "/");
    const content = await readFileSafe(abs);
    const cluster = classifyFile(rel);
    const kind = kindOf(rel, content);
    const loc = content ? content.split("\n").length : 0;
    const importMatches = content.matchAll(IMPORT_RE);
    const imports: string[] = [];
    for (const m of importMatches) {
      const spec = m[1];
      const resolved = resolveImport(spec, abs);
      if (resolved) imports.push(resolved);
    }
    const idx = neurons.length;
    neurons.push({
      id: rel,
      path: rel,
      name: path.basename(rel),
      cluster,
      loc,
      imports: imports.length,
      importedBy: 0, // filled below
      kind,
    });
    pathToIndex.set(abs, idx);
    // stash imports on the neuron temporarily via the id map; we re-resolve below
    (neurons[idx] as Neuron & { _imports?: string[] })._imports = imports;
  }

  // Build synapses
  const synapseSet = new Map<string, Synapse>();
  for (let i = 0; i < neurons.length; i++) {
    const n = neurons[i] as Neuron & { _imports?: string[] };
    if (!n._imports) continue;
    for (const targetAbs of n._imports) {
      const targetIdx = pathToIndex.get(targetAbs);
      if (targetIdx === undefined || targetIdx === i) continue;
      const key = `${i}->${targetIdx}`;
      if (!synapseSet.has(key)) {
        synapseSet.set(key, { source: i, target: targetIdx, weight: 1 });
        neurons[targetIdx].importedBy += 1;
      }
    }
    delete n._imports;
  }

  const synapses = Array.from(synapseSet.values());

  // Ensure every declared cluster has at least one neuron so the brain still
  // renders all lobes even on tiny codebases.
  const present = new Set(neurons.map((n) => n.cluster));
  for (const c of CLUSTERS) {
    if (!present.has(c.id)) {
      neurons.push({
        id: `__virtual__/${c.id}`,
        path: `(empty) ${c.domain}`,
        name: "(empty)",
        cluster: c.id,
        loc: 0,
        imports: 0,
        importedBy: 0,
        kind: "virtual",
      });
    }
  }

  // ---- Detect circular import chains via DFS on the directed synapse graph ----
  const adj = new Map<number, number[]>();
  for (const s of synapses) {
    const arr = adj.get(s.source) ?? [];
    arr.push(s.target);
    adj.set(s.source, arr);
  }
  const circularSet = detectCircular(neurons.length, adj);
  for (const idx of circularSet) {
    if (neurons[idx]) neurons[idx].circular = true;
  }

  // ---- Fetch last-commit timestamp per file via git (best-effort) ----
  const lastCommitMap = await fetchGitActivity(files);
  for (let i = 0; i < neurons.length; i++) {
    const abs = files[i];
    if (abs) {
      const rel = path.relative(PROJECT_ROOT, abs).replace(/\\/g, "/");
      neurons[i].lastCommit = lastCommitMap.get(rel) ?? null;
    }
  }

  return {
    clusters: CLUSTERS,
    neurons,
    synapses,
    stats: {
      files: neurons.length,
      edges: synapses.length,
      clusters: CLUSTERS.length,
      avgDegree: neurons.length
        ? +(synapses.length / neurons.length).toFixed(2)
        : 0,
      circularCount: circularSet.size,
    },
  };
}

/**
 * Detect all neurons that participate in a circular import chain using
 * iterative DFS with WHITE/GRAY/BLACK coloring. Returns a Set of neuron
 * indices that are part of any cycle.
 */
function detectCircular(n: number, adj: Map<number, number[]>): Set<number> {
  // 0 = white (unvisited), 1 = gray (on stack), 2 = black (done)
  const color = new Uint8Array(n);
  const onCyclePath = new Set<number>();
  const cyclic = new Set<number>();

  for (let start = 0; start < n; start++) {
    if (color[start] !== 0) continue;
    const stack: { node: number; iter: number }[] = [{ node: start, iter: 0 }];
    const path: number[] = [];
    color[start] = 1;
    while (stack.length > 0) {
      const top = stack[stack.length - 1];
      const neighbors = adj.get(top.node) ?? [];
      if (top.iter < neighbors.length) {
        const next = neighbors[top.iter++];
        if (color[next] === 0) {
          color[next] = 1;
          path.push(top.node);
          stack.push({ node: next, iter: 0 });
        } else if (color[next] === 1) {
          // found a back-edge → cycle. Mark all nodes from `next` to current.
          cyclic.add(next);
          let i = path.length - 1;
          while (i >= 0 && path[i] !== next) {
            cyclic.add(path[i]);
            i--;
          }
          cyclic.add(top.node);
        }
      } else {
        color[top.node] = 2;
        path.pop();
        stack.pop();
      }
    }
  }
  void onCyclePath; // (kept for future cycle-path extraction)
  return cyclic;
}

/**
 * Fetch the last-commit ISO timestamp for each file using `git log`. Falls back
 * to an empty map if git is unavailable or the project isn't a git repo.
 * Runs a single `git log --name-only` for efficiency.
 */
async function fetchGitActivity(absFiles: string[]): Promise<Map<string, string>> {
  const result = new Map<string, string>();
  if (absFiles.length === 0) return result;
  try {
    // one git log call returning "ISO<TAB>path" per file, most-recent first
    const { stdout } = await execFileAsync(
      "git",
      [
        "log",
        "--name-only",
        "--format=%aI",
        "--no-renames",
        "--diff-filter=AM",
      ],
      { cwd: PROJECT_ROOT, maxBuffer: 8 * 1024 * 1024, timeout: 8000 }
    );
    // parse: each commit block starts with an ISO timestamp line, followed by
    // blank line(s) and the file list until the next timestamp.
    let currentDate: string | null = null;
    for (const rawLine of stdout.split("\n")) {
      const line = rawLine.trim();
      if (!line) continue;
      // ISO timestamps start with a 4-digit year + '-'
      if (/^\d{4}-\d{2}-\d{2}T/.test(line)) {
        currentDate = line;
        continue;
      }
      if (currentDate && !result.has(line)) {
        result.set(line, currentDate);
      }
    }
  } catch {
    // git not available or not a repo — return empty map
  }
  return result;
}
