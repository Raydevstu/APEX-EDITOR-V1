import type { Cluster } from "@/components/brain/types";

/**
 * The brain anatomy: each cluster is a lobe/region of the brain and is mapped
 * to a codebase directory. The anchor is in normalized brain-space [0..1]
 * where (0.5, 0.5) is the brain center; y grows downward.
 *
 * The palette intentionally avoids indigo/blue; we use violet, magenta,
 * emerald, amber, rose, cyan and fuchsia.
 */
export const CLUSTERS: Cluster[] = [
  {
    id: "prefrontal",
    label: "Prefrontal Cortex",
    domain: "App Pages",
    color: "#a855f7", // violet
    anatomy: "Higher-order routing & layout — the front of the brain where app pages and the root route are orchestrated.",
    anchor: { x: 0.5, y: 0.26 },
    weight: 1.15,
  },
  {
    id: "motor",
    label: "Motor Cortex",
    domain: "API Routes",
    color: "#22d3ee", // cyan
    anatomy: "Top-strip driving action — every server endpoint lives here as a nerve that fires on request.",
    anchor: { x: 0.5, y: 0.12 },
    weight: 0.95,
  },
  {
    id: "frontal",
    label: "Frontal Lobe",
    domain: "Lib & Utils",
    color: "#d946ef", // fuchsia / magenta
    anatomy: "Reasoning & planning utilities — shared helpers, database client, and core logic.",
    anchor: { x: 0.74, y: 0.36 },
    weight: 1.0,
  },
  {
    id: "visual",
    label: "Visual Cortex",
    domain: "UI Components",
    color: "#34d399", // emerald
    anatomy: "Perception of the interface — every shadcn/ui primitive the eye of the user ultimately sees.",
    anchor: { x: 0.18, y: 0.62 },
    weight: 1.4,
  },
  {
    id: "parietal",
    label: "Parietal Lobe",
    domain: "Hooks",
    color: "#fb7185", // rose
    anatomy: "Sensory integration — small reactive hooks bind signals from across the body into behavior.",
    anchor: { x: 0.42, y: 0.58 },
    weight: 0.7,
  },
  {
    id: "temporal",
    label: "Temporal Lobe",
    domain: "Database & Schema",
    color: "#fbbf24", // amber
    anatomy: "Long-term memory — the Prisma schema and migrations encode what the app remembers.",
    anchor: { x: 0.74, y: 0.74 },
    weight: 0.85,
  },
  {
    id: "cerebellum",
    label: "Cerebellum",
    domain: "Config & Tooling",
    color: "#c084fc", // light violet
    anatomy: "Coordination & balance — the build config, tailwind theme and tooling that keeps the body upright.",
    anchor: { x: 0.36, y: 0.86 },
    weight: 0.8,
  },
];

/** Map a file path to a cluster id based on its directory. */
export function classifyFile(relPath: string): Cluster["id"] {
  const p = relPath.replace(/\\/g, "/");
  if (p.startsWith("src/components/ui/")) return "visual";
  if (p.startsWith("src/components/")) return "visual";
  if (p.startsWith("src/app/api/")) return "motor";
  if (p.startsWith("src/app/")) return "prefrontal";
  if (p.startsWith("src/hooks/")) return "parietal";
  if (p.startsWith("src/lib/")) return "frontal";
  if (p.startsWith("prisma/")) return "temporal";
  if (
    p.startsWith("prisma/") ||
    p.endsWith("schema.prisma") ||
    p.includes("/db.ts") ||
    p.includes("lib/db")
  )
    return "temporal";
  // fallthroughs
  if (p.startsWith("next.config") || p.startsWith("tailwind.config") || p.startsWith("postcss.config"))
    return "cerebellum";
  if (p.startsWith("tsconfig") || p.startsWith("eslint.config") || p.startsWith("components.json"))
    return "cerebellum";
  if (p.startsWith("Caddyfile") || p.startsWith("package.json")) return "cerebellum";
  return "frontal";
}

/** Assign a coarse semantic "kind" tag from the filename/path. */
export function kindOf(relPath: string, content: string): string {
  const p = relPath.replace(/\\/g, "/");
  if (p.startsWith("src/app/api/")) return "api";
  if (p === "src/app/page.tsx" || p.startsWith("src/app/") && p.endsWith("page.tsx")) return "page";
  if (p.endsWith("layout.tsx")) return "layout";
  if (p.startsWith("src/hooks/")) return "hook";
  if (p.startsWith("src/components/ui/")) return "ui";
  if (p.startsWith("src/components/")) return "component";
  if (p.startsWith("prisma/") && p.endsWith(".prisma")) return "schema";
  if (p.endsWith(".prisma")) return "schema";
  if (p.includes("lib/db")) return "db";
  if (p.endsWith(".config.ts") || p.endsWith(".config.mjs") || p.endsWith(".config.js")) return "config";
  if (p.startsWith("src/lib/")) return "lib";
  if (p === "package.json") return "manifest";
  if (content.includes("export async function GET") || content.includes("export async function POST"))
    return "api";
  return "module";
}
