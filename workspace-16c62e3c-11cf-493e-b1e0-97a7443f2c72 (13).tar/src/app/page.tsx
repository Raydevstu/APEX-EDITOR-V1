"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast, Toaster as SonnerToaster } from "sonner";
import BrainCanvas from "@/components/brain/BrainCanvas";
import InfoPanel from "@/components/brain/InfoPanel";
import ControlPanel from "@/components/brain/ControlPanel";
import HoverTooltip from "@/components/brain/HoverTooltip";
import BrainHeader from "@/components/brain/BrainHeader";
import BrainFooter from "@/components/brain/BrainFooter";
import MiniMap from "@/components/brain/MiniMap";
import ShortcutsHint from "@/components/brain/ShortcutsHint";
import RadialMenu from "@/components/brain/RadialMenu";
import ExportShare from "@/components/brain/ExportShare";
import RecentlyChanged from "@/components/brain/RecentlyChanged";
import DependencyMatrix from "@/components/brain/DependencyMatrix";
import OnboardingTour from "@/components/brain/OnboardingTour";
import type {
  CameraCommand,
  CameraState,
  Cluster,
  NavigateCommand,
  NeuralGraph,
  Neuron,
} from "@/components/brain/types";
import { shortestPath } from "@/lib/brain/pathfind";
import { useAudio } from "@/hooks/use-audio";
import { Skeleton } from "@/components/ui/skeleton";

async function fetchGraph(): Promise<NeuralGraph> {
  const res = await fetch("/api/codebase", { cache: "no-store" });
  if (!res.ok) throw new Error("failed to load neural graph");
  return (await res.json()) as NeuralGraph;
}

// localStorage preference keys
const PREF_KEY = "codebase-brain:prefs:v1";

interface Prefs {
  showSynapses: boolean;
  showLabels: boolean;
  showFiring: boolean;
  parallax: boolean;
}

const DEFAULT_PREFS: Prefs = {
  showSynapses: true,
  showLabels: true,
  showFiring: true,
  parallax: true,
};

function loadPrefs(): Prefs {
  if (typeof window === "undefined") return DEFAULT_PREFS;
  try {
    const raw = window.localStorage.getItem(PREF_KEY);
    if (!raw) return DEFAULT_PREFS;
    const parsed = JSON.parse(raw) as Partial<Prefs>;
    return { ...DEFAULT_PREFS, ...parsed };
  } catch {
    return DEFAULT_PREFS;
  }
}

export default function Home() {
  const { data: graph, isLoading, isError, refetch } = useQuery<NeuralGraph>({
    queryKey: ["codebase-graph"],
    queryFn: fetchGraph,
    staleTime: 30_000,
  });

  // Load persisted prefs via lazy useState initializers (avoids setState-in-effect)
  const [showSynapses, setShowSynapses] = useState(() => loadPrefs().showSynapses);
  const [showLabels, setShowLabels] = useState(() => loadPrefs().showLabels);
  const [showFiring, setShowFiring] = useState(() => loadPrefs().showFiring);
  const [parallax, setParallax] = useState(() => loadPrefs().parallax);
  const [showGitHeat, setShowGitHeat] = useState(true);
  const [showRegionFlow, setShowRegionFlow] = useState(false);
  const [showOrbital, setShowOrbital] = useState(true);
  const [showRecent, setShowRecent] = useState(false);
  const [showMatrix, setShowMatrix] = useState(false);
  const [useForceLayout, setUseForceLayout] = useState(true);
  const [flowFilter, setFlowFilter] = useState<{ from: string; to: string } | null>(null);
  const [audioEnabled, setAudioEnabled] = useState(false);
  const playSound = useAudio(audioEnabled);
  const [navigateCommand, setNavigateCommand] = useState<NavigateCommand | null>(null);

  // Persist prefs whenever they change
  useEffect(() => {
    try {
      window.localStorage.setItem(
        PREF_KEY,
        JSON.stringify({ showSynapses, showLabels, showFiring, parallax })
      );
    } catch {
      // ignore
    }
  }, [showSynapses, showLabels, showFiring, parallax]);

  // local UI state
  const [hiddenClusters, setHiddenClusters] = useState<Set<string>>(new Set());
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Neuron | null>(null);
  const [hovered, setHovered] = useState<Neuron | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [activity, setActivity] = useState(0);
  const [visibleNeurons, setVisibleNeurons] = useState(0);
  const [scanAge, setScanAge] = useState(0);

  // camera / focus state
  const [focusClusterId, setFocusClusterId] = useState<string | null>(null);
  const [cameraCommand, setCameraCommand] = useState<CameraCommand | null>(null);
  const [camera, setCamera] = useState<CameraState>({ panX: 0, panY: 0, zoom: 1 });
  // trace mode: neuron ID being traced (sustained firing)
  const [traceNeuronId, setTraceNeuronId] = useState<string | null>(null);
  const traceTimerRef = useRef<number | null>(null);
  // radial menu state
  const [radialMenu, setRadialMenu] = useState<{
    neuron: Neuron;
    x: number;
    y: number;
  } | null>(null);
  // search input ref (for `/` shortcut focus)
  const searchInputRef = useRef<HTMLInputElement | null>(null);
  // path-finder: second neuron (shift-clicked) + computed path
  const [pathEndpoint, setPathEndpoint] = useState<Neuron | null>(null);

  // Visible clusters = all clusters minus hidden ones. Derived, not stored.
  const visibleClusters = useMemo(() => {
    const set = new Set<string>();
    if (graph) {
      for (const c of graph.clusters) {
        if (!hiddenClusters.has(c.id)) set.add(c.id);
      }
    }
    return set;
  }, [graph, hiddenClusters]);

  // refresh scan age every second
  useEffect(() => {
    const id = setInterval(() => setScanAge((s) => s + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const clusterMap = useMemo(() => {
    const m = new Map<string, Cluster>();
    graph?.clusters.forEach((c) => m.set(c.id, c));
    return m;
  }, [graph]);

  const clusterCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    graph?.neurons.forEach((n) => {
      if (n.kind === "virtual") return;
      counts[n.cluster] = (counts[n.cluster] ?? 0) + 1;
    });
    return counts;
  }, [graph]);

  const clusterLocs = useMemo(() => {
    const locs: Record<string, number> = {};
    graph?.neurons.forEach((n) => {
      if (n.kind === "virtual") return;
      locs[n.cluster] = (locs[n.cluster] ?? 0) + n.loc;
    });
    return locs;
  }, [graph]);

  // Per-cluster outgoing dependency flow (top targets, sorted by count desc)
  const clusterFlow = useMemo(() => {
    const flow: Record<string, { to: string; count: number }[]> = {};
    if (!graph) return flow;
    const map = new Map<string, number>();
    for (const s of graph.synapses) {
      const na = graph.neurons[s.source];
      const nb = graph.neurons[s.target];
      if (!na || !nb || na.cluster === nb.cluster) continue;
      const key = `${na.cluster}->${nb.cluster}`;
      map.set(key, (map.get(key) ?? 0) + 1);
    }
    for (const [key, count] of map.entries()) {
      const [from, to] = key.split("->");
      if (!flow[from]) flow[from] = [];
      flow[from].push({ to, count });
    }
    for (const k of Object.keys(flow)) {
      flow[k].sort((a, b) => b.count - a.count);
    }
    return flow;
  }, [graph]);

  const selectedCluster = selected ? clusterMap.get(selected.cluster) : undefined;
  const hoveredCluster = hovered ? clusterMap.get(hovered.cluster) : undefined;
  const focusCluster = focusClusterId ? clusterMap.get(focusClusterId) ?? null : null;

  // Share-link auto-select: when the graph loads, check URL for ?n=<path> and
  // auto-select that neuron. Uses the React-recommended "adjust state during
  // render" pattern (storing the previous graph reference) to avoid calling
  // setState in an effect body.
  const [lastGraphRef, setLastGraphRef] = useState<NeuralGraph | null>(null);
  if (graph !== lastGraphRef) {
    setLastGraphRef(graph);
    if (graph && !selected) {
      try {
        const url = new URL(window.location.href);
        const n = url.searchParams.get("n");
        if (n) {
          const neuron = graph.neurons.find((x) => x.path === n || x.id === n);
          if (neuron) {
            setSelected(neuron);
            toast.info("Loaded from share link", { description: neuron.path });
          }
        }
      } catch {
        // ignore URL parse errors (SSR)
      }
    }
  }

  const handleActivity = useCallback((activeCount: number) => {
    setVisibleNeurons(activeCount);
    const denom = Math.max(1, activeCount);
    const base = Math.min(1, activeCount / Math.max(40, denom * 0.6));
    setActivity((prev) => prev * 0.85 + (0.4 + base * 0.6 + Math.random() * 0.1) * 0.15);
  }, []);

  const toggleCluster = useCallback((id: string) => {
    setHiddenClusters((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const showAllClusters = useCallback(() => {
    setHiddenClusters(new Set());
  }, []);

  const isolateCluster = useCallback(
    (clusterId: string) => {
      if (!graph) return;
      const others = new Set(
        graph.clusters.filter((c) => c.id !== clusterId).map((c) => c.id)
      );
      setHiddenClusters(others);
      setFocusClusterId(clusterId);
      setCameraCommand({ type: "focus-cluster", clusterId, nonce: Date.now() });
      const c = clusterMap.get(clusterId);
      if (c) toast.success(`Isolated ${c.label}`, { description: c.domain });
      playSound("isolate");
    },
    [graph, clusterMap, playSound]
  );

  const handleHover = useCallback((n: Neuron | null) => {
    setHovered(n);
  }, []);

  const resetView = useCallback(() => {
    setQuery("");
    setHiddenClusters(new Set());
    setFocusClusterId(null);
    setSelected(null);
    setTraceNeuronId(null);
    setPathEndpoint(null);
    setFlowFilter(null);
    setCameraCommand({ type: "reset", nonce: Date.now() });
  }, []);

  // shift-click handler: set the path-finder endpoint. The first shift-click
  // sets the endpoint; a second shift-click (or clicking the same neuron)
  // clears it. Requires a selected neuron as the path source.
  const handleShiftClick = useCallback(
    (n: Neuron) => {
      if (!selected) {
        // if nothing is selected, treat the shift-click as selecting the source
        setSelected(n);
        setPathEndpoint(null);
        toast.info("Path source set", { description: `Shift-click another neuron to find the import path from ${n.name}` });
        return;
      }
      if (pathEndpoint?.id === n.id) {
        // toggle off
        setPathEndpoint(null);
        toast.info("Path cleared");
        return;
      }
      setPathEndpoint(n);
      const fromName = selected.name;
      const toName = n.name;
      toast.success("Finding path…", { description: `${fromName} → ${toName}` });
    },
    [selected, pathEndpoint]
  );

  // compute the shortest path whenever both endpoints are set
  const pathHighlight = useMemo(() => {
    if (!graph || !selected || !pathEndpoint || selected.id === pathEndpoint.id) return null;
    const fromIdx = graph.neurons.findIndex((n) => n.id === selected.id);
    const toIdx = graph.neurons.findIndex((n) => n.id === pathEndpoint.id);
    if (fromIdx < 0 || toIdx < 0) return null;
    const result = shortestPath(graph, fromIdx, toIdx);
    return result.path.length > 0 ? result.path : null;
  }, [graph, selected, pathEndpoint]);

  // track the endpoint we've already reported on, so we fire the toast exactly
  // once per endpoint-set (avoids re-toasting on every re-render).
  const lastReportedEndpointRef = useRef<string | null>(null);
  useEffect(() => {
    if (!graph || !selected || !pathEndpoint) return;
    // skip if we've already reported this endpoint
    if (lastReportedEndpointRef.current === pathEndpoint.id) return;
    lastReportedEndpointRef.current = pathEndpoint.id;
    if (pathHighlight && pathHighlight.length > 1) {
      toast.success(`Path found: ${pathHighlight.length - 1} hops`, {
        description: `${selected.name} → ${pathEndpoint.name}`,
      });
    } else {
      // no path found — clear the endpoint + warn the user
      toast.error("No import path found", {
        description: `${selected.name} → ${pathEndpoint.name} — these files aren't connected via imports`,
      });
      // small delay so the user sees the endpoint ring briefly before clearing
      window.setTimeout(() => setPathEndpoint(null), 600);
    }
  }, [pathHighlight, graph, selected, pathEndpoint]);

  const handleFocusCluster = useCallback((clusterId: string) => {
    setFocusClusterId(clusterId);
    setCameraCommand({ type: "focus-cluster", clusterId, nonce: Date.now() });
    const c = clusterMap.get(clusterId);
    if (c) toast.info(`Focused ${c.label}`, { description: c.domain });
    playSound("whoosh");
  }, [clusterMap, playSound]);

  const exitFocus = useCallback(() => {
    setFocusClusterId(null);
    setCameraCommand({ type: "reset", nonce: Date.now() });
  }, []);

  // start trace mode for a neuron (sustained firing for 3 seconds)
  const startTrace = useCallback(
    (neuron: Neuron) => {
      setTraceNeuronId(neuron.id);
      if (traceTimerRef.current) window.clearTimeout(traceTimerRef.current);
      traceTimerRef.current = window.setTimeout(() => {
        setTraceNeuronId(null);
        traceTimerRef.current = null;
      }, 3500);
      const c = clusterMap.get(neuron.cluster);
      toast.success(`Tracing ${neuron.name}`, {
        description: c ? `${c.label} · firing all ${neuron.imports + neuron.importedBy} synapses` : `${neuron.imports + neuron.importedBy} synapses`,
      });
      playSound("trace");
    },
    [clusterMap, playSound]
  );

  // radial menu actions
  const handleRadialAction = useCallback(
    (action: string, neuron: Neuron) => {
      setRadialMenu(null);
      switch (action) {
        case "focus":
          setSelected(neuron);
          setCameraCommand({ type: "focus-neuron", neuronId: neuron.id, nonce: Date.now() });
          toast.info(`Focused ${neuron.name}`, { description: neuron.path });
          break;
        case "trace":
          setSelected(neuron);
          startTrace(neuron);
          break;
        case "isolate": {
          // isolate the neuron's cluster
          isolateCluster(neuron.cluster);
          setSelected(neuron);
          break;
        }
        case "copy":
          try {
            navigator.clipboard.writeText(neuron.path);
            toast.success("Copied path to clipboard", { description: neuron.path });
          } catch {
            toast.error("Failed to copy path");
          }
          break;
      }
    },
    [isolateCluster, startTrace]
  );

  // cleanup trace timer on unmount
  useEffect(() => {
    return () => {
      if (traceTimerRef.current) window.clearTimeout(traceTimerRef.current);
    };
  }, []);

  // mini-map is shown when the camera has moved away from the default
  const minimapActive =
    Math.abs(camera.panX) > 4 || Math.abs(camera.panY) > 4 || Math.abs(camera.zoom - 1) > 0.04;

  // track mouse position relative to the canvas wrapper for the tooltip
  const wrapRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const onMove = (e: PointerEvent) => {
      const rect = el.getBoundingClientRect();
      setMousePos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
    };
    el.addEventListener("pointermove", onMove);
    return () => el.removeEventListener("pointermove", onMove);
  }, []);

  // keyboard shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      // ignore when typing in an input/textarea
      const target = e.target as HTMLElement | null;
      const tag = target?.tagName?.toLowerCase();
      const isEditable =
        tag === "input" || tag === "textarea" || target?.isContentEditable;
      if (isEditable) {
        // Esc blurs the input
        if (e.key === "Escape") {
          (target as HTMLElement).blur();
        }
        return;
      }
      switch (e.key) {
        case "/":
          e.preventDefault();
          searchInputRef.current?.focus();
          searchInputRef.current?.select();
          break;
        case "Escape":
          if (radialMenu) {
            setRadialMenu(null);
          } else if (traceNeuronId) {
            setTraceNeuronId(null);
            if (traceTimerRef.current) window.clearTimeout(traceTimerRef.current);
          } else if (focusClusterId) {
            exitFocus();
          } else if (selected) {
            setSelected(null);
          }
          break;
        case "r":
        case "R":
          resetView();
          break;
        case "f":
        case "F":
          setShowFiring((v) => !v);
          break;
        case "s":
        case "S":
          setShowSynapses((v) => !v);
          break;
        case "l":
        case "L":
          setShowLabels((v) => !v);
          break;
        case "p":
        case "P":
          setParallax((v) => !v);
          break;
        case "g":
        case "G":
          setShowGitHeat((v) => !v);
          break;
        case "o":
        case "O":
          setShowOrbital((v) => !v);
          break;
        case "v":
        case "V":
          setShowRegionFlow((v) => !v);
          break;
        case "m":
        case "M":
          setShowMatrix((v) => !v);
          break;
        case "ArrowUp":
          if (selected) {
            e.preventDefault();
            setNavigateCommand({ direction: "up", nonce: Date.now() });
          }
          break;
        case "ArrowDown":
          if (selected) {
            e.preventDefault();
            setNavigateCommand({ direction: "down", nonce: Date.now() });
          }
          break;
        case "ArrowLeft":
          if (selected) {
            e.preventDefault();
            setNavigateCommand({ direction: "left", nonce: Date.now() });
          }
          break;
        case "ArrowRight":
          if (selected) {
            e.preventDefault();
            setNavigateCommand({ direction: "right", nonce: Date.now() });
          }
          break;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [
    focusClusterId,
    selected,
    exitFocus,
    resetView,
    radialMenu,
    traceNeuronId,
  ]);

  return (
    <main
      ref={wrapRef}
      className="relative flex min-h-screen flex-col overflow-hidden bg-[#02010a] text-white"
      style={{ height: "100vh" }}
    >
      {/* Subtle radial backdrop layer for extra depth */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(1200px 700px at 50% 30%, rgba(168,85,247,0.08), transparent 60%), radial-gradient(900px 600px at 80% 80%, rgba(34,211,238,0.05), transparent 60%)",
        }}
      />

      {/* Canvas area */}
      <section className="relative flex-1">
        {isLoading && <LoadingState />}
        {isError && <ErrorState onRetry={() => refetch()} />}
        {graph && (
          <>
            <BrainHeader
              lastScan={scanAge}
              focusCluster={focusCluster}
              onExitFocus={exitFocus}
            />
            <BrainCanvas
              graph={graph}
              visibleClusters={visibleClusters}
              showSynapses={showSynapses}
              showLabels={showLabels}
              showFiring={showFiring}
              parallax={parallax}
              query={query}
              selectedId={selected?.id ?? null}
              traceNeuronId={traceNeuronId}
              pathHighlight={pathHighlight}
              showGitHeat={showGitHeat}
              showRegionFlow={showRegionFlow}
              showOrbital={showOrbital}
              useForceLayout={useForceLayout}
              focusClusterId={focusClusterId}
              flowFilter={flowFilter}
              onSelect={(n) => {
                setSelected(n);
                if (n) playSound("select");
              }}
              onHover={handleHover}
              onActivity={handleActivity}
              cameraCommand={cameraCommand}
              onCameraChange={setCamera}
              onFocusCluster={handleFocusCluster}
              onShiftClick={handleShiftClick}
              onAmbientFire={() => {
                if (audioEnabled) playSound("click");
              }}
              navigateCommand={navigateCommand}
              onContextMenu={(neuron, sx, sy) => {
                // convert screen coords to local wrapper coords for positioning
                const el = wrapRef.current;
                if (!el) return;
                const rect = el.getBoundingClientRect();
                setRadialMenu({
                  neuron,
                  x: sx - rect.left,
                  y: sy - rect.top,
                });
              }}
            />
            <ControlPanel
              query={query}
              onQuery={setQuery}
              searchInputRef={searchInputRef}
              showSynapses={showSynapses}
              onShowSynapses={setShowSynapses}
              showLabels={showLabels}
              onShowLabels={setShowLabels}
              showFiring={showFiring}
              onShowFiring={setShowFiring}
              parallax={parallax}
              onParallax={setParallax}
              showGitHeat={showGitHeat}
              onShowGitHeat={setShowGitHeat}
              showRegionFlow={showRegionFlow}
              onShowRegionFlow={setShowRegionFlow}
              showOrbital={showOrbital}
              onShowOrbital={setShowOrbital}
              useForceLayout={useForceLayout}
              onUseForceLayout={setUseForceLayout}
              audioEnabled={audioEnabled}
              onAudioEnabled={setAudioEnabled}
              clusters={graph.clusters}
              visibleClusters={visibleClusters}
              onToggleCluster={toggleCluster}
              onShowAll={showAllClusters}
              onResetView={resetView}
              clusterCounts={clusterCounts}
              clusterLocs={clusterLocs}
              clusterFlow={clusterFlow}
              focusClusterId={focusClusterId}
              onFocusCluster={handleFocusCluster}
            />
            <ExportShare
              selectedPath={selected?.path ?? null}
              showRecent={showRecent}
              onToggleRecent={() => setShowRecent((v) => !v)}
              showMatrix={showMatrix}
              onToggleMatrix={() => setShowMatrix((v) => !v)}
            />
            <RecentlyChanged
              graph={graph}
              open={showRecent}
              onClose={() => setShowRecent(false)}
              onSelectNeuron={setSelected}
            />
            <DependencyMatrix
              graph={graph}
              open={showMatrix}
              onClose={() => setShowMatrix(false)}
              onCellClick={(from, to) => {
                // toggle: if same pair clicked again, clear the filter
                if (flowFilter?.from === from && flowFilter?.to === to) {
                  setFlowFilter(null);
                  toast.info("Flow filter cleared");
                } else {
                  setFlowFilter({ from, to });
                  const fromCluster = clusterMap.get(from);
                  const toCluster = clusterMap.get(to);
                  toast.success("Highlighting flow", {
                    description: `${fromCluster?.domain ?? from} → ${toCluster?.domain ?? to}`,
                  });
                }
              }}
              highlightedPair={flowFilter}
              onHeaderClick={(clusterId) => {
                setShowMatrix(false);
                isolateCluster(clusterId);
              }}
            />
            <InfoPanel
              neuron={selected}
              graph={graph}
              cluster={selectedCluster}
              onSelectNeuron={setSelected}
              onClose={() => setSelected(null)}
            />
            <HoverTooltip
              neuron={hovered}
              cluster={hoveredCluster}
              x={mousePos.x}
              y={mousePos.y}
            />
            <MiniMap
              graph={graph}
              visibleClusters={visibleClusters}
              camera={camera}
              active={minimapActive}
              onReset={resetView}
            />
            <ShortcutsHint />
            <RadialMenu
              neuron={radialMenu?.neuron ?? null}
              cluster={
                radialMenu?.neuron
                  ? clusterMap.get(radialMenu.neuron.cluster)
                  : undefined
              }
              x={radialMenu?.x ?? 0}
              y={radialMenu?.y ?? 0}
              onAction={handleRadialAction}
              onClose={() => setRadialMenu(null)}
            />
          </>
        )}
      </section>

      <BrainFooter
        graph={graph ?? null}
        activity={activity}
        visibleNeurons={visibleNeurons}
      />
      <SonnerToaster
        position="bottom-center"
        theme="dark"
        toastOptions={{
          style: {
            background: "rgba(10,7,24,0.92)",
            border: "1px solid rgba(255,255,255,0.12)",
            color: "white",
            backdropFilter: "blur(12px)",
          },
        }}
      />
      <OnboardingTour />
    </main>
  );
}

function LoadingState() {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
      <div className="relative h-16 w-16">
        <div className="absolute inset-0 animate-ping rounded-full bg-violet-500/20" />
        <div className="absolute inset-2 animate-pulse rounded-full bg-violet-500/40" />
        <div className="absolute inset-4 rounded-full bg-violet-400" />
      </div>
      <div className="text-center">
        <div className="text-sm font-medium text-white/80">Mapping neurons…</div>
        <div className="mt-1 text-[11px] text-white/40">
          scanning codebase and wiring synapses
        </div>
      </div>
      <Skeleton className="mt-2 h-1 w-40 bg-white/10" />
    </div>
  );
}

function ErrorState({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
      <div className="rounded-xl border border-rose-400/30 bg-rose-400/10 px-4 py-3 text-center">
        <div className="text-sm font-medium text-rose-200">Failed to scan codebase</div>
        <div className="mt-1 text-[11px] text-rose-200/60">
          the neural graph could not be built
        </div>
      </div>
      <button
        onClick={onRetry}
        className="rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-white/10"
      >
        Retry scan
      </button>
    </div>
  );
}
