import { NextResponse } from "next/server";
import { buildNeuralGraph } from "@/lib/brain/graph";

// Force dynamic so the codebase is re-scanned on every request — useful while
// the project keeps changing during development.
export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET() {
  try {
    const graph = await buildNeuralGraph();
    return NextResponse.json(graph, {
      headers: {
        "Cache-Control": "no-store, max-age=0",
      },
    });
  } catch (err) {
    return NextResponse.json(
      { error: "Failed to build neural graph", detail: String(err) },
      { status: 500 }
    );
  }
}
