import { NextResponse } from "next/server";
import { promises as fs } from "node:fs";
import path from "node:path";

export const dynamic = "force-dynamic";

const PROJECT_ROOT = path.resolve(process.cwd());

// Allowlisted root prefixes that the endpoint may read from. Anything outside
// is rejected with 403 to avoid leaking arbitrary files (e.g. .env, ../../etc).
const ALLOW_PREFIXES = [
  path.join(PROJECT_ROOT, "src") + path.sep,
  path.join(PROJECT_ROOT, "prisma") + path.sep,
  path.join(PROJECT_ROOT, "mini-services") + path.sep,
];
const ALLOW_ROOT_FILES = new Set([
  "next.config.ts",
  "tailwind.config.ts",
  "postcss.config.mjs",
  "tsconfig.json",
  "eslint.config.mjs",
  "components.json",
  "package.json",
  "Caddyfile",
]);

const MAX_BYTES = 64 * 1024; // 64 KB cap per file preview
const MAX_LINES = 200;

function languageOf(relPath: string): string {
  const p = relPath.toLowerCase();
  if (p.endsWith(".tsx")) return "tsx";
  if (p.endsWith(".ts")) return "ts";
  if (p.endsWith(".jsx")) return "jsx";
  if (p.endsWith(".js")) return "js";
  if (p.endsWith(".mjs")) return "javascript";
  if (p.endsWith(".cjs")) return "javascript";
  if (p.endsWith(".json")) return "json";
  if (p.endsWith(".prisma")) return "graphql"; // close-enough highlighting
  if (p.endsWith(".css")) return "css";
  if (p.endsWith(".md")) return "markdown";
  return "text";
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const rel = url.searchParams.get("path");
  if (!rel) {
    return NextResponse.json({ error: "missing path" }, { status: 400 });
  }
  const normalized = rel.replace(/\\/g, "/").replace(/^\.?\//, "");
  // block path traversal
  if (normalized.includes("..") || normalized.includes("\0")) {
    return NextResponse.json({ error: "invalid path" }, { status: 400 });
  }
  const abs = path.join(PROJECT_ROOT, normalized);
  // enforce allowlist
  const inPrefix = ALLOW_PREFIXES.some((p) => abs.startsWith(p));
  const isRootFile =
    !normalized.includes("/") && ALLOW_ROOT_FILES.has(normalized);
  if (!inPrefix && !isRootFile) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }

  try {
    const buf = await fs.readFile(abs);
    const truncated = buf.length > MAX_BYTES ? buf.subarray(0, MAX_BYTES) : buf;
    const text = truncated.toString("utf8");
    const lines = text.split("\n").slice(0, MAX_LINES);
    const joined = lines.join("\n");
    const stat = await fs.stat(abs);
    return NextResponse.json({
      path: normalized,
      language: languageOf(normalized),
      content: joined,
      lines: lines.length,
      totalLines: text ? text.split("\n").length : 0,
      bytes: buf.length,
      truncated: buf.length > MAX_BYTES,
      mtime: stat.mtime.toISOString(),
    });
  } catch {
    return NextResponse.json({ error: "file not found" }, { status: 404 });
  }
}
