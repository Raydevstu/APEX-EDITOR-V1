"use client";

import { useCallback, useEffect, useRef } from "react";

/**
 * Sound types supported by the synth.
 */
export type SoundType = "click" | "whoosh" | "trace" | "select" | "isolate";

/**
 * A Web Audio API-based sound synthesizer. Generates short tones and sweeps
 * on demand — no audio files needed. Falls back to a no-op if the Web Audio
 * API isn't available or the AudioContext is blocked (e.g. before first user
 * interaction).
 *
 * Returns a `play` function that takes a sound type. The hook manages a
 * single AudioContext + a master gain node.
 */
export function useAudio(enabled: boolean) {
  const ctxRef = useRef<AudioContext | null>(null);
  const masterGainRef = useRef<GainNode | null>(null);

  // lazily create the AudioContext on first use (browsers require a user
  // gesture before audio can play)
  const ensureContext = useCallback(() => {
    if (ctxRef.current) {
      // resume if suspended (autoplay policy)
      if (ctxRef.current.state === "suspended") {
        void ctxRef.current.resume();
      }
      return ctxRef.current;
    }
    const Ctor =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext;
    if (!Ctor) return null;
    const ctx = new Ctor();
    const gain = ctx.createGain();
    gain.gain.value = 0.15; // master volume
    gain.connect(ctx.destination);
    ctxRef.current = ctx;
    masterGainRef.current = gain;
    return ctx;
  }, []);

  const play = useCallback(
    (type: SoundType) => {
      if (!enabled) return;
      const ctx = ensureContext();
      if (!ctx || !masterGainRef.current) return;
      const master = masterGainRef.current;
      const now = ctx.currentTime;

      switch (type) {
        case "click": {
          // short, soft click — a quick sine blip at 800Hz
          const osc = ctx.createOscillator();
          const g = ctx.createGain();
          osc.type = "sine";
          osc.frequency.setValueAtTime(880, now);
          osc.frequency.exponentialRampToValueAtTime(440, now + 0.08);
          g.gain.setValueAtTime(0.0001, now);
          g.gain.exponentialRampToValueAtTime(0.3, now + 0.005);
          g.gain.exponentialRampToValueAtTime(0.0001, now + 0.1);
          osc.connect(g);
          g.connect(master);
          osc.start(now);
          osc.stop(now + 0.12);
          break;
        }
        case "select": {
          // rising two-tone chime (660 → 990Hz)
          const osc = ctx.createOscillator();
          const g = ctx.createGain();
          osc.type = "triangle";
          osc.frequency.setValueAtTime(660, now);
          osc.frequency.setValueAtTime(990, now + 0.06);
          g.gain.setValueAtTime(0.0001, now);
          g.gain.exponentialRampToValueAtTime(0.25, now + 0.01);
          g.gain.exponentialRampToValueAtTime(0.0001, now + 0.18);
          osc.connect(g);
          g.connect(master);
          osc.start(now);
          osc.stop(now + 0.2);
          break;
        }
        case "whoosh": {
          // soft sweep — filtered noise descending in pitch
          const bufferSize = ctx.sampleRate * 0.4;
          const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
          const data = buffer.getChannelData(0);
          for (let i = 0; i < bufferSize; i++) {
            data[i] = (Math.random() * 2 - 1) * 0.5;
          }
          const noise = ctx.createBufferSource();
          noise.buffer = buffer;
          const filter = ctx.createBiquadFilter();
          filter.type = "bandpass";
          filter.frequency.setValueAtTime(1200, now);
          filter.frequency.exponentialRampToValueAtTime(300, now + 0.35);
          filter.Q.value = 2;
          const g = ctx.createGain();
          g.gain.setValueAtTime(0.0001, now);
          g.gain.exponentialRampToValueAtTime(0.2, now + 0.02);
          g.gain.exponentialRampToValueAtTime(0.0001, now + 0.38);
          noise.connect(filter);
          filter.connect(g);
          g.connect(master);
          noise.start(now);
          noise.stop(now + 0.4);
          break;
        }
        case "trace": {
          // electrical buzz — sawtooth at 120Hz with fast vibrato, 0.3s
          const osc = ctx.createOscillator();
          const g = ctx.createGain();
          osc.type = "sawtooth";
          osc.frequency.setValueAtTime(120, now);
          // vibrato
          const lfo = ctx.createOscillator();
          const lfoGain = ctx.createGain();
          lfo.frequency.value = 18;
          lfoGain.gain.value = 20;
          lfo.connect(lfoGain);
          lfoGain.connect(osc.frequency);
          g.gain.setValueAtTime(0.0001, now);
          g.gain.exponentialRampToValueAtTime(0.15, now + 0.02);
          g.gain.exponentialRampToValueAtTime(0.0001, now + 0.3);
          osc.connect(g);
          g.connect(master);
          osc.start(now);
          lfo.start(now);
          osc.stop(now + 0.32);
          lfo.stop(now + 0.32);
          break;
        }
        case "isolate": {
          // low thump — 100Hz sine with fast decay
          const osc = ctx.createOscillator();
          const g = ctx.createGain();
          osc.type = "sine";
          osc.frequency.setValueAtTime(100, now);
          osc.frequency.exponentialRampToValueAtTime(50, now + 0.15);
          g.gain.setValueAtTime(0.0001, now);
          g.gain.exponentialRampToValueAtTime(0.35, now + 0.01);
          g.gain.exponentialRampToValueAtTime(0.0001, now + 0.2);
          osc.connect(g);
          g.connect(master);
          osc.start(now);
          osc.stop(now + 0.22);
          break;
        }
      }
    },
    [enabled, ensureContext]
  );

  // cleanup on unmount
  useEffect(() => {
    return () => {
      if (ctxRef.current) {
        void ctxRef.current.close();
        ctxRef.current = null;
      }
    };
  }, []);

  return play;
}
