"use client";

import { useEffect, useState } from "react";

export interface FilePreview {
  path: string;
  language: string;
  content: string;
  lines: number;
  totalLines: number;
  bytes: number;
  truncated: boolean;
  mtime: string;
}

interface State {
  data: FilePreview | null;
  loading: boolean;
  error: string | null;
}

const EMPTY: State = { data: null, loading: false, error: null };
const LOADING: State = { data: null, loading: true, error: null };

/**
 * Fetch a code preview for a file path. Re-fetches when `path` changes. The
 * request is sent to `/api/file?path=...` which returns a truncated (64 KB,
 * 200-line) snippet of the file content with syntax-highlighting metadata.
 *
 * When `path` is null/empty, the hook short-circuits and returns the EMPTY
 * state directly.
 *
 * State is reset using the React-recommended "adjust state during render"
 * pattern (storing the previous key) to avoid calling setState in an effect
 * body.
 */
export function useFilePreview(path: string | null | undefined): State {
  const key = path ?? "";
  const [state, setState] = useState<State>(EMPTY);
  const [lastKey, setLastKey] = useState<string>("");

  // Adjust state synchronously during render when the key changes. React will
  // re-render immediately with the new state and the effect below never sees a
  // stale key. This is the pattern recommended at
  // https://react.dev/learn/you-might-not-need-an-effect
  if (key !== lastKey) {
    setLastKey(key);
    setState(key ? LOADING : EMPTY);
  }

  useEffect(() => {
    if (!key) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(
          `/api/file?path=${encodeURIComponent(key)}`,
          { cache: "no-store" }
        );
        if (!res.ok) {
          const j = await res.json().catch(() => ({ error: "request failed" }));
          if (!cancelled)
            setState({ data: null, loading: false, error: j.error ?? "error" });
          return;
        }
        const data = (await res.json()) as FilePreview;
        if (!cancelled) setState({ data, loading: false, error: null });
      } catch (e) {
        if (!cancelled)
          setState({
            data: null,
            loading: false,
            error: e instanceof Error ? e.message : "fetch error",
          });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [key]);

  return state;
}
