"use client";

import { useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Grid3x3, X, ArrowRight } from "lucide-react";
import type { Cluster, NeuralGraph } from "./types";

interface DependencyMatrixProps {
  graph: NeuralGraph;
  open: boolean;
  onClose: () => void;
  /** called when a cell is clicked: highlights all synapses from→to between the two clusters */
  onCellClick?: (fromClusterId: string, toClusterId: string) => void;
  /** the currently highlighted cluster pair (for visual feedback) */
  highlightedPair?: { from: string; to: string } | null;
  /** called when a row/column header is clicked: isolates that cluster */
  onHeaderClick?: (clusterId: string) => void;
}

interface FlowKey {
  from: string;
  to: string;
  count: number;
}

/**
 * A compact heatmap grid showing import counts between all cluster pairs.
 * Rows = source cluster (importer), columns = target cluster (imported).
 * Cell intensity = count / maxCount. Diagonal is hidden (same-cluster imports).
 * Hovering a cell shows the exact count + direction.
 */
export default function DependencyMatrix({ graph, open, onClose, onCellClick, highlightedPair, onHeaderClick }: DependencyMatrixProps) {
  const { flow, maxCount, clusterList } = useMemo(() => {
    const flowMap = new Map<string, FlowKey>();
    for (const s of graph.synapses) {
      const na = graph.neurons[s.source];
      const nb = graph.neurons[s.target];
      if (!na || !nb || na.cluster === nb.cluster) continue;
      const key = `${na.cluster}->${nb.cluster}`;
      const existing = flowMap.get(key);
      if (existing) existing.count++;
      else flowMap.set(key, { from: na.cluster, to: nb.cluster, count: 1 });
    }
    const flowArr = Array.from(flowMap.values());
    const max = Math.max(1, ...flowArr.map((f) => f.count));
    const clusters = graph.clusters.filter((c) =>
      graph.neurons.some((n) => n.cluster === c.id && n.kind !== "virtual")
    );
    return { flow: flowMap, maxCount: max, clusterList: clusters };
  }, [graph]);

  const clusterColor = useMemo(() => {
    const m = new Map<string, string>();
    graph.clusters.forEach((c: Cluster) => m.set(c.id, c.color));
    return m;
  }, [graph.clusters]);

  const getCount = (from: string, to: string): number => {
    if (from === to) return 0;
    return flow.get(`${from}->${to}`)?.count ?? 0;
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          className="pointer-events-auto absolute left-1/2 top-1/2 z-40 -translate-x-1/2 -translate-y-1/2 w-[440px] max-w-[90vw] rounded-xl border border-white/15 bg-[#0a0718]/95 p-4 shadow-2xl backdrop-blur-xl"
        >
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-sm font-semibold text-white">
              <Grid3x3 className="h-4 w-4 text-violet-300" />
              Dependency Matrix
            </div>
            <button
              onClick={onClose}
              className="rounded-md p-1 text-white/50 transition hover:bg-white/10 hover:text-white"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <p className="mt-1 text-[10px] text-white/45">
            Rows = importer, columns = imported. Cell intensity = import count.
            Diagonal hidden (same-cluster).
          </p>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="sticky left-0 z-10 bg-[#0a0718] p-1 text-[9px] font-medium text-white/40"></th>
                  {clusterList.map((c) => (
                    <th key={c.id} className="p-1 text-center">
                      <button
                        onClick={() => onHeaderClick?.(c.id)}
                        className="group flex flex-col items-center gap-0.5 rounded p-0.5 transition hover:bg-white/5"
                        title={`Isolate ${c.label}`}
                      >
                        <div
                          className="mx-auto h-2 w-2 rounded-full transition group-hover:scale-125"
                          style={{ background: c.color, boxShadow: `0 0 4px ${c.color}` }}
                        />
                        <div className="text-[8px] text-white/50 transition group-hover:text-white/80">
                          {c.domain.split(" ")[0]}
                        </div>
                      </button>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {clusterList.map((rowCluster) => (
                  <tr key={rowCluster.id}>
                    <td className="sticky left-0 z-10 bg-[#0a0718] p-1 pr-2 text-right">
                      <button
                        onClick={() => onHeaderClick?.(rowCluster.id)}
                        className="group flex items-center justify-end gap-1 rounded p-0.5 transition hover:bg-white/5"
                        title={`Isolate ${rowCluster.label}`}
                      >
                        <span className="text-[8px] text-white/50 transition group-hover:text-white/80">
                          {rowCluster.domain.split(" ")[0]}
                        </span>
                        <div
                          className="h-2 w-2 rounded-full transition group-hover:scale-125"
                          style={{
                            background: rowCluster.color,
                            boxShadow: `0 0 4px ${rowCluster.color}`,
                          }}
                        />
                      </button>
                    </td>
                    {clusterList.map((colCluster) => {
                      const count = getCount(rowCluster.id, colCluster.id);
                      const isDiagonal = rowCluster.id === colCluster.id;
                      const intensity = count / maxCount;
                      const color = clusterColor.get(colCluster.id) ?? "#a855f7";
                      const isHighlighted =
                        highlightedPair?.from === rowCluster.id &&
                        highlightedPair?.to === colCluster.id;
                      return (
                        <td key={colCluster.id} className="p-0.5">
                          <button
                            disabled={isDiagonal || count === 0}
                            onClick={() => {
                              if (!isDiagonal && count > 0 && onCellClick) {
                                onCellClick(rowCluster.id, colCluster.id);
                              }
                            }}
                            className="group relative flex h-7 w-7 items-center justify-center rounded text-[10px] font-mono font-semibold tabular-nums transition disabled:cursor-default enabled:hover:scale-110"
                            style={{
                              background: isDiagonal
                                ? "rgba(255,255,255,0.02)"
                                : isHighlighted
                                ? `${color}80`
                                : count > 0
                                ? `${color}${Math.round(intensity * 200 + 30)
                                    .toString(16)
                                    .padStart(2, "0")}`
                                : "rgba(255,255,255,0.03)",
                              color: count > 0 ? "#fff" : "rgba(255,255,255,0.2)",
                              border: isDiagonal
                                ? "1px dashed rgba(255,255,255,0.05)"
                                : isHighlighted
                                ? `2px solid #ffffff`
                                : count > 0
                                ? `1px solid ${color}40`
                                : "1px solid rgba(255,255,255,0.05)",
                              boxShadow: isHighlighted
                                ? `0 0 12px ${color}`
                                : undefined,
                            }}
                          >
                            {isDiagonal ? "·" : count > 0 ? count : ""}
                            {!isDiagonal && count > 0 && (
                              <span className="pointer-events-none absolute -top-7 left-1/2 z-20 hidden -translate-x-1/2 whitespace-nowrap rounded border border-white/15 bg-[#0a0718] px-1.5 py-0.5 text-[9px] text-white group-hover:block">
                                {rowCluster.domain.split(" ")[0]}
                                <ArrowRight className="mx-0.5 inline h-2 w-2" />
                                {colCluster.domain.split(" ")[0]}: {count}
                              </span>
                            )}
                          </button>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-3 flex items-center justify-between text-[9px] text-white/40">
            <span>max: {maxCount} imports</span>
            <div className="flex items-center gap-1.5">
              <span>low</span>
              <div className="h-2 w-16 rounded-full bg-gradient-to-r from-white/5 to-violet-500" />
              <span>high</span>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
