// Shared types for the Codebase Brain visualization.
// A "NeuralGraph" is the full living-brain model: clusters (brain regions),
// neurons (files) and synapses (import edges between files).

export type ClusterId = string;

export interface Cluster {
  id: ClusterId;
  /** Human label, e.g. "Visual Cortex" */
  label: string;
  /** Anatomical codebase area this region represents, e.g. "UI Components" */
  domain: string;
  /** Hex color used for the cluster's neurons and synapses */
  color: string;
  /** Short biological description shown in the legend / info panel */
  anatomy: string;
  /** Position weight inside the brain silhouette, [0..1] x and y */
  anchor: { x: number; y: number };
  /** Relative radius weight of the cluster blob, 0.5..1.4 */
  weight: number;
}

export interface Neuron {
  id: string;
  /** File path relative to project root, e.g. "src/components/ui/button.tsx" */
  path: string;
  /** Short display name, e.g. "button.tsx" */
  name: string;
  /** Owning cluster id */
  cluster: ClusterId;
  /** Lines of code (file length, best-effort) */
  loc: number;
  /** Number of imports this file makes (outgoing synapses) */
  imports: number;
  /** Number of files that import this file (incoming synapses) */
  importedBy: number;
  /** Quick semantic tag, e.g. "component" | "hook" | "api" | "route" | "config" | "schema" | "lib" */
  kind: string;
  /** ISO timestamp of the last git commit touching this file (or null). */
  lastCommit?: string | null;
  /** True if this neuron participates in a circular import chain. */
  circular?: boolean;
}

export interface Synapse {
  /** Index into neurons[] for the source (importer) */
  source: number;
  /** Index into neurons[] for the target (imported) */
  target: number;
  /** Weight 0..1, currently 1 for direct import, smaller for transitive */
  weight: number;
}

export interface BrainLayout {
  /** Computed center of the cluster in canvas coordinates (already in px) */
  centers: Record<ClusterId, { x: number; y: number; r: number }>;
  /** Computed neuron positions (px). Index aligns with neurons[] */
  neurons: { x: number; y: number; r: number; phase: number }[];
  /** Synapses with pre-computed bezier control points for organic curves */
  synapses: Synapse[];
}

export interface NeuralGraph {
  clusters: Cluster[];
  neurons: Neuron[];
  synapses: Synapse[];
  stats: {
    files: number;
    edges: number;
    clusters: number;
    avgDegree: number;
    /** number of neurons participating in circular import chains */
    circularCount: number;
  };
}

/**
 * Result of a shortest-path search between two neurons (BFS over synapses).
 * `path` is an ordered list of neuron indices from source to target (inclusive).
 * Empty if no path exists.
 */
export interface PathResult {
  path: number[];
  /** number of hops (path.length - 1), or -1 if unreachable */
  hops: number;
}

/** Camera command — emitted by the parent page (e.g. via keyboard shortcuts,
 * breadcrumb clicks or cluster-focus actions) and consumed by BrainCanvas to
 * animate the pan/zoom camera. `nonce` changes every emit so the canvas can
 * detect a new command even if the payload is identical to the previous one.
 */
export type CameraCommand =
  | { type: "reset"; nonce: number }
  | { type: "focus-cluster"; clusterId: string; nonce: number }
  | { type: "focus-neuron"; neuronId: string; nonce: number };

/** Navigation command for arrow-key neuron traversal. */
export type NavigateCommand = {
  direction: "up" | "down" | "left" | "right";
  nonce: number;
};

/** Current camera state, reported back to the parent for the mini-map. */
export interface CameraState {
  panX: number;
  panY: number;
  zoom: number;
}
