"use client";

import { motion } from "framer-motion";
import {
  Crosshair,
  Search,
  Sparkles,
  Waypoints,
  Type,
  MousePointerClick,
  Layers,
  Zap,
  Focus,
  X,
  Flame,
  GitBranch,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { Cluster } from "./types";

interface ControlPanelProps {
  query: string;
  onQuery: (q: string) => void;
  searchInputRef?: React.RefObject<HTMLInputElement | null>;
  showSynapses: boolean;
  onShowSynapses: (v: boolean) => void;
  showLabels: boolean;
  onShowLabels: (v: boolean) => void;
  showFiring: boolean;
  onShowFiring: (v: boolean) => void;
  parallax: boolean;
  onParallax: (v: boolean) => void;
  showGitHeat: boolean;
  onShowGitHeat: (v: boolean) => void;
  showRegionFlow: boolean;
  onShowRegionFlow: (v: boolean) => void;
  showOrbital: boolean;
  onShowOrbital: (v: boolean) => void;
  useForceLayout: boolean;
  onUseForceLayout: (v: boolean) => void;
  audioEnabled: boolean;
  onAudioEnabled: (v: boolean) => void;
  clusters: Cluster[];
  visibleClusters: Set<string>;
  onToggleCluster: (id: string) => void;
  onShowAll: () => void;
  onResetView: () => void;
  clusterCounts: Record<string, number>;
  clusterLocs: Record<string, number>;
  clusterFlow: Record<string, { to: string; count: number }[]>;
  focusClusterId?: string | null;
  onFocusCluster?: (id: string) => void;
}

export default function ControlPanel({
  query,
  onQuery,
  searchInputRef,
  showSynapses,
  onShowSynapses,
  showLabels,
  onShowLabels,
  showFiring,
  onShowFiring,
  parallax,
  onParallax,
  showGitHeat,
  onShowGitHeat,
  showRegionFlow,
  onShowRegionFlow,
  showOrbital,
  onShowOrbital,
  useForceLayout,
  onUseForceLayout,
  audioEnabled,
  onAudioEnabled,
  clusters,
  visibleClusters,
  onToggleCluster,
  onShowAll,
  onResetView,
  clusterCounts,
  clusterLocs,
  clusterFlow,
  focusClusterId,
  onFocusCluster,
}: ControlPanelProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -24 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
      className="pointer-events-auto absolute left-3 top-3 z-30 flex max-h-[calc(100%-1.5rem)] w-[280px] flex-col gap-3 rounded-xl border border-white/10 bg-[#0a0718]/85 p-3 shadow-2xl backdrop-blur-xl"
    >
      {/* Search */}
      <div className="relative">
        <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-white/40" />
        <Input
          ref={searchInputRef}
          value={query}
          onChange={(e) => onQuery(e.target.value)}
          placeholder="Find a neuron…"
          className="h-8 border-white/10 bg-white/5 pl-8 pr-7 text-xs text-white placeholder:text-white/30 focus-visible:ring-violet-400/40"
        />
        {query && (
          <button
            onClick={() => onQuery("")}
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-white/40 transition hover:bg-white/10 hover:text-white"
            aria-label="Clear search"
          >
            <X className="h-3 w-3" />
          </button>
        )}
      </div>

      {/* Toggles */}
      <div className="grid grid-cols-2 gap-x-3 gap-y-2">
        <ToggleRow
          label="Synapses"
          icon={<Waypoints className="h-3.5 w-3.5" />}
          checked={showSynapses}
          onChecked={onShowSynapses}
        />
        <ToggleRow
          label="Labels"
          icon={<Type className="h-3.5 w-3.5" />}
          checked={showLabels}
          onChecked={onShowLabels}
        />
        <ToggleRow
          label="Firing"
          icon={<Zap className="h-3.5 w-3.5" />}
          checked={showFiring}
          onChecked={onShowFiring}
        />
        <ToggleRow
          label="Parallax"
          icon={<MousePointerClick className="h-3.5 w-3.5" />}
          checked={parallax}
          onChecked={onParallax}
        />
        <ToggleRow
          label="Git Heat"
          icon={<Flame className="h-3.5 w-3.5" />}
          checked={showGitHeat}
          onChecked={onShowGitHeat}
        />
        <ToggleRow
          label="Cycles"
          icon={<GitBranch className="h-3.5 w-3.5" />}
          checked={true}
          onChecked={() => {}}
          disabled
        />
        <ToggleRow
          label="Region Flow"
          icon={<Waypoints className="h-3.5 w-3.5" />}
          checked={showRegionFlow}
          onChecked={onShowRegionFlow}
        />
        <ToggleRow
          label="Orbital"
          icon={<Focus className="h-3.5 w-3.5" />}
          checked={showOrbital}
          onChecked={onShowOrbital}
        />
        <ToggleRow
          label="Force Layout"
          icon={<Crosshair className="h-3.5 w-3.5" />}
          checked={useForceLayout}
          onChecked={onUseForceLayout}
        />
        <ToggleRow
          label="Audio"
          icon={<Zap className="h-3.5 w-3.5" />}
          checked={audioEnabled}
          onChecked={onAudioEnabled}
        />
      </div>

      <Separator className="bg-white/10" />

      {/* Cluster filter */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-white/50">
          <Layers className="h-3 w-3" />
          Brain Regions
        </div>
        <button
          onClick={onShowAll}
          className="text-[10px] font-medium text-violet-300 transition hover:text-violet-200"
        >
          show all
        </button>
      </div>
      <ScrollArea className="max-h-[260px] pr-1">
        <ul className="space-y-1">
          {clusters.map((c) => {
            const visible = visibleClusters.has(c.id);
            const count = clusterCounts[c.id] ?? 0;
            const loc = clusterLocs[c.id] ?? 0;
            const maxLoc = Math.max(1, ...Object.values(clusterLocs));
            const locPct = Math.round((loc / maxLoc) * 100);
            const isFocused = focusClusterId === c.id;
            return (
              <li key={c.id} className="group relative">
                <button
                  onClick={() => onToggleCluster(c.id)}
                  className={`flex w-full items-center gap-2 rounded-lg border px-2 py-1.5 text-left transition ${
                    visible
                      ? isFocused
                        ? "border-white/30 bg-white/10"
                        : "border-white/15 bg-white/5 hover:bg-white/10"
                      : "border-white/5 bg-transparent opacity-50 hover:opacity-80"
                  }`}
                >
                  <span
                    className="inline-block h-2.5 w-2.5 shrink-0 rounded-full"
                    style={{
                      background: c.color,
                      boxShadow: visible ? `0 0 8px ${c.color}` : "none",
                    }}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[11px] font-medium text-white">
                      {c.label}
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="truncate text-[10px] text-white/40">{c.domain}</span>
                      {loc > 0 && (
                        <span className="ml-auto h-1 w-8 shrink-0 overflow-hidden rounded-full bg-white/10">
                          <span
                            className="block h-full rounded-full transition-all"
                            style={{ width: `${locPct}%`, background: c.color }}
                          />
                        </span>
                      )}
                    </div>
                  </div>
                  <span className="rounded-full bg-white/10 px-1.5 py-px font-mono text-[9px] text-white/60">
                    {count}
                  </span>
                </button>
                {/* Focus button — appears on hover when visible */}
                {visible && onFocusCluster && !isFocused && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onFocusCluster?.(c.id);
                    }}
                    className="absolute right-7 top-1/2 -translate-y-1/2 rounded p-0.5 text-white/40 opacity-0 transition hover:bg-white/15 hover:text-white group-hover:opacity-100"
                    title={`Focus ${c.label}`}
                    aria-label={`Focus ${c.label}`}
                  >
                    <Focus className="h-3 w-3" />
                  </button>
                )}
                {isFocused && (
                  <span
                    className="absolute right-7 top-1/2 -translate-y-1/2 rounded px-1 py-px text-[8px] font-bold uppercase tracking-wider"
                    style={{ background: `${c.color}22`, color: c.color }}
                  >
                    in view
                  </span>
                )}
                {/* Mini dependency chart: top-3 import targets */}
                {visible && (clusterFlow[c.id]?.length ?? 0) > 0 && (
                  <div className="flex items-center gap-1 px-2 pb-1 pt-0.5">
                    {clusterFlow[c.id]!.slice(0, 3).map((f, fi) => {
                      const targetCluster = clusters.find((cc) => cc.id === f.to);
                      const maxFlow = Math.max(...(clusterFlow[c.id] ?? []).map((x) => x.count));
                      const pct = Math.round((f.count / maxFlow) * 100);
                      return (
                        <div
                          key={fi}
                          className="flex items-center gap-0.5"
                          title={`${f.count} imports → ${targetCluster?.label ?? f.to}`}
                        >
                          <div className="h-1 w-6 overflow-hidden rounded-full bg-white/10">
                            <div
                              className="h-full rounded-full"
                              style={{
                                width: `${pct}%`,
                                background: targetCluster?.color ?? c.color,
                              }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      </ScrollArea>

      <Separator className="bg-white/10" />

      {/* Action buttons */}
      <div className="flex items-center gap-2">
        <button
          onClick={onResetView}
          className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-2 py-1.5 text-[11px] font-medium text-white/80 transition hover:bg-white/10 hover:text-white"
        >
          <Crosshair className="h-3.5 w-3.5" />
          Reset view
        </button>
        <button
          onClick={() => onShowFiring(!showFiring)}
          className={`flex items-center justify-center gap-1.5 rounded-lg border px-2 py-1.5 text-[11px] font-medium transition ${
            showFiring
              ? "border-cyan-400/40 bg-cyan-400/10 text-cyan-200"
              : "border-white/15 bg-white/5 text-white/80 hover:bg-white/10"
          }`}
          title="Toggle live firing"
        >
          <Sparkles className="h-3.5 w-3.5" />
        </button>
      </div>
    </motion.div>
  );
}

function ToggleRow({
  label,
  icon,
  checked,
  onChecked,
  disabled,
}: {
  label: string;
  icon: React.ReactNode;
  checked: boolean;
  onChecked: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <label
      className={`flex items-center justify-between rounded-lg border border-white/10 bg-white/5 px-2 py-1.5 transition ${
        disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer hover:bg-white/10"
      }`}
    >
      <div className="flex items-center gap-1.5 text-[11px] font-medium text-white/70">
        <span className="text-white/40">{icon}</span>
        {label}
      </div>
      <Switch
        checked={checked}
        onCheckedChange={onChecked}
        disabled={disabled}
        className="h-4 w-7 data-[state=checked]:bg-violet-500"
      />
    </label>
  );
}
