"use client";

import { useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Clock, Flame, X } from "lucide-react";
import type { Cluster, NeuralGraph, Neuron } from "./types";

interface RecentlyChangedProps {
  graph: NeuralGraph | null;
  open: boolean;
  onClose: () => void;
  onSelectNeuron: (n: Neuron) => void;
}

interface RankedNeuron {
  neuron: Neuron;
  ts: number;
  ageDays: number;
}

/**
 * A slide-in side panel (right side, below the InfoPanel) listing the most
 * recently-committed files. Requires git-activity data (neuron.lastCommit).
 * Clicking a row selects that neuron. Shows top 12 files sorted by commit
 * recency, each with a relative-time label and a colored heat dot.
 */
export default function RecentlyChanged({
  graph,
  open,
  onClose,
  onSelectNeuron,
}: RecentlyChangedProps) {
  const ranked = useMemo<RankedNeuron[]>(() => {
    if (!graph) return [];
    const now = Date.now();
    const list: RankedNeuron[] = [];
    for (const n of graph.neurons) {
      if (n.kind === "virtual" || !n.lastCommit) continue;
      const ts = Date.parse(n.lastCommit);
      if (!Number.isFinite(ts)) continue;
      list.push({ neuron: n, ts, ageDays: (now - ts) / 86400000 });
    }
    list.sort((a, b) => b.ts - a.ts);
    return list.slice(0, 12);
  }, [graph]);

  const clusterColor = useMemo(() => {
    const m = new Map<string, string>();
    graph?.clusters.forEach((c: Cluster) => m.set(c.id, c.color));
    return m;
  }, [graph]);

  return (
    <AnimatePresence>
      {open && graph && (
        <motion.div
          initial={{ opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 24 }}
          transition={{ duration: 0.25, ease: "easeOut" }}
          className="pointer-events-auto absolute right-3 top-[calc(100%-560px)] z-30 flex max-h-[420px] w-[280px] flex-col gap-2 rounded-xl border border-white/10 bg-[#0a0718]/85 p-3 shadow-2xl backdrop-blur-xl"
          style={{ top: "auto", bottom: 60 }}
        >
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-amber-300">
              <Flame className="h-3 w-3" />
              Recently Changed
            </div>
            <button
              onClick={onClose}
              className="rounded-md p-1 text-white/50 transition hover:bg-white/10 hover:text-white"
              aria-label="Close"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
          <div className="text-[10px] text-white/40">
            Last 12 files touched by git commits
          </div>
          <div className="min-h-0 flex-1 overflow-hidden">
            <ul className="space-y-0.5">
              {ranked.length === 0 && (
                <li className="px-2 py-3 text-[11px] italic text-white/30">
                  no git history available
                </li>
              )}
              {ranked.map(({ neuron, ageDays }) => {
                const color = clusterColor.get(neuron.cluster) ?? "#a855f7";
                const heat = Math.max(0, 1 - ageDays / 30);
                return (
                  <li key={neuron.id}>
                    <button
                      onClick={() => onSelectNeuron(neuron)}
                      className="flex w-full items-center gap-2 truncate rounded-md px-2 py-1 text-left text-[11px] text-white/70 transition hover:bg-white/10 hover:text-white"
                    >
                      <span
                        className="inline-block h-2 w-2 shrink-0 rounded-full"
                        style={{
                          background: color,
                          boxShadow: `0 0 ${4 + heat * 8}px ${color}`,
                          opacity: 0.4 + heat * 0.6,
                        }}
                      />
                      <span className="min-w-0 flex-1 truncate">{neuron.name}</span>
                      <Clock className="h-3 w-3 shrink-0 text-white/30" />
                      <span className="shrink-0 font-mono text-[9px] text-white/40">
                        {formatAge(ageDays)}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function formatAge(days: number): string {
  if (days < 1 / 24) return "now";
  if (days < 1) return `${Math.floor(days * 24)}h`;
  if (days < 30) return `${Math.floor(days)}d`;
  if (days < 365) return `${Math.floor(days / 30)}mo`;
  return `${Math.floor(days / 365)}y`;
}
