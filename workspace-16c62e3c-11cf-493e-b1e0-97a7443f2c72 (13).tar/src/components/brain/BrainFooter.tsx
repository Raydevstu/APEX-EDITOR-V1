"use client";

import { useEffect, useMemo, useRef } from "react";
import { GitBranch, Network, Cpu, Zap, HeartPulse, Gauge, AlertTriangle, GitCommit } from "lucide-react";
import type { Cluster, NeuralGraph } from "./types";

interface BrainFooterProps {
  graph: NeuralGraph | null;
  /** rolling activity series 0..1 */
  activity: number;
  visibleNeurons: number;
}

const MAX_SAMPLES = 90;

/**
 * Compute a synthetic "Structural Integrity" health score (0..100).
 * Heuristic: high when the graph is balanced (avg degree near 1-2), low when
 * it's overly coupled (high degree) or completely sparse. Adds a small bonus
 * for more regions being populated (diversity) and penalizes very high
 * single-file fan-in.
 */
function computeHealth(g: NeuralGraph | null): number {
  if (!g) return 100;
  const avg = g.stats.avgDegree;
  // ideal avg degree ~ 1.0..1.6
  let score = 100;
  if (avg > 2.5) score -= (avg - 2.5) * 18;
  else if (avg < 0.4) score -= (0.4 - avg) * 30;
  // diversity bonus: more regions populated = healthier
  const populatedRegions = g.clusters.filter((c) =>
    g.neurons.some((n) => n.cluster === c.id && n.kind !== "virtual")
  ).length;
  score += (populatedRegions - g.stats.clusters * 0.7) * 4;
  // circular dependencies are a strong health penalty (8 pts each, capped)
  const circular = g.stats.circularCount ?? 0;
  score -= Math.min(40, circular * 8);
  // cap
  return Math.max(0, Math.min(100, Math.round(score)));
}

/** Cognitive load: total LOC of visible neurons (proxy for complexity). */
function computeCognitiveLoad(g: NeuralGraph | null): number {
  if (!g) return 0;
  return g.neurons.reduce((s, n) => (n.kind === "virtual" ? s : s + n.loc), 0);
}

/**
 * Compute per-cluster commit activity buckets (last 30 days → 8 buckets).
 * Returns a map of clusterId → number[] (8 values, 0..maxCommits).
 */
function computeClusterCommits(g: NeuralGraph | null): Map<string, number[]> {
  const result = new Map<string, number[]>();
  if (!g) return result;
  const now = Date.now();
  const BUCKETS = 8;
  const DAY_RANGE = 30;
  const bucketMs = (DAY_RANGE * 86400000) / BUCKETS;
  for (const c of g.clusters) {
    result.set(c.id, new Array(BUCKETS).fill(0));
  }
  for (const n of g.neurons) {
    if (n.kind === "virtual" || !n.lastCommit) continue;
    const ts = Date.parse(n.lastCommit);
    if (!Number.isFinite(ts)) continue;
    const ageMs = now - ts;
    if (ageMs > DAY_RANGE * 86400000) continue;
    const bucketIdx = Math.min(BUCKETS - 1, Math.floor(ageMs / bucketMs));
    const arr = result.get(n.cluster);
    if (arr) arr[bucketIdx]++;
  }
  return result;
}

export default function BrainFooter({
  graph,
  activity,
  visibleNeurons,
}: BrainFooterProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const samplesRef = useRef<number[]>([]);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = 240;
    const h = 36;
    c.width = w * dpr;
    c.height = h * dpr;
    c.style.width = w + "px";
    c.style.height = h + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    samplesRef.current.push(activity);
    if (samplesRef.current.length > MAX_SAMPLES) samplesRef.current.shift();
    draw(ctx, samplesRef.current, w, h);
  }, [activity]);

  const stats = graph?.stats;
  const health = computeHealth(graph);
  const cognitiveLoad = computeCognitiveLoad(graph);
  const healthColor =
    health >= 80 ? "#34d399" : health >= 60 ? "#fbbf24" : "#fb7185";
  const clusterCommits = useMemo(() => computeClusterCommits(graph), [graph]);
  const maxCommit = useMemo(() => {
    let m = 1;
    for (const arr of clusterCommits.values()) {
      for (const v of arr) if (v > m) m = v;
    }
    return m;
  }, [clusterCommits]);

  return (
    <footer className="z-30 mt-auto border-t border-white/10 bg-gradient-to-b from-[#070418]/95 to-[#02010a]/95 backdrop-blur-xl">
      <div className="mx-auto flex max-w-[1600px] flex-wrap items-center justify-between gap-x-5 gap-y-2 px-4 py-2.5 text-white sm:px-6">
        <div className="flex items-center gap-4 sm:gap-6">
          <Stat
            icon={<Network className="h-3.5 w-3.5" />}
            label="neurons"
            value={stats?.files ?? 0}
            color="#a855f7"
          />
          <Stat
            icon={<GitBranch className="h-3.5 w-3.5" />}
            label="synapses"
            value={stats?.edges ?? 0}
            color="#22d3ee"
          />
          <Stat
            icon={<Cpu className="h-3.5 w-3.5" />}
            label="regions"
            value={stats?.clusters ?? 0}
            color="#34d399"
          />
          <Stat
            icon={<Zap className="h-3.5 w-3.5" />}
            label="avg degree"
            value={stats?.avgDegree ?? 0}
            color="#fb7185"
            decimals={2}
          />
          {/* Health Score with mini gauge */}
          <HealthGauge
            value={health}
            color={healthColor}
          />
          {/* Cognitive Load */}
          <Stat
            icon={<Gauge className="h-3.5 w-3.5" />}
            label="cognitive load"
            value={cognitiveLoad}
            color="#d946ef"
            suffix=" LOC"
          />
          {/* Circular dependencies */}
          <Stat
            icon={<AlertTriangle className="h-3.5 w-3.5" />}
            label="circular"
            value={stats?.circularCount ?? 0}
            color={(stats?.circularCount ?? 0) > 0 ? "#fb7185" : "#34d399"}
          />
          {/* Per-cluster commit sparklines (last 30 days) */}
          {graph && maxCommit > 0 && (
            <div className="hidden items-center gap-1 lg:flex" title="Git commit frequency per cluster (last 30 days)">
              <GitCommit className="h-3 w-3 text-white/30" />
              {graph.clusters.map((c) => {
                const commits = clusterCommits.get(c.id) ?? [];
                const total = commits.reduce((s, v) => s + v, 0);
                if (total === 0) return null;
                return (
                  <ClusterCommitSparkline
                    key={c.id}
                    cluster={c}
                    commits={commits}
                    maxCommit={maxCommit}
                  />
                );
              })}
            </div>
          )}
        </div>

        <div className="hidden items-center gap-3 md:flex">
          <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-white/50">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400/60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
            brain activity
          </div>
          <canvas
            ref={canvasRef}
            className="rounded bg-black/30 ring-1 ring-white/5"
            aria-hidden
          />
          <span className="font-mono text-[10px] tabular-nums text-white/60">
            {visibleNeurons} active
          </span>
        </div>
      </div>
    </footer>
  );
}

function HealthGauge({ value, color }: { value: number; color: string }) {
  const radius = 11;
  const circ = 2 * Math.PI * radius;
  const offset = circ - (value / 100) * circ;
  return (
    <div className="flex items-center gap-2" title="Structural Integrity Score">
      <span
        className="relative flex h-7 w-7 items-center justify-center"
        style={{ color }}
      >
        <svg width="28" height="28" viewBox="0 0 28 28" className="-rotate-90">
          <circle
            cx="14"
            cy="14"
            r={radius}
            fill="none"
            stroke="rgba(255,255,255,0.1)"
            strokeWidth="2.5"
          />
          <circle
            cx="14"
            cy="14"
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeDasharray={circ}
            strokeDashoffset={offset}
            style={{
              transition: "stroke-dashoffset 0.6s ease, stroke 0.6s ease",
              filter: `drop-shadow(0 0 4px ${color}88)`,
            }}
          />
        </svg>
        <HeartPulse className="absolute h-3 w-3 opacity-80" />
      </span>
      <div className="leading-none">
        <div className="font-mono text-base font-semibold tabular-nums text-white">
          {value}
          <span className="text-xs text-white/40">%</span>
        </div>
        <div className="mt-0.5 text-[9px] uppercase tracking-[0.15em] text-white/40">
          integrity
        </div>
      </div>
    </div>
  );
}

function Stat({
  icon,
  label,
  value,
  color,
  decimals = 0,
  suffix = "",
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: string;
  decimals?: number;
  suffix?: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <span
        className="flex h-7 w-7 items-center justify-center rounded-md border"
        style={{
          color,
          borderColor: `${color}33`,
          background: `${color}14`,
          boxShadow: `inset 0 0 8px ${color}22`,
        }}
      >
        {icon}
      </span>
      <div className="leading-none">
        <div className="font-mono text-base font-semibold tabular-nums text-white">
          {decimals > 0 ? value.toFixed(decimals) : value}
          {suffix && <span className="text-[10px] text-white/40">{suffix}</span>}
        </div>
        <div className="mt-0.5 text-[9px] uppercase tracking-[0.15em] text-white/40">{label}</div>
      </div>
    </div>
  );
}

function draw(ctx: CanvasRenderingContext2D, samples: number[], w: number, h: number) {
  ctx.clearRect(0, 0, w, h);
  if (samples.length < 2) return;
  // baseline grid
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.lineWidth = 1;
  for (let i = 1; i < 4; i++) {
    const y = (h * i) / 4;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }

  // area
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, "rgba(52,211,153,0.55)");
  grad.addColorStop(1, "rgba(52,211,153,0)");
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.moveTo(0, h - 2);
  for (let i = 0; i < samples.length; i++) {
    const x = (i / (MAX_SAMPLES - 1)) * w;
    const y = h - 2 - samples[i] * (h - 4);
    ctx.lineTo(x, y);
  }
  ctx.lineTo((samples.length - 1) / (MAX_SAMPLES - 1) * w, h - 2);
  ctx.closePath();
  ctx.fill();

  // line
  ctx.strokeStyle = "#34d399";
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  for (let i = 0; i < samples.length; i++) {
    const x = (i / (MAX_SAMPLES - 1)) * w;
    const y = h - 2 - samples[i] * (h - 4);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // current dot + glow
  const lastX = (samples.length - 1) / (MAX_SAMPLES - 1) * w;
  const lastY = h - 2 - samples[samples.length - 1] * (h - 4);
  const g2 = ctx.createRadialGradient(lastX, lastY, 0, lastX, lastY, 6);
  g2.addColorStop(0, "rgba(52,211,153,0.8)");
  g2.addColorStop(1, "rgba(52,211,153,0)");
  ctx.fillStyle = g2;
  ctx.beginPath();
  ctx.arc(lastX, lastY, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.arc(lastX, lastY, 1.8, 0, Math.PI * 2);
  ctx.fill();
}

/** Mini per-cluster commit-frequency bar chart (8 bars, last 30 days). */
function ClusterCommitSparkline({
  cluster,
  commits,
  maxCommit,
}: {
  cluster: Cluster;
  commits: number[];
  maxCommit: number;
}) {
  return (
    <div
      className="flex h-7 items-end gap-px"
      title={`${cluster.label}: ${commits.reduce((s, v) => s + v, 0)} commits (30d)`}
    >
      {commits.map((v, i) => {
        const h = Math.max(2, (v / maxCommit) * 22);
        return (
          <div
            key={i}
            className="w-0.5 rounded-t transition-all duration-300"
            style={{
              height: `${h}px`,
              background: v > 0 ? cluster.color : "rgba(255,255,255,0.08)",
              opacity: v > 0 ? 0.4 + (v / maxCommit) * 0.6 : 0.3,
            }}
          />
        );
      })}
    </div>
  );
}
