"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  BrainCircuit,
  Search,
  MousePointerClick,
  Waypoints,
  Grid3x3,
  Keyboard,
  X,
  ChevronRight,
  ChevronLeft,
  Sparkles,
} from "lucide-react";

const TOUR_KEY = "codebase-brain:onboarded:v1";

const STEPS = [
  {
    icon: <BrainCircuit className="h-5 w-5 text-violet-300" />,
    title: "Welcome to Codebase Brain",
    body: "Your codebase rendered as a living brain — clusters are brain regions, neurons are files, and synapses are imports. Watch the firing pulses travel along import edges in real time.",
  },
  {
    icon: <Search className="h-5 w-5 text-cyan-300" />,
    title: "Find any file",
    body: "Type in the search box (or press /) to find a neuron. Matching files glow with a white ring; everything else dims. Synapses between matching files light up as spotlight pathways.",
  },
  {
    icon: <MousePointerClick className="h-5 w-5 text-emerald-300" />,
    title: "Click to explore",
    body: "Click any neuron to see its file details — LOC, imports, incoming dependencies, syntax-highlighted code preview, and git history. Right-click for a radial menu with Focus, Trace, Isolate, and Copy Path actions.",
  },
  {
    icon: <Waypoints className="h-5 w-5 text-amber-300" />,
    title: "Trace & path-find",
    body: "The Trace action fires all of a neuron's synapses as an electrical storm. Shift-click two neurons to find the shortest import path between them — the path animates as an amber line with a traveling pulse.",
  },
  {
    icon: <Grid3x3 className="h-5 w-5 text-fuchsia-300" />,
    title: "Dependency matrix",
    body: "Press M to open the dependency matrix — a heatmap grid showing import counts between all cluster pairs. Click a cell to highlight those synapses on the brain. Click a header to isolate a cluster.",
  },
  {
    icon: <Keyboard className="h-5 w-5 text-rose-300" />,
    title: "Keyboard shortcuts",
    body: "Arrow keys navigate between connected neurons. R resets the view. F/S/L/P/G/O/V/M toggle layers. Esc deselects. Explore the Shortcuts button (bottom-left) for the full list.",
  },
  {
    icon: <Sparkles className="h-5 w-5 text-violet-300" />,
    title: "You're all set",
    body: "The brain is alive — neurons pulse, synapses fire, the vortex swirls. Zoom with scroll, pan by dragging empty space, and let the codebase reveal its architecture. This tour won't show again.",
  },
];

export const REPLAY_TOUR_EVENT = "codebase-brain:replay-tour";

export default function OnboardingTour() {
  // Check localStorage via lazy useState initializer (avoids setState-in-effect).
  // During SSR, window is undefined so the tour stays closed; on the client
  // (after hydration) it opens if the user hasn't been onboarded yet.
  const [open, setOpen] = useState(() => {
    if (typeof window === "undefined") return false;
    try {
      return !window.localStorage.getItem(TOUR_KEY);
    } catch {
      return false;
    }
  });
  const [step, setStep] = useState(0);

  // Listen for the replay event (dispatched by ShortcutsHint)
  useEffect(() => {
    const handler = () => {
      setStep(0);
      setOpen(true);
    };
    window.addEventListener(REPLAY_TOUR_EVENT, handler);
    return () => window.removeEventListener(REPLAY_TOUR_EVENT, handler);
  }, []);

  const handleClose = () => {
    setOpen(false);
    try {
      window.localStorage.setItem(TOUR_KEY, "1");
    } catch {
      // ignore
    }
  };

  const handleNext = () => {
    if (step < STEPS.length - 1) {
      setStep((s) => s + 1);
    } else {
      handleClose();
    }
  };

  const handlePrev = () => {
    if (step > 0) setStep((s) => s - 1);
  };

  const handleSkip = () => {
    handleClose();
  };

  const current = STEPS[step];

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 backdrop-blur-sm"
          onClick={handleSkip}
        >
          <motion.div
            initial={{ scale: 0.92, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.92, y: 20 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-[420px] max-w-[90vw] overflow-hidden rounded-2xl border border-white/15 bg-[#0a0718]/95 shadow-2xl"
          >
            {/* progress bar */}
            <div className="h-1 w-full bg-white/5">
              <motion.div
                className="h-full bg-gradient-to-r from-violet-500 to-fuchsia-500"
                initial={{ width: "0%" }}
                animate={{ width: `${((step + 1) / STEPS.length) * 100}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>

            {/* close button */}
            <button
              onClick={handleSkip}
              className="absolute right-3 top-3 z-10 rounded-md p-1 text-white/40 transition hover:bg-white/10 hover:text-white"
              aria-label="Skip tour"
            >
              <X className="h-4 w-4" />
            </button>

            {/* content */}
            <div className="p-6">
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl border border-white/10 bg-white/5">
                {current.icon}
              </div>
              <h2 className="text-lg font-semibold text-white">{current.title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-white/60">
                {current.body}
              </p>

              {/* step dots */}
              <div className="mt-5 flex items-center gap-1.5">
                {STEPS.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setStep(i)}
                    className={`h-1.5 rounded-full transition-all ${
                      i === step
                        ? "w-6 bg-violet-400"
                        : i < step
                        ? "w-1.5 bg-violet-400/40"
                        : "w-1.5 bg-white/15"
                    }`}
                    aria-label={`Go to step ${i + 1}`}
                  />
                ))}
              </div>

              {/* navigation */}
              <div className="mt-5 flex items-center justify-between">
                <button
                  onClick={handleSkip}
                  className="text-[11px] font-medium text-white/40 transition hover:text-white/70"
                >
                  Skip tour
                </button>
                <div className="flex items-center gap-2">
                  {step > 0 && (
                    <button
                      onClick={handlePrev}
                      className="flex items-center gap-1 rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-[11px] font-medium text-white/70 transition hover:bg-white/10 hover:text-white"
                    >
                      <ChevronLeft className="h-3.5 w-3.5" />
                      Back
                    </button>
                  )}
                  <button
                    onClick={handleNext}
                    className="flex items-center gap-1 rounded-lg bg-violet-500 px-3 py-1.5 text-[11px] font-medium text-white transition hover:bg-violet-400"
                  >
                    {step === STEPS.length - 1 ? "Get started" : "Next"}
                    <ChevronRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
