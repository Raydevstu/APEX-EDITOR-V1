"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Crosshair,
  Focus,
  Crosshair as TraceIcon,
  Layers,
  Copy,
  FileCode2,
  X,
} from "lucide-react";
import type { Cluster, Neuron } from "./types";

export interface RadialMenuAction {
  id: string;
  label: string;
  icon: React.ReactNode;
  /** angle in radians (0 = right, grows clockwise) */
  angle: number;
  color: string;
}

interface RadialMenuProps {
  neuron: Neuron | null;
  cluster?: Cluster;
  /** screen-space coordinates where the menu should open */
  x: number;
  y: number;
  onAction: (action: string, neuron: Neuron) => void;
  onClose: () => void;
}

const RADIUS = 78;

export default function RadialMenu({
  neuron,
  cluster,
  x,
  y,
  onAction,
  onClose,
}: RadialMenuProps) {
  const [hovered, setHovered] = useState<string | null>(null);
  const ref = useRef<HTMLDivElement | null>(null);

  // Close on outside click / Escape
  useEffect(() => {
    if (!neuron) return;
    const onDown = (e: PointerEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("pointerdown", onDown);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("pointerdown", onDown);
      window.removeEventListener("keydown", onKey);
    };
  }, [neuron, onClose]);

  if (!neuron) return null;
  const color = cluster?.color ?? "#a855f7";

  const actions: RadialMenuAction[] = [
    { id: "focus", label: "Focus", icon: <Focus className="h-4 w-4" />, angle: -Math.PI / 2, color: "#a855f7" },
    { id: "trace", label: "Trace", icon: <TraceIcon className="h-4 w-4" />, angle: -Math.PI / 6, color: "#22d3ee" },
    { id: "isolate", label: "Isolate", icon: <Layers className="h-4 w-4" />, angle: Math.PI / 6, color: "#34d399" },
    { id: "copy", label: "Copy path", icon: <Copy className="h-4 w-4" />, angle: Math.PI / 2, color: "#fbbf24" },
  ];

  return (
    <AnimatePresence>
      {neuron && (
        <motion.div
          ref={ref}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="pointer-events-auto absolute z-50"
          style={{ left: x, top: y, transform: "translate(-50%, -50%)" }}
        >
          {/* Center node card */}
          <motion.div
            initial={{ scale: 0.4 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0.4 }}
            transition={{ duration: 0.18, ease: "backOut" }}
            className="relative flex h-[140px] w-[140px] items-center justify-center"
          >
            {/* radial guide ring */}
            <div
              className="absolute inset-0 rounded-full border border-dashed"
              style={{ borderColor: `${color}33` }}
            />
            {/* backdrop */}
            <div className="absolute inset-2 rounded-full border border-white/10 bg-[#0a0718]/95 backdrop-blur-xl shadow-2xl" />
            {/* content */}
            <div className="relative flex max-w-[120px] flex-col items-center text-center">
              <FileCode2 className="h-4 w-4" style={{ color }} />
              <div className="mt-1 truncate text-[11px] font-medium text-white">
                {neuron.name}
              </div>
              <div className="truncate font-mono text-[9px] text-white/40">
                {neuron.loc} LOC
              </div>
            </div>
            {/* close X */}
            <button
              onClick={onClose}
              className="absolute -right-1 -top-1 rounded-full border border-white/20 bg-[#0a0718] p-1 text-white/60 transition hover:border-white/40 hover:text-white"
              aria-label="Close menu"
            >
              <X className="h-3 w-3" />
            </button>
          </motion.div>

          {/* Action wedges */}
          {actions.map((a) => {
            const ax = Math.cos(a.angle) * RADIUS;
            const ay = Math.sin(a.angle) * RADIUS;
            const isHovered = hovered === a.id;
            return (
              <motion.button
                key={a.id}
                initial={{ x: 0, y: 0, opacity: 0, scale: 0.4 }}
                animate={{ x: ax, y: ay, opacity: 1, scale: 1 }}
                exit={{ x: 0, y: 0, opacity: 0, scale: 0.4 }}
                transition={{ duration: 0.18, ease: "backOut" }}
                onMouseEnter={() => setHovered(a.id)}
                onMouseLeave={() => setHovered((h) => (h === a.id ? null : h))}
                onClick={() => onAction(a.id, neuron)}
                className="absolute left-1/2 top-1/2 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center gap-0.5 rounded-full border bg-[#0a0718]/95 backdrop-blur-xl shadow-xl transition"
                style={{
                  borderColor: isHovered ? a.color : "rgba(255,255,255,0.12)",
                  background: isHovered ? `${a.color}1f` : "rgba(10,7,24,0.95)",
                  color: isHovered ? a.color : "rgba(255,255,255,0.8)",
                  boxShadow: isHovered ? `0 0 18px ${a.color}66` : undefined,
                }}
                title={a.label}
              >
                {a.icon}
                <span className="text-[8px] font-medium uppercase tracking-wider">
                  {a.label}
                </span>
              </motion.button>
            );
          })}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
