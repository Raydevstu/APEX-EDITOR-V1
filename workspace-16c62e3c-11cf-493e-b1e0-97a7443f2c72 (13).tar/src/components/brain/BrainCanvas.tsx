"use client";

import { useCallback, useEffect, useMemo, useRef } from "react";
import type {
  BrainLayout,
  CameraCommand,
  CameraState,
  Cluster,
  NavigateCommand,
  NeuralGraph,
  Neuron,
} from "./types";
import { computeLayout, computeForceDirectedLayout } from "@/lib/brain/layout";

interface BrainCanvasProps {
  graph: NeuralGraph;
  visibleClusters: Set<string>;
  showSynapses: boolean;
  showLabels: boolean;
  showFiring: boolean;
  parallax: boolean;
  query: string;
  selectedId: string | null;
  /** neuron ID that should be "traced" (sustained firing of all its synapses) */
  traceNeuronId: string | null;
  /** ordered list of neuron indices forming the highlighted shortest-path (or null) */
  pathHighlight: number[] | null;
  /** whether to render git-recency glow on neurons */
  showGitHeat: boolean;
  /** whether to render cluster-to-cluster dependency flow arrows */
  showRegionFlow: boolean;
  /** whether to render orbital module chips around the vortex core */
  showOrbital: boolean;
  /** whether to use force-directed layout for the focused cluster's neurons */
  useForceLayout: boolean;
  /** currently focused cluster id (triggers force-directed re-layout when changed) */
  focusClusterId: string | null;
  /** optional cluster-pair filter: only highlight synapses between these two clusters */
  flowFilter: { from: string; to: string } | null;
  onSelect: (neuron: Neuron | null) => void;
  onHover: (neuron: Neuron | null) => void;
  onActivity?: (activeCount: number) => void;
  /** imperative camera commands from the parent (reset / focus-cluster / focus-neuron) */
  cameraCommand?: CameraCommand | null;
  /** reports the current camera state back to the parent for the mini-map */
  onCameraChange?: (state: CameraState) => void;
  /** called when the user clicks an empty area inside a cluster (for breadcrumb focus) */
  onFocusCluster?: (clusterId: string) => void;
  /** right-click on a neuron: opens the radial menu */
  onContextMenu?: (neuron: Neuron, screenX: number, screenY: number) => void;
  /** shift-click on a neuron: set as path-finder endpoint */
  onShiftClick?: (neuron: Neuron) => void;
  /** called when an ambient firing pulse spawns (for ambient audio) */
  onAmbientFire?: () => void;
  /** arrow-key navigation command — finds nearest connected neuron in direction */
  navigateCommand?: NavigateCommand | null;
}

interface Star {
  x: number;
  y: number;
  r: number;
  base: number;
  twinkle: number;
  vx: number; // parallax depth factor
}

interface Nebula {
  x: number;
  y: number;
  r: number;
  color: string;
  drift: number;
  phase: number;
}

interface Pulse {
  synapseIdx: number;
  t: number;
  speed: number;
  color: string;
  /** 0 = ambient random fire, 1 = hover-triggered (brighter, faster) */
  intensity: number;
}

interface Shockwave {
  /** canvas-space origin */
  x: number;
  y: number;
  /** current radius */
  r: number;
  /** max radius */
  maxR: number;
  color: string;
  alpha: number;
}

const BG_DEEP = "#02010a";

export default function BrainCanvas({
  graph,
  visibleClusters,
  showSynapses,
  showLabels,
  showFiring,
  parallax,
  query,
  selectedId,
  traceNeuronId,
  pathHighlight,
  showGitHeat,
  showRegionFlow,
  showOrbital,
  useForceLayout,
  focusClusterId,
  flowFilter,
  onSelect,
  onHover,
  onActivity,
  cameraCommand,
  onCameraChange,
  onFocusCluster,
  onContextMenu,
  onShiftClick,
  onAmbientFire,
  navigateCommand,
}: BrainCanvasProps) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const layoutRef = useRef<BrainLayout | null>(null);
  const sizeRef = useRef({ w: 800, h: 600, dpr: 1 });
  const starsRef = useRef<Star[]>([]);
  const nebulaeRef = useRef<Nebula[]>([]);
  const pulsesRef = useRef<Pulse[]>([]);
  const shockwavesRef = useRef<Shockwave[]>([]);
  const parallaxRef = useRef({ x: 0, y: 0, tx: 0, ty: 0 });
  const panRef = useRef({ x: 0, y: 0, dragging: false, lastX: 0, lastY: 0 });
  const zoomRef = useRef(1);
  const lastTsRef = useRef<number>(0);
  const fireAccRef = useRef(0);
  // force-layout animation: stores old + target positions + progress for
  // smooth interpolation from spiral to force-directed over ~1s
  const forceAnimRef = useRef<{
    indices: number[];
    fromX: number[];
    fromY: number[];
    toX: number[];
    toY: number[];
    progress: number; // 0..1
    duration: number; // seconds
  } | null>(null);
  const hoverFireAccRef = useRef(0);
  const activeCountRef = useRef(0);
  const hoveredIdxRef = useRef<number>(-1);
  const selectedIdxRef = useRef<number>(-1);
  // navigation arrow: brief directional indicator from old→new neuron on arrow-key nav
  const navArrowRef = useRef<{
    fromX: number;
    fromY: number;
    toX: number;
    toY: number;
    alpha: number;
  } | null>(null);
  // camera animation target (when set, render loop eases pan/zoom toward it)
  const camAnimRef = useRef<{ tx: number; ty: number; tz: number } | null>(null);
  // last reported camera state (to throttle onCameraChange callbacks)
  const lastCamReportRef = useRef<{ panX: number; panY: number; zoom: number }>({ panX: 0, panY: 0, zoom: 1 });
  const lastCamEmitRef = useRef(0);
  // central particle vortex — galaxy-spiral of ~3000 additive dots
  const vortexRef = useRef<{ x: number; y: number; r: number; theta: number; size: number; hue: number }[]>([]);
  // activation intensity 0..1 — bumps to 1 on Trace/Focus/Select events, decays
  const activationRef = useRef(0);
  // film-grain noise tile (pre-rendered offscreen canvas, tiled each frame)
  const noiseCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // cluster color lookup
  const clusterMap = useMemo(() => {
    const m = new Map<string, Cluster>();
    for (const c of graph.clusters) m.set(c.id, c);
    return m;
  }, [graph.clusters]);

  const colorFor = useCallback(
    (neuronIdx: number) => {
      const n = graph.neurons[neuronIdx];
      return clusterMap.get(n?.cluster)?.color ?? "#a855f7";
    },
    [graph.neurons, clusterMap]
  );

  // mirror props + derived data into a ref so the stable render callback
  // (created once) always reads the latest values. The assignment happens in an
  // effect because refs must not be mutated during render.
  const ctxRef = useRef({
    graph,
    visibleClusters,
    showSynapses,
    showLabels,
    showFiring,
    parallax,
    query,
    selectedId,
    traceNeuronId,
    pathHighlight,
    showGitHeat,
    showRegionFlow,
    showOrbital,
    flowFilter,
    onActivity,
    onCameraChange,
    onFocusCluster,
    onAmbientFire,
    clusterMap,
    colorFor,
  });
  useEffect(() => {
    ctxRef.current = {
      graph,
      visibleClusters,
      showSynapses,
      showLabels,
      showFiring,
      parallax,
      query,
      selectedId,
      traceNeuronId,
      pathHighlight,
      showGitHeat,
      showRegionFlow,
      showOrbital,
      flowFilter,
      onActivity,
      onCameraChange,
      onFocusCluster,
      onAmbientFire,
      clusterMap,
      colorFor,
    };
  });

  // track the trace-neuron index in a ref (read by the render loop)
  const traceIdxRef = useRef<number>(-1);
  useEffect(() => {
    if (!traceNeuronId) {
      traceIdxRef.current = -1;
      return;
    }
    traceIdxRef.current = graph.neurons.findIndex((n) => n.id === traceNeuronId);
  }, [traceNeuronId, graph.neurons]);

  // keep selectedIdx in sync with selectedId; on change, spawn a shockwave
  useEffect(() => {
    const layout = layoutRef.current;
    const prev = selectedIdxRef.current;
    if (selectedId == null) {
      selectedIdxRef.current = -1;
      return;
    }
    const idx = graph.neurons.findIndex((n) => n.id === selectedId);
    selectedIdxRef.current = idx;
    if (idx >= 0 && idx !== prev && layout) {
      const n = layout.neurons[idx];
      if (n) {
        const color = clusterMap.get(graph.neurons[idx].cluster)?.color ?? "#a855f7";
        shockwavesRef.current.push({
          x: n.x,
          y: n.y,
          r: n.r,
          maxR: 60,
          color,
          alpha: 0.9,
        });
      }
    }
  }, [selectedId, graph.neurons, graph.clusters, clusterMap]);

  // react to camera commands (reset / focus-cluster / focus-neuron) — also
  // triggers a brief "activation" flash on focus events for visual feedback.
  useEffect(() => {
    if (!cameraCommand) return;
    const layout = layoutRef.current;
    const { w, h } = sizeRef.current;
    if (!layout || w === 0 || h === 0) return;

    if (cameraCommand.type === "reset") {
      camAnimRef.current = { tx: 0, ty: 0, tz: 1 };
      return;
    }
    if (cameraCommand.type === "focus-cluster") {
      const center = layout.centers[cameraCommand.clusterId];
      if (!center) return;
      // zoom so the cluster radius fills ~40% of the smaller viewport dim
      const targetZoom = Math.max(1.1, Math.min(2.4, (Math.min(w, h) * 0.42) / center.r));
      // pan so the cluster center maps to the viewport center
      const tx = -(center.x - w / 2) * targetZoom;
      const ty = -(center.y - h / 2) * targetZoom;
      camAnimRef.current = { tx, ty, tz: targetZoom };
      activationRef.current = 1; // power-up flash
      return;
    }
    if (cameraCommand.type === "focus-neuron") {
      const idx = graph.neurons.findIndex((n) => n.id === cameraCommand.neuronId);
      const n = idx >= 0 ? layout.neurons[idx] : null;
      if (!n) return;
      const targetZoom = 2.0;
      const tx = -(n.x - w / 2) * targetZoom;
      const ty = -(n.y - h / 2) * targetZoom;
      camAnimRef.current = { tx, ty, tz: targetZoom };
      activationRef.current = 1; // power-up flash
    }
  }, [cameraCommand, graph.neurons]);

  // bump activation when trace mode starts
  useEffect(() => {
    if (traceNeuronId) activationRef.current = 1;
  }, [traceNeuronId]);

  // arrow-key navigation: find the nearest connected neuron in the given
  // direction from the currently selected neuron and select it.
  useEffect(() => {
    if (!navigateCommand) return;
    const layout = layoutRef.current;
    if (!layout) return;
    const selIdx = selectedIdxRef.current;
    if (selIdx < 0) return;
    const selPos = layout.neurons[selIdx];
    if (!selPos) return;

    // collect all neurons connected to the selected one via synapses
    const connected = new Set<number>();
    for (const s of layout.synapses) {
      if (s.source === selIdx) connected.add(s.target);
      if (s.target === selIdx) connected.add(s.source);
    }
    if (connected.size === 0) return;

    // find the nearest connected neuron in the given direction
    let bestIdx = -1;
    let bestScore = -Infinity;
    for (const idx of connected) {
      const pos = layout.neurons[idx];
      if (!pos) continue;
      const dx = pos.x - selPos.x;
      const dy = pos.y - selPos.y;
      // direction dot product: higher = more aligned with the direction
      let dot = 0;
      switch (navigateCommand.direction) {
        case "up": dot = -dy; break;
        case "down": dot = dy; break;
        case "left": dot = -dx; break;
        case "right": dot = dx; break;
      }
      // prefer neurons that are strongly in the direction + not too far
      const dist = Math.hypot(dx, dy) || 1;
      const score = dot / dist; // cosine similarity
      if (score > bestScore) {
        bestScore = score;
        bestIdx = idx;
      }
    }
    if (bestIdx >= 0) {
      const newPos = layout.neurons[bestIdx];
      // set the navigation arrow for visual feedback
      if (newPos) {
        navArrowRef.current = {
          fromX: selPos.x,
          fromY: selPos.y,
          toX: newPos.x,
          toY: newPos.y,
          alpha: 1.0,
        };
      }
      selectedIdxRef.current = bestIdx;
      onSelect(graph.neurons[bestIdx]);
    }
  }, [navigateCommand, graph.neurons, graph.synapses, onSelect]);

  // recompute layout when graph or canvas size changes
  const computeIfReady = useCallback(() => {
    const { w, h } = sizeRef.current;
    if (!graph || w === 0 || h === 0) return;
    layoutRef.current = computeLayout(graph, w, h);
  }, [graph]);

  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    const ro = new ResizeObserver(() => {
      const rect = wrap.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      sizeRef.current = { w: rect.width, h: rect.height, dpr };
      canvas.width = Math.floor(rect.width * dpr);
      canvas.height = Math.floor(rect.height * dpr);
      canvas.style.width = rect.width + "px";
      canvas.style.height = rect.height + "px";
      computeIfReady();
    });
    ro.observe(wrap);
    return () => ro.disconnect();
  }, [computeIfReady]);

  // Force-directed sub-graph layout: when focusClusterId changes (and
  // useForceLayout is on), compute target positions for the focused cluster's
  // neurons. Instead of snapping instantly, we save the old positions and
  // interpolate toward the targets over ~1s in the render loop.
  useEffect(() => {
    if (!useForceLayout || !focusClusterId) {
      forceAnimRef.current = null;
      return;
    }
    const layout = layoutRef.current;
    if (!layout) return;
    const fd = computeForceDirectedLayout(graph, focusClusterId, layout, 80);
    if (fd.length === 0) return;
    // collect old positions + target positions for animation
    const indices: number[] = [];
    const fromX: number[] = [];
    const fromY: number[] = [];
    const toX: number[] = [];
    const toY: number[] = [];
    let fi = 0;
    for (let i = 0; i < graph.neurons.length; i++) {
      if (graph.neurons[i].cluster === focusClusterId && graph.neurons[i].kind !== "virtual") {
        const n = layout.neurons[i];
        if (n && fd[fi]) {
          indices.push(i);
          fromX.push(n.x);
          fromY.push(n.y);
          toX.push(fd[fi].x);
          toY.push(fd[fi].y);
        }
        fi++;
      }
    }
    if (indices.length > 0) {
      forceAnimRef.current = {
        indices,
        fromX,
        fromY,
        toX,
        toY,
        progress: 0,
        duration: 1.0, // 1 second transition
      };
    }
  }, [useForceLayout, focusClusterId, graph]);

  // build stars + nebulae once
  useEffect(() => {
    const rng = mulberry32(42);
    const stars: Star[] = [];
    for (let i = 0; i < 320; i++) {
      stars.push({
        x: rng(),
        y: rng(),
        r: rng() * 1.3 + 0.2,
        base: rng() * 0.5 + 0.15,
        twinkle: rng() * Math.PI * 2,
        vx: 0.2 + rng() * 0.8, // depth: small vx = far, large = near
      });
    }
    starsRef.current = stars;
    nebulaeRef.current = [
      { x: 0.18, y: 0.22, r: 0.42, color: "rgba(139,92,246,0.18)", drift: 0.02, phase: rng() * 6.28 },
      { x: 0.82, y: 0.7, r: 0.48, color: "rgba(217,70,239,0.14)", drift: 0.018, phase: rng() * 6.28 },
      { x: 0.5, y: 0.5, r: 0.6, color: "rgba(52,211,153,0.07)", drift: 0.012, phase: rng() * 6.28 },
      { x: 0.75, y: 0.18, r: 0.34, color: "rgba(251,191,36,0.09)", drift: 0.025, phase: rng() * 6.28 },
      { x: 0.25, y: 0.82, r: 0.36, color: "rgba(34,211,238,0.08)", drift: 0.022, phase: rng() * 6.28 },
    ];

    // ---- central particle vortex: ~2800 dots in a 3-arm galaxy spiral ----
    // Each particle has a normalized radius (0..1), angle, angular speed, size,
    // and a hue offset so the spiral tint varies from center (warm) to edge (cool).
    const vortex: { x: number; y: number; r: number; theta: number; size: number; hue: number }[] = [];
    const ARMS = 3;
    const N = 2800;
    for (let i = 0; i < N; i++) {
      // bias toward outer edge for a denser torus look
      const t = Math.pow(rng(), 0.7);
      const arm = Math.floor(rng() * ARMS);
      const armOffset = (arm / ARMS) * Math.PI * 2;
      // logarithmic spiral angle
      const angle = armOffset + t * 6.5 + (rng() - 0.5) * 0.6;
      // tiny radial jitter for fuzz
      const r = t + (rng() - 0.5) * 0.03;
      vortex.push({
        x: 0,
        y: 0,
        r,
        theta: angle,
        size: 0.5 + rng() * 1.4,
        hue: rng(), // 0..1, mapped to color below
      });
    }
    vortexRef.current = vortex;

    // ---- film-grain noise tile (128x128, pre-rendered once) ----
    const noise = document.createElement("canvas");
    noise.width = 128;
    noise.height = 128;
    const nctx = noise.getContext("2d");
    if (nctx) {
      const img = nctx.createImageData(128, 128);
      for (let i = 0; i < img.data.length; i += 4) {
        // grayscale noise, low intensity
        const v = Math.floor(rng() * 255);
        img.data[i] = v;
        img.data[i + 1] = v;
        img.data[i + 2] = v;
        img.data[i + 3] = 18; // ~7% alpha
      }
      nctx.putImageData(img, 0, 0);
    }
    noiseCanvasRef.current = noise;
  }, []);

  // ---- render (declared BEFORE the animation effect so source order is correct) ----
  const render = useCallback((ctx: CanvasRenderingContext2D, dt: number, time: number) => {
    const p = ctxRef.current;
    const {
      graph: g,
      visibleClusters: vc,
      showSynapses: ss,
      showLabels: sl,
      showFiring: sf,
      onActivity: oa,
      onCameraChange: occ,
      clusterMap: cm,
      colorFor: cf,
      query: q,
      pathHighlight: ph,
      showGitHeat: gh,
      showRegionFlow: rf,
      showOrbital: orb,
      flowFilter: ff,
      onAmbientFire: oaf,
    } = p;
    const { w, h, dpr } = sizeRef.current;
    if (w === 0 || h === 0) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // ease camera animation toward target (if any)
    const cam = camAnimRef.current;
    if (cam) {
      const k = Math.min(1, dt * 4.5);
      panRef.current.x += (cam.tx - panRef.current.x) * k;
      panRef.current.y += (cam.ty - panRef.current.y) * k;
      zoomRef.current += (cam.tz - zoomRef.current) * k;
      // snap when close enough
      if (
        Math.abs(cam.tx - panRef.current.x) < 0.5 &&
        Math.abs(cam.ty - panRef.current.y) < 0.5 &&
        Math.abs(cam.tz - zoomRef.current) < 0.005
      ) {
        panRef.current.x = cam.tx;
        panRef.current.y = cam.ty;
        zoomRef.current = cam.tz;
        camAnimRef.current = null;
      }
    }

    // smooth parallax interpolation
    parallaxRef.current.x += (parallaxRef.current.tx - parallaxRef.current.x) * Math.min(1, dt * 4);
    parallaxRef.current.y += (parallaxRef.current.ty - parallaxRef.current.y) * Math.min(1, dt * 4);

    // force-layout transition: interpolate neuron positions from spiral → force-directed
    const fa = forceAnimRef.current;
    if (fa) {
      fa.progress = Math.min(1, fa.progress + dt / fa.duration);
      // ease-in-out cubic for smooth acceleration + deceleration
      const eased = fa.progress < 0.5
        ? 4 * fa.progress * fa.progress * fa.progress
        : 1 - Math.pow(-2 * fa.progress + 2, 3) / 2;
      const layout = layoutRef.current;
      if (layout) {
        for (let k = 0; k < fa.indices.length; k++) {
          const idx = fa.indices[k];
          const n = layout.neurons[idx];
          if (n) {
            n.x = fa.fromX[k] + (fa.toX[k] - fa.fromX[k]) * eased;
            n.y = fa.fromY[k] + (fa.toY[k] - fa.fromY[k]) * eased;
          }
        }
      }
      if (fa.progress >= 1) {
        forceAnimRef.current = null;
      }
    }

    // decay activation intensity (bumped to 1 by focus/trace/select events)
    if (activationRef.current > 0) {
      activationRef.current = Math.max(0, activationRef.current - dt * 1.4);
    }

    drawBackground(ctx, w, h, time);
    drawNebulae(ctx, w, h, time);
    // perspective grid floor — cyan wave-distorted horizon under the brain
    drawPerspectiveGrid(ctx, w, h, time);

    // viewport-culling helper: returns true if a world-space point (x,y) with
    // radius r is within the current viewport (accounting for pan/zoom/parallax).
    // Defined at render-scope so both drawSynapses and drawNeurons can use it.
    const viewportMargin = 60;
    const isVisible = (nx: number, ny: number, nr: number) => {
      const z = zoomRef.current;
      const screenX = w / 2 + (nx - w / 2) * z + panRef.current.x + parallaxRef.current.x;
      const screenY = h / 2 + (ny - h / 2) * z + panRef.current.y + parallaxRef.current.y;
      return (
        screenX + nr * z > -viewportMargin &&
        screenX - nr * z < w + viewportMargin &&
        screenY + nr * z > -viewportMargin &&
        screenY - nr * z < h + viewportMargin
      );
    };

    ctx.save();
    ctx.translate(
      w / 2 + panRef.current.x + parallaxRef.current.x,
      h / 2 + panRef.current.y + parallaxRef.current.y
    );
    ctx.scale(zoomRef.current, zoomRef.current);
    ctx.translate(-w / 2, -h / 2);

    drawBrainSilhouette(ctx, w, h, time);
    // central particle vortex — galaxy-spiral core at the brain center
    drawVortexCore(ctx, w, h, time);

    const layout = layoutRef.current;
    if (!layout) {
      ctx.restore();
      drawVignette(ctx, w, h);
      drawNoise(ctx, w, h, time);
      return;
    }

    drawClusters(ctx, layout, time);
    if (rf) drawRegionFlow(ctx, layout, time);
    if (ss) drawSynapses(ctx, layout, time);
    if (ph && ph.length > 1) drawPathHighlight(ctx, layout, time);
    drawNeurons(ctx, layout, time);
    if (sf) updatePulses(dt, time, layout);
    drawPulses(ctx, layout);
    updateShockwaves(dt);
    drawShockwaves(ctx);
    // navigation arrow: decay + draw
    const na = navArrowRef.current;
    if (na) {
      na.alpha = Math.max(0, na.alpha - dt * 2.5);
      if (na.alpha <= 0) {
        navArrowRef.current = null;
      } else {
        ctx.save();
        ctx.globalCompositeOperation = "lighter";
        ctx.strokeStyle = `rgba(34,211,238,${na.alpha})`;
        ctx.lineWidth = 2;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(na.fromX, na.fromY);
        ctx.lineTo(na.toX, na.toY);
        ctx.stroke();
        ctx.setLineDash([]);
        // arrowhead at the target
        const angle = Math.atan2(na.toY - na.fromY, na.toX - na.fromX);
        const headLen = 8;
        ctx.fillStyle = `rgba(34,211,238,${na.alpha})`;
        ctx.beginPath();
        ctx.moveTo(na.toX, na.toY);
        ctx.lineTo(
          na.toX - headLen * Math.cos(angle - Math.PI / 6),
          na.toY - headLen * Math.sin(angle - Math.PI / 6)
        );
        ctx.lineTo(
          na.toX - headLen * Math.cos(angle + Math.PI / 6),
          na.toY - headLen * Math.sin(angle + Math.PI / 6)
        );
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      }
    }
    if (orb) drawOrbitalNodes(ctx, w, h, time);
    if (sl) drawLabels(ctx, layout);
    // semantic zoom: file-name labels appear when zoomed in
    drawNeuronLabels(ctx, layout, time);

    ctx.restore();

    drawVignette(ctx, w, h);
    // activation flash — brief white-magenta bloom on Focus/Trace/Select
    drawActivationFlash(ctx, w, h);
    // film-grain noise overlay — kills digital flatness
    drawNoise(ctx, w, h, time);

    if (oa) oa(activeCountRef.current);

    // throttle camera-state reporting to ~10 Hz
    const now = time;
    if (occ && now - lastCamEmitRef.current > 0.1) {
      lastCamEmitRef.current = now;
      const cs = { panX: panRef.current.x, panY: panRef.current.y, zoom: zoomRef.current };
      // only emit if something changed
      if (
        cs.panX !== lastCamReportRef.current.panX ||
        cs.panY !== lastCamReportRef.current.panY ||
        cs.zoom !== lastCamReportRef.current.zoom
      ) {
        lastCamReportRef.current = cs;
        occ(cs);
      }
    }

    // ---------- draw helpers ----------

    function drawBackground(c: CanvasRenderingContext2D, W: number, H: number, t: number) {
      const grad = c.createRadialGradient(W * 0.5, H * 0.42, 0, W * 0.5, H * 0.5, Math.max(W, H) * 0.9);
      grad.addColorStop(0, "#0d0826");
      grad.addColorStop(0.4, "#070418");
      grad.addColorStop(1, BG_DEEP);
      c.fillStyle = grad;
      c.fillRect(0, 0, W, H);

      // parallax offset for stars (subtle, opposite to brain parallax)
      const px = parallaxRef.current.x * 0.15;
      const py = parallaxRef.current.y * 0.15;

      const stars = starsRef.current;
      for (let i = 0; i < stars.length; i++) {
        const s = stars[i];
        const tw = 0.5 + 0.5 * Math.sin(t * s.twinkle * 0.6 + s.base * 10);
        c.globalAlpha = s.base + tw * 0.5;
        // near stars (high vx) move more with parallax; far stars barely move
        const sx = (s.x * W - px * s.vx) % W;
        const sy = (s.y * H - py * s.vx) % H;
        c.fillStyle = i % 7 === 0 ? "#c4b5fd" : i % 11 === 0 ? "#67e8f9" : i % 13 === 0 ? "#fda4af" : "#ffffff";
        c.beginPath();
        c.arc(sx < 0 ? sx + W : sx, sy < 0 ? sy + H : sy, s.r, 0, Math.PI * 2);
        c.fill();
        // sparkle cross for a few bright near stars
        if (s.r > 1.1 && tw > 0.85) {
          c.globalAlpha = (tw - 0.85) * 4;
          c.strokeStyle = c.fillStyle as string;
          c.lineWidth = 0.5;
          c.beginPath();
          c.moveTo(sx - s.r * 3, sy);
          c.lineTo(sx + s.r * 3, sy);
          c.moveTo(sx, sy - s.r * 3);
          c.lineTo(sx, sy + s.r * 3);
          c.stroke();
        }
      }
      c.globalAlpha = 1;
    }

    function drawNebulae(c: CanvasRenderingContext2D, W: number, H: number, t: number) {
      for (const n of nebulaeRef.current) {
        const cx = n.x * W + Math.sin(t * n.drift + n.phase) * 50;
        const cy = n.y * H + Math.cos(t * n.drift * 0.8 + n.phase) * 34;
        const r = n.r * Math.min(W, H);
        const grad = c.createRadialGradient(cx, cy, 0, cx, cy, r);
        grad.addColorStop(0, n.color);
        grad.addColorStop(0.6, n.color.replace(/[\d.]+\)$/, "0.04)"));
        grad.addColorStop(1, "rgba(0,0,0,0)");
        c.fillStyle = grad;
        c.fillRect(cx - r, cy - r, r * 2, r * 2);
      }
    }

    /**
     * Perspective grid floor — a cyan wave-distorted horizon that grounds the
     * brain in 3D space. Drawn before the brain transform so it stays fixed in
     * screen space (doesn't pan/zoom with the brain), giving a stable "floor".
     * Intensifies during activation.
     */
    function drawPerspectiveGrid(c: CanvasRenderingContext2D, W: number, H: number, t: number) {
      const horizonY = H * 0.72;
      const act = activationRef.current;
      const baseAlpha = 0.10 + act * 0.18;
      c.save();
      // horizon glow
      const glow = c.createLinearGradient(0, horizonY - 30, 0, horizonY + 30);
      glow.addColorStop(0, "rgba(34,211,238,0)");
      glow.addColorStop(0.5, `rgba(34,211,238,${0.12 + act * 0.25})`);
      glow.addColorStop(1, "rgba(34,211,238,0)");
      c.fillStyle = glow;
      c.fillRect(0, horizonY - 30, W, 60);

      // perspective grid: horizontal lines converging to a vanishing point
      c.strokeStyle = `rgba(103,232,249,${baseAlpha})`;
      c.lineWidth = 1;
      const vp = { x: W / 2, y: horizonY - 40 };
      // horizontal lines (receding toward horizon)
      for (let i = 1; i <= 14; i++) {
        const k = i / 14;
        // exponential spacing for perspective
        const y = horizonY + Math.pow(k, 1.6) * (H - horizonY) * 1.2;
        if (y > H + 5) break;
        const wave = Math.sin(t * 0.6 + i * 0.4) * (2 + act * 3);
        c.globalAlpha = (1 - k * 0.7) * baseAlpha * 2.2;
        c.beginPath();
        c.moveTo(0, y + wave);
        c.lineTo(W, y + wave);
        c.stroke();
      }
      c.globalAlpha = baseAlpha * 2.2;
      // vertical lines converging to vanishing point
      const cols = 24;
      for (let i = -cols; i <= cols; i++) {
        const xBottom = W / 2 + (i / cols) * W * 1.1;
        c.beginPath();
        c.moveTo(xBottom, H);
        c.lineTo(vp.x, vp.y);
        c.stroke();
      }
      c.globalAlpha = 1;
      c.restore();
    }

    /**
     * Central particle vortex — a 3-arm galaxy spiral of ~2800 additive dots
     * at the brain's geometric center. Rotates slowly, intensifies + shifts
     * hue toward the selected/trace neuron's cluster color during activation.
     */
    function drawVortexCore(c: CanvasRenderingContext2D, W: number, H: number, t: number) {
      const cx = W / 2;
      const cy = H / 2;
      const baseR = Math.min(W, H) * 0.085;
      const act = activationRef.current;
      // rotation speed: slow idle, faster during activation
      const rot = t * (0.12 + act * 0.4);
      // determine tint: default magenta-violet, shifts to selected cluster color
      let tintR = 217, tintG = 70, tintB = 239; // #d946ef magenta
      const selIdx = selectedIdxRef.current;
      const trIdx = traceIdxRef.current;
      const refIdx = trIdx >= 0 ? trIdx : selIdx;
      if (refIdx >= 0) {
        const neuron = g.neurons[refIdx];
        const color = cm.get(neuron?.cluster)?.color ?? "#a855f7";
        const h = color.replace("#", "");
        tintR = parseInt(h.slice(0, 2), 16);
        tintG = parseInt(h.slice(2, 4), 16);
        tintB = parseInt(h.slice(4, 6), 16);
      }
      const particles = vortexRef.current;
      c.save();
      c.globalCompositeOperation = "lighter"; // additive blend for bloom
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        const r = baseR * p.r * (1 + act * 0.25);
        const angle = p.theta + rot * (1 + (1 - p.r) * 1.5);
        const x = cx + Math.cos(angle) * r;
        const y = cy + Math.sin(angle) * r;
        // color: inner particles warm (white-hot), outer particles tinted
        const warmth = 1 - p.r;
        const rr = Math.round(tintR + (255 - tintR) * warmth * 0.7);
        const gg = Math.round(tintG + (255 - tintG) * warmth * 0.7);
        const bb = Math.round(tintB + (255 - tintB) * warmth * 0.7);
        const alpha = (0.25 + warmth * 0.4) * (1 + act * 0.5);
        c.fillStyle = `rgba(${rr},${gg},${bb},${Math.min(1, alpha)})`;
        c.beginPath();
        c.arc(x, y, p.size, 0, Math.PI * 2);
        c.fill();
      }
      // central white-hot nucleus glow (stronger during activation)
      const nucleusR = baseR * (0.25 + act * 0.15);
      const ng = c.createRadialGradient(cx, cy, 0, cx, cy, nucleusR * 4);
      ng.addColorStop(0, `rgba(255,255,255,${0.6 + act * 0.3})`);
      ng.addColorStop(0.3, `rgba(${tintR},${tintG},${tintB},${0.3 + act * 0.3})`);
      ng.addColorStop(1, `rgba(${tintR},${tintG},${tintB},0)`);
      c.fillStyle = ng;
      c.beginPath();
      c.arc(cx, cy, nucleusR * 4, 0, Math.PI * 2);
      c.fill();
      c.restore();
    }

    /**
     * Activation flash — a brief full-screen white-magenta bloom that overlays
     * the scene when activationRef > 0. Decays in ~0.7s. Gives a satisfying
     * "power-up" beat on Focus/Trace/Select actions (mimics the JARVIS video).
     */
    function drawActivationFlash(c: CanvasRenderingContext2D, W: number, H: number) {
      const act = activationRef.current;
      if (act <= 0.01) return;
      c.save();
      c.globalCompositeOperation = "lighter";
      const cx = W / 2;
      const cy = H / 2;
      const grad = c.createRadialGradient(cx, cy, 0, cx, cy, Math.max(W, H) * 0.7);
      grad.addColorStop(0, `rgba(255,255,255,${act * 0.18})`);
      grad.addColorStop(0.3, `rgba(217,70,239,${act * 0.10})`);
      grad.addColorStop(1, "rgba(217,70,239,0)");
      c.fillStyle = grad;
      c.fillRect(0, 0, W, H);
      c.restore();
    }

    /**
     * Film-grain noise overlay — tiles a 128x128 pre-rendered noise canvas
     * across the screen with a slow drift. Subtle (7% alpha), kills the flat
     * digital look. Animate the offset slightly so the grain shimmers.
     */
    function drawNoise(c: CanvasRenderingContext2D, W: number, H: number, t: number) {
      const noise = noiseCanvasRef.current;
      if (!noise) return;
      c.save();
      c.globalAlpha = 0.55;
      const ox = (Math.floor(t * 7) % 128);
      const oy = (Math.floor(t * 5) % 128);
      // tile across the screen, offset by the drift
      for (let y = -oy; y < H; y += 128) {
        for (let x = -ox; x < W; x += 128) {
          c.drawImage(noise, x, y);
        }
      }
      c.restore();
    }

    function drawVignette(c: CanvasRenderingContext2D, W: number, H: number) {
      const grad = c.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.75);
      grad.addColorStop(0, "rgba(0,0,0,0)");
      grad.addColorStop(1, "rgba(0,0,0,0.55)");
      c.fillStyle = grad;
      c.fillRect(0, 0, W, H);
    }

    function drawBrainSilhouette(c: CanvasRenderingContext2D, W: number, H: number, t: number) {
      const cx = W / 2;
      const cy = H / 2;
      const rx = (W * 0.86) / 2;
      const ry = (H * 0.78) / 2;
      c.save();
      c.beginPath();
      brainPath(c, cx, cy, rx, ry, t);
      const glow = c.createRadialGradient(cx, cy, ry * 0.2, cx, cy, rx);
      glow.addColorStop(0, "rgba(168,85,247,0.06)");
      glow.addColorStop(0.7, "rgba(168,85,247,0.035)");
      glow.addColorStop(1, "rgba(168,85,247,0)");
      c.fillStyle = glow;
      c.fill();
      c.strokeStyle = "rgba(168,85,247,0.22)";
      c.lineWidth = 1.2;
      c.stroke();
      // secondary outer halo ring
      c.beginPath();
      brainPath(c, cx, cy, rx * 1.04, ry * 1.04, t + 0.5);
      c.strokeStyle = "rgba(168,85,247,0.06)";
      c.lineWidth = 1;
      c.stroke();
      // central fissure
      c.beginPath();
      c.moveTo(cx, cy - ry * 0.92);
      c.bezierCurveTo(
        cx + rx * 0.04, cy - ry * 0.3,
        cx - rx * 0.04, cy + ry * 0.3,
        cx, cy + ry * 0.9
      );
      c.strokeStyle = "rgba(255,255,255,0.05)";
      c.lineWidth = 1;
      c.stroke();
      c.restore();
    }

    function brainPath(
      c: CanvasRenderingContext2D,
      cx: number, cy: number, rx: number, ry: number, t: number
    ) {
      const segments = 72;
      const wob = 0.045;
      for (let i = 0; i <= segments; i++) {
        const a = (i / segments) * Math.PI * 2;
        const wobble = 1 + Math.sin(a * 5 + t * 0.4) * wob + Math.cos(a * 7 - t * 0.3) * wob * 0.6;
        const x = cx + Math.cos(a) * rx * wobble;
        const y = cy + Math.sin(a) * ry * wobble;
        if (i === 0) c.moveTo(x, y);
        else c.lineTo(x, y);
      }
      c.closePath();
    }

    function drawClusters(c: CanvasRenderingContext2D, layout: BrainLayout, t: number) {
      const hovered = hoveredIdxRef.current;
      const hoveredCluster = hovered >= 0 ? g.neurons[hovered]?.cluster : null;

      for (const cl of g.clusters) {
        const center = layout.centers[cl.id];
        if (!center) continue;
        if (!vc.has(cl.id)) continue;
        const isHovered = hoveredCluster === cl.id;
        const breathing = 1 + Math.sin(t * 0.8 + center.x * 0.01) * 0.04;
        const r = center.r * breathing * (isHovered ? 1.04 : 1);

        // soft outer glow halo (stronger on hover)
        const haloR = r * (isHovered ? 1.7 : 1.4);
        const grad = c.createRadialGradient(center.x, center.y, r * 0.1, center.x, center.y, haloR);
        grad.addColorStop(0, hexA(cl.color, isHovered ? 0.32 : 0.22));
        grad.addColorStop(0.6, hexA(cl.color, isHovered ? 0.12 : 0.08));
        grad.addColorStop(1, hexA(cl.color, 0));
        c.fillStyle = grad;
        c.beginPath();
        c.arc(center.x, center.y, haloR, 0, Math.PI * 2);
        c.fill();

        // inner cluster membrane (organic wobbly shape)
        c.beginPath();
        const segs = 44;
        for (let i = 0; i <= segs; i++) {
          const a = (i / segs) * Math.PI * 2;
          const w = 1 + Math.sin(a * 4 + t * 0.5 + center.y * 0.02) * 0.08;
          const x = center.x + Math.cos(a) * r * w;
          const y = center.y + Math.sin(a) * r * w;
          if (i === 0) c.moveTo(x, y);
          else c.lineTo(x, y);
        }
        c.closePath();
        c.strokeStyle = hexA(cl.color, isHovered ? 0.6 : 0.35);
        c.lineWidth = isHovered ? 1.5 : 1;
        c.stroke();

        // inner subtle fill for "membrane" look
        c.fillStyle = hexA(cl.color, 0.025);
        c.fill();
      }
    }

    /**
     * Draw cluster-to-cluster dependency flow arrows. Aggregates all synapses
     * by their source/target cluster, then draws thick animated arrows between
     * cluster centers with width proportional to the import count. Gives a
     * "region-level" view of how modules depend on each other.
     */
    function drawRegionFlow(c: CanvasRenderingContext2D, layout: BrainLayout, t: number) {
      // aggregate synapses by cluster pair
      const flow = new Map<string, { from: string; to: string; count: number }>();
      for (const s of layout.synapses) {
        const na = g.neurons[s.source];
        const nb = g.neurons[s.target];
        if (!na || !nb || na.cluster === nb.cluster) continue;
        const key = `${na.cluster}->${nb.cluster}`;
        const existing = flow.get(key);
        if (existing) existing.count++;
        else flow.set(key, { from: na.cluster, to: nb.cluster, count: 1 });
      }
      const maxCount = Math.max(1, ...Array.from(flow.values()).map((f) => f.count));
      c.save();
      c.lineCap = "round";
      c.globalCompositeOperation = "lighter";
      for (const f of flow.values()) {
        const fromCenter = layout.centers[f.from];
        const toCenter = layout.centers[f.to];
        if (!fromCenter || !toCenter) continue;
        if (!vc.has(f.from) || !vc.has(f.to)) continue;
        const fromColor = cm.get(f.from)?.color ?? "#a855f7";
        const toColor = cm.get(f.to)?.color ?? "#a855f7";
        // line from edge of source cluster to edge of target cluster
        const dx = toCenter.x - fromCenter.x;
        const dy = toCenter.y - fromCenter.y;
        const len = Math.hypot(dx, dy) || 1;
        const ux = dx / len;
        const uy = dy / len;
        const sx = fromCenter.x + ux * fromCenter.r * 0.9;
        const sy = fromCenter.y + uy * fromCenter.r * 0.9;
        const ex = toCenter.x - ux * toCenter.r * 0.9;
        const ey = toCenter.y - uy * toCenter.r * 0.9;
        // width scales with count — thicker base for visibility
        const width = 2 + (f.count / maxCount) * 7;
        const alpha = 0.35 + (f.count / maxCount) * 0.5;
        const grad = c.createLinearGradient(sx, sy, ex, ey);
        grad.addColorStop(0, hexA(fromColor, alpha));
        grad.addColorStop(1, hexA(toColor, alpha));
        c.strokeStyle = grad;
        c.lineWidth = width;
        // animated dash flow
        c.setLineDash([8, 6]);
        c.lineDashOffset = -t * 30;
        c.beginPath();
        c.moveTo(sx, sy);
        // slight curve for organic feel
        const mx = (sx + ex) / 2;
        const my = (sy + ey) / 2;
        const curve = Math.min(30, len * 0.15);
        c.quadraticCurveTo(mx - uy * curve, my + ux * curve, ex, ey);
        c.stroke();
        c.setLineDash([]);
        // arrowhead at the target end
        const headLen = 6 + (f.count / maxCount) * 4;
        const angle = Math.atan2(ey - my, ex - mx);
        c.fillStyle = hexA(toColor, alpha + 0.2);
        c.beginPath();
        c.moveTo(ex, ey);
        c.lineTo(
          ex - headLen * Math.cos(angle - Math.PI / 6),
          ey - headLen * Math.sin(angle - Math.PI / 6)
        );
        c.lineTo(
          ex - headLen * Math.cos(angle + Math.PI / 6),
          ey - headLen * Math.sin(angle + Math.PI / 6)
        );
        c.closePath();
        c.fill();
      }
      c.restore();
    }

    /**
     * Draw orbital module nodes — 7 circular icon chips representing the brain
     * regions, orbiting the vortex core on a slow rotation. Each chip is
     * connected to the core by a faint curved Bézier "gravity" edge. Clicking
     * a chip focuses that cluster. Mimics the JARVIS video's orbiting UI nodes.
     */
    function drawOrbitalNodes(c: CanvasRenderingContext2D, W: number, H: number, t: number) {
      const cx = W / 2;
      const cy = H / 2;
      const orbitR = Math.min(W, H) * 0.42;
      const visibleCount = g.clusters.filter((cl) => vc.has(cl.id)).length;
      if (visibleCount === 0) return;
      c.save();
      // orbit guide ring (faint dashed)
      c.strokeStyle = "rgba(255,255,255,0.05)";
      c.lineWidth = 1;
      c.setLineDash([3, 6]);
      c.beginPath();
      c.arc(cx, cy, orbitR, 0, Math.PI * 2);
      c.stroke();
      c.setLineDash([]);

      let vi = 0;
      for (const cl of g.clusters) {
        if (!vc.has(cl.id)) continue;
        const angle = (vi / visibleCount) * Math.PI * 2 + t * 0.08;
        const x = cx + Math.cos(angle) * orbitR;
        const y = cy + Math.sin(angle) * orbitR;
        // gravity edge: faint curve from chip to core
        const grad = c.createLinearGradient(x, y, cx, cy);
        grad.addColorStop(0, hexA(cl.color, 0.3));
        grad.addColorStop(1, hexA(cl.color, 0));
        c.strokeStyle = grad;
        c.lineWidth = 0.8;
        c.beginPath();
        c.moveTo(x, y);
        // curve toward the perpendicular for an organic "gravity" arc
        const midx = (x + cx) / 2;
        const midy = (y + cy) / 2;
        const perpX = -(cy - y) / Math.hypot(cx - x, cy - y);
        const perpY = (cx - x) / Math.hypot(cx - x, cy - y);
        c.quadraticCurveTo(midx + perpX * 20, midy + perpY * 20, cx, cy);
        c.stroke();

        // chip: outer glow
        const chipR = 14;
        const glow = c.createRadialGradient(x, y, 0, x, y, chipR * 2);
        glow.addColorStop(0, hexA(cl.color, 0.5));
        glow.addColorStop(1, hexA(cl.color, 0));
        c.fillStyle = glow;
        c.beginPath();
        c.arc(x, y, chipR * 2, 0, Math.PI * 2);
        c.fill();
        // chip body
        c.fillStyle = "#0a0718";
        c.beginPath();
        c.arc(x, y, chipR, 0, Math.PI * 2);
        c.fill();
        c.strokeStyle = cl.color;
        c.lineWidth = 1.5;
        c.stroke();
        // chip inner dot
        c.fillStyle = cl.color;
        c.beginPath();
        c.arc(x, y, 4, 0, Math.PI * 2);
        c.fill();
        // chip label (first word of domain)
        const label = cl.domain.split(" ")[0];
        c.font = "600 9px var(--font-geist-mono), monospace";
        c.textAlign = "center";
        c.textBaseline = "middle";
        c.fillStyle = "rgba(255,255,255,0.7)";
        c.fillText(label, x, y + chipR + 9);
        vi++;
      }
      c.restore();
    }

    function drawSynapses(c: CanvasRenderingContext2D, layout: BrainLayout, t: number) {
      const hovered = hoveredIdxRef.current;
      const selected = selectedIdxRef.current;
      const ql = q.toLowerCase();
      const isHighlighted = (s: { source: number; target: number }) =>
        (hovered >= 0 && (s.source === hovered || s.target === hovered)) ||
        (selected >= 0 && (s.source === selected || s.target === selected));

      // gather query-matching neuron indices for spotlight lines
      const qMatches = new Set<number>();
      if (ql.length > 0) {
        for (let i = 0; i < g.neurons.length; i++) {
          if (g.neurons[i].name.toLowerCase().includes(ql)) qMatches.add(i);
        }
      }

      c.lineCap = "round";
      for (let i = 0; i < layout.synapses.length; i++) {
        const s = layout.synapses[i];
        const a = layout.neurons[s.source];
        const b = layout.neurons[s.target];
        if (!a || !b) continue;
        const na = g.neurons[s.source];
        const nb = g.neurons[s.target];
        if (!na || !nb) continue;
        if (!vc.has(na.cluster) && !vc.has(nb.cluster)) continue;
        // synapse culling: skip if BOTH endpoints are offscreen (unless highlighted)
        const synHl = isHighlighted(s);
        const synFF = ff !== null && na.cluster === ff.from && nb.cluster === ff.to;
        if (!synHl && !synFF && !isVisible(a.x, a.y, 10) && !isVisible(b.x, b.y, 10)) continue;

        const hl = synHl;
        // spotlight: synapse connecting two query matches is bright
        const spotlight = ql.length > 0 && qMatches.has(s.source) && qMatches.has(s.target);
        // flow-filter: highlight synapses matching the matrix cell click
        const matchesFlowFilter =
          ff !== null &&
          na.cluster === ff.from &&
          nb.cluster === ff.to;
        const midX = (a.x + b.x) / 2;
        const midY = (a.y + b.y) / 2;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const len = Math.hypot(dx, dy) || 1;
        const nx = -dy / len;
        const ny = dx / len;
        const curve = Math.min(40, len * 0.18);
        const cxp = midX + nx * curve * Math.sin(t * 0.3 + i);
        const cyp = midY + ny * curve * Math.sin(t * 0.3 + i);

        const c1 = cf(s.source);
        const c2 = cf(s.target);
        const grad = c.createLinearGradient(a.x, a.y, b.x, b.y);
        const baseAlpha = hl ? 0.95 : matchesFlowFilter ? 0.85 : spotlight ? 0.7 : 0.12;
        grad.addColorStop(0, hexA(c1, baseAlpha));
        grad.addColorStop(1, hexA(c2, baseAlpha));
        c.strokeStyle = grad;
        c.lineWidth = hl ? 1.8 : matchesFlowFilter ? 1.6 : spotlight ? 1.2 : 0.6;
        c.beginPath();
        c.moveTo(a.x, a.y);
        c.quadraticCurveTo(cxp, cyp, b.x, b.y);
        c.stroke();
      }
    }

    function drawNeurons(c: CanvasRenderingContext2D, layout: BrainLayout, t: number) {
      const hovered = hoveredIdxRef.current;
      const selected = selectedIdxRef.current;
      let active = 0;
      const ql = q.toLowerCase();

      // precompute the path-highlight neuron set for membership tests
      const pathSet = new Set<number>(ph ?? []);

      // find the most-recent commit timestamp across all neurons (for heat normalization)
      let maxTs = 0;
      if (gh) {
        for (const neuron of g.neurons) {
          if (neuron.lastCommit) {
            const ts = Date.parse(neuron.lastCommit);
            if (Number.isFinite(ts) && ts > maxTs) maxTs = ts;
          }
        }
      }
      const now = Date.now();

      // ---- Pass 1: glow halos with additive blending (true bloom) ----
      c.save();
      c.globalCompositeOperation = "lighter";
      for (let i = 0; i < layout.neurons.length; i++) {
        const n = layout.neurons[i];
        if (!n) continue;
        const neuron = g.neurons[i];
        if (!neuron || neuron.kind === "virtual") continue;
        if (!vc.has(neuron.cluster)) continue;
        // viewport cull (skip offscreen neurons)
        if (!isVisible(n.x, n.y, 20)) continue;

        const color = cm.get(neuron.cluster)?.color ?? "#a855f7";
        const phase = n.phase;
        const pulse = 0.5 + 0.5 * Math.sin(t * 1.6 + phase);
        const r = n.r * (0.9 + pulse * 0.25);

        const isHover = i === hovered;
        const isSel = i === selected;
        const matchesQuery = ql.length > 0 && neuron.name.toLowerCase().includes(ql);
        const dimmed = ql.length > 0 && !matchesQuery;

        // git recency heat: 0 (old/never) .. 1 (most recent)
        let heat = 0;
        if (gh && neuron.lastCommit && maxTs > 0) {
          const ts = Date.parse(neuron.lastCommit);
          if (Number.isFinite(ts)) {
            const ageDays = (now - ts) / 86400000;
            heat = Math.max(0, 1 - ageDays / 30);
          }
        }

        const glowR = r * (isHover || isSel ? 6.5 : 3.5 + heat * 1.5);
        const grad = c.createRadialGradient(n.x, n.y, 0, n.x, n.y, glowR);
        const baseGlowAlpha = dimmed
          ? 0.05
          : isHover || isSel
          ? 0.9
          : 0.45 + pulse * 0.2 + heat * 0.3;
        grad.addColorStop(0, hexA(color, baseGlowAlpha));
        grad.addColorStop(1, hexA(color, 0));
        c.fillStyle = grad;
        c.beginPath();
        c.arc(n.x, n.y, glowR, 0, Math.PI * 2);
        c.fill();

        // hot core for recently-committed files (white-hot lerp, additive)
        if (heat > 0.4 && !dimmed) {
          const hg = c.createRadialGradient(n.x, n.y, 0, n.x, n.y, r * 1.6);
          hg.addColorStop(0, hexA("#ffffff", heat * 0.5));
          hg.addColorStop(1, hexA("#ffffff", 0));
          c.fillStyle = hg;
          c.beginPath();
          c.arc(n.x, n.y, r * 1.6, 0, Math.PI * 2);
          c.fill();
        }
      }
      c.restore();

      // ---- Pass 2: solid cores + rings (normal blending) ----
      for (let i = 0; i < layout.neurons.length; i++) {
        const n = layout.neurons[i];
        if (!n) continue;
        const neuron = g.neurons[i];
        if (!neuron || neuron.kind === "virtual") continue;
        if (!vc.has(neuron.cluster)) continue;
        // viewport cull (but always render hovered/selected/path-highlighted)
        const isHover2 = i === hoveredIdxRef.current;
        const isSel2 = i === selectedIdxRef.current;
        const onPathCull = (ph ?? []).includes(i);
        if (!isHover2 && !isSel2 && !onPathCull && !isVisible(n.x, n.y, 20)) continue;

        const color = cm.get(neuron.cluster)?.color ?? "#a855f7";
        const phase = n.phase;
        const pulse = 0.5 + 0.5 * Math.sin(t * 1.6 + phase);
        const r = n.r * (0.9 + pulse * 0.25);

        const isHover = i === hovered;
        const isSel = i === selected;
        const matchesQuery = ql.length > 0 && neuron.name.toLowerCase().includes(ql);
        const dimmed = ql.length > 0 && !matchesQuery;
        const isCircular = !!neuron.circular;
        const onPath = pathSet.has(i);

        c.globalAlpha = dimmed ? 0.18 : 1;
        c.fillStyle = color;
        c.beginPath();
        c.arc(n.x, n.y, r, 0, Math.PI * 2);
        c.fill();

        c.globalAlpha = dimmed ? 0.08 : 0.85;
        c.fillStyle = "#ffffff";
        c.beginPath();
        c.arc(n.x - r * 0.25, n.y - r * 0.25, r * 0.4, 0, Math.PI * 2);
        c.fill();

        if (matchesQuery) {
          c.globalAlpha = 1;
          c.strokeStyle = "#ffffff";
          c.lineWidth = 1.5;
          c.beginPath();
          c.arc(n.x, n.y, r + 5 + Math.sin(t * 6) * 1.2, 0, Math.PI * 2);
          c.stroke();
        }
        if (isSel) {
          c.globalAlpha = 1;
          c.strokeStyle = hexA("#ffffff", 0.9);
          c.lineWidth = 1.8;
          c.beginPath();
          c.arc(n.x, n.y, r + 7, 0, Math.PI * 2);
          c.stroke();
          c.strokeStyle = hexA(color, 0.5);
          c.lineWidth = 1;
          c.beginPath();
          c.arc(n.x, n.y, r + 12 + Math.sin(t * 4) * 2, 0, Math.PI * 2);
          c.stroke();
        }
        // circular-dependency warning ring (pulsing rose)
        if (isCircular) {
          c.globalAlpha = 0.7 + 0.3 * Math.sin(t * 3 + i);
          c.strokeStyle = "#fb7185";
          c.lineWidth = 1.2;
          c.setLineDash([2, 3]);
          c.beginPath();
          c.arc(n.x, n.y, r + 4, 0, Math.PI * 2);
          c.stroke();
          c.setLineDash([]);
        }
        // path-highlight ring (amber, double-stroke)
        if (onPath && !isSel) {
          c.globalAlpha = 1;
          c.strokeStyle = "#fbbf24";
          c.lineWidth = 1.4;
          c.beginPath();
          c.arc(n.x, n.y, r + 6, 0, Math.PI * 2);
          c.stroke();
        }
        c.globalAlpha = 1;
        if (!dimmed) active++;
      }
      activeCountRef.current = active;
    }

    /**
     * Draw the shortest-path highlight: animated amber gradient line connecting
     * the ordered path neurons, with a traveling bright dot.
     */
    function drawPathHighlight(c: CanvasRenderingContext2D, layout: BrainLayout, t: number) {
      const path = ph ?? [];
      if (path.length < 2) return;
      c.save();
      c.lineCap = "round";
      c.lineJoin = "round";
      // draw the connecting polyline with an amber gradient
      for (let i = 0; i < path.length - 1; i++) {
        const a = layout.neurons[path[i]];
        const b = layout.neurons[path[i + 1]];
        if (!a || !b) continue;
        const grad = c.createLinearGradient(a.x, a.y, b.x, b.y);
        grad.addColorStop(0, "rgba(251,191,36,0.9)");
        grad.addColorStop(1, "rgba(251,191,36,0.7)");
        c.strokeStyle = grad;
        c.lineWidth = 2.2;
        c.beginPath();
        c.moveTo(a.x, a.y);
        c.lineTo(b.x, b.y);
        c.stroke();
      }
      // traveling bright dot along the full path
      const totalSegs = path.length - 1;
      const progress = (t * 0.35) % totalSegs;
      const segIdx = Math.floor(progress);
      const segT = progress - segIdx;
      const a = layout.neurons[path[segIdx]];
      const b = layout.neurons[path[segIdx + 1]];
      if (a && b) {
        const px = a.x + (b.x - a.x) * segT;
        const py = a.y + (b.y - a.y) * segT;
        const g = c.createRadialGradient(px, py, 0, px, py, 8);
        g.addColorStop(0, "rgba(255,255,255,1)");
        g.addColorStop(0.4, "rgba(251,191,36,0.8)");
        g.addColorStop(1, "rgba(251,191,36,0)");
        c.fillStyle = g;
        c.beginPath();
        c.arc(px, py, 8, 0, Math.PI * 2);
        c.fill();
      }
      c.restore();
    }

    function updatePulses(deltaT: number, _t: number, _layout: BrainLayout) {
      const layout = layoutRef.current;
      if (!layout) return;
      const syns = layout.synapses;
      if (syns.length === 0) return;

      // ---- ambient firing (random) ----
      fireAccRef.current += deltaT;
      const spawnInterval = 0.35;
      while (fireAccRef.current > spawnInterval) {
        fireAccRef.current -= spawnInterval;
        const tries = 8;
        for (let i = 0; i < tries; i++) {
          const idx = Math.floor(Math.random() * syns.length);
          const s = syns[idx];
          const na = g.neurons[s.source];
          const nb = g.neurons[s.target];
          if (!na || !nb) continue;
          if (na.kind === "virtual" || nb.kind === "virtual") continue;
          if (!vc.has(na.cluster) || !vc.has(nb.cluster)) continue;
          pulsesRef.current.push({
            synapseIdx: idx,
            t: 0,
            speed: 0.6 + Math.random() * 0.9,
            color: cf(s.source),
            intensity: 0,
          });
          if (oaf) oaf();
          break;
        }
      }

      // ---- hover-triggered firing: bias pulses toward hovered neuron's synapses ----
      const hovered = hoveredIdxRef.current;
      if (hovered >= 0) {
        hoverFireAccRef.current += deltaT;
        // fire every ~120ms while hovering
        while (hoverFireAccRef.current > 0.12) {
          hoverFireAccRef.current -= 0.12;
          // collect synapses touching the hovered neuron
          const candidates: number[] = [];
          for (let i = 0; i < syns.length; i++) {
            if (syns[i].source === hovered || syns[i].target === hovered) candidates.push(i);
          }
          if (candidates.length > 0) {
            // fire 1-2 of them
            const count = Math.min(2, candidates.length);
            for (let k = 0; k < count; k++) {
              const pick = candidates[Math.floor(Math.random() * candidates.length)];
              pulsesRef.current.push({
                synapseIdx: pick,
                t: 0,
                speed: 1.1 + Math.random() * 0.6,
                color: cf(hovered),
                intensity: 1,
              });
            }
          }
        }
      } else {
        hoverFireAccRef.current = 0;
      }

      // ---- trace-mode firing: sustained intense firing of all synapses of the
      // trace-neuron (triggered by the radial menu "Trace" action) ----
      const traced = traceIdxRef.current;
      if (traced >= 0) {
        // spawn a burst every ~40ms
        if (!("_traceAcc" in pulsesRef)) {
          (pulsesRef as unknown as { _traceAcc: number })._traceAcc = 0;
        }
        const traceAcc = (pulsesRef as unknown as { _traceAcc: number });
        traceAcc._traceAcc += deltaT;
        while (traceAcc._traceAcc > 0.04) {
          traceAcc._traceAcc -= 0.04;
          const candidates: number[] = [];
          for (let i = 0; i < syns.length; i++) {
            if (syns[i].source === traced || syns[i].target === traced) candidates.push(i);
          }
          if (candidates.length > 0) {
            // fire 2-3 at once for an intense "electrical storm" effect
            const count = Math.min(3, candidates.length);
            for (let k = 0; k < count; k++) {
              const pick = candidates[Math.floor(Math.random() * candidates.length)];
              pulsesRef.current.push({
                synapseIdx: pick,
                t: 0,
                speed: 1.4 + Math.random() * 0.8,
                color: cf(traced),
                intensity: 2, // trace mode = even brighter
              });
            }
          }
        }
      }

      // advance existing pulses
      const pulses = pulsesRef.current;
      for (let i = pulses.length - 1; i >= 0; i--) {
        pulses[i].t += deltaT * pulses[i].speed;
        if (pulses[i].t >= 1) pulses.splice(i, 1);
      }
      if (pulses.length > 320) pulses.splice(0, pulses.length - 320);
    }

    function drawPulses(c: CanvasRenderingContext2D, layout: BrainLayout) {
      const pulses = pulsesRef.current;
      for (const p of pulses) {
        const s = layout.synapses[p.synapseIdx];
        if (!s) continue;
        const a = layout.neurons[s.source];
        const b = layout.neurons[s.target];
        if (!a || !b) continue;
        const t = p.t;
        const mx = (a.x + b.x) / 2;
        const my = (a.y + b.y) / 2;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const len = Math.hypot(dx, dy) || 1;
        const nx = -dy / len;
        const ny = dx / len;
        const curve = Math.min(40, len * 0.18);
        const cxp = mx + nx * curve;
        const cyp = my + ny * curve;
        const x = (1 - t) * (1 - t) * a.x + 2 * (1 - t) * t * cxp + t * t * b.x;
        const y = (1 - t) * (1 - t) * a.y + 2 * (1 - t) * t * cyp + t * t * b.y;

        const trailLen = p.intensity > 1 ? 0.3 : p.intensity > 0 ? 0.24 : 0.18;
        const tStart = Math.max(0, t - trailLen);
        const xs = (1 - tStart) * (1 - tStart) * a.x + 2 * (1 - tStart) * tStart * cxp + tStart * tStart * b.x;
        const ys = (1 - tStart) * (1 - tStart) * a.y + 2 * (1 - tStart) * tStart * cyp + tStart * tStart * b.y;
        const grad = c.createLinearGradient(xs, ys, x, y);
        grad.addColorStop(0, hexA(p.color, 0));
        grad.addColorStop(1, hexA(p.color, p.intensity > 1 ? 1 : p.intensity > 0 ? 1 : 0.95));
        c.strokeStyle = grad;
        c.lineWidth = p.intensity > 1 ? 3.2 : p.intensity > 0 ? 2.6 : 2;
        c.beginPath();
        c.moveTo(xs, ys);
        c.lineTo(x, y);
        c.stroke();

        // bright head dot
        c.fillStyle = p.intensity > 0 ? "#ffffff" : hexA(p.color, 0.95);
        c.beginPath();
        c.arc(x, y, p.intensity > 1 ? 3 : p.intensity > 0 ? 2.4 : 1.8, 0, Math.PI * 2);
        c.fill();
        // extra glow for hover / trace pulses
        if (p.intensity > 0) {
          const glowR = p.intensity > 1 ? 12 : 8;
          const g2 = c.createRadialGradient(x, y, 0, x, y, glowR);
          g2.addColorStop(0, hexA(p.color, p.intensity > 1 ? 0.8 : 0.6));
          g2.addColorStop(1, hexA(p.color, 0));
          c.fillStyle = g2;
          c.beginPath();
          c.arc(x, y, glowR, 0, Math.PI * 2);
          c.fill();
        }
      }
    }

    function updateShockwaves(deltaT: number) {
      const sws = shockwavesRef.current;
      for (let i = sws.length - 1; i >= 0; i--) {
        const sw = sws[i];
        sw.r += deltaT * 110;
        sw.alpha = Math.max(0, 0.9 * (1 - sw.r / sw.maxR));
        if (sw.r >= sw.maxR) sws.splice(i, 1);
      }
    }

    function drawShockwaves(c: CanvasRenderingContext2D) {
      for (const sw of shockwavesRef.current) {
        c.strokeStyle = hexA(sw.color, sw.alpha);
        c.lineWidth = 2;
        c.beginPath();
        c.arc(sw.x, sw.y, sw.r, 0, Math.PI * 2);
        c.stroke();
        // inner faint ring
        c.strokeStyle = hexA(sw.color, sw.alpha * 0.4);
        c.lineWidth = 1;
        c.beginPath();
        c.arc(sw.x, sw.y, sw.r * 0.7, 0, Math.PI * 2);
        c.stroke();
      }
    }

    function drawLabels(c: CanvasRenderingContext2D, layout: BrainLayout) {
      c.font = "600 11px var(--font-geist-sans), system-ui, sans-serif";
      c.textAlign = "center";
      c.textBaseline = "middle";
      for (const cl of g.clusters) {
        const center = layout.centers[cl.id];
        if (!center) continue;
        if (!vc.has(cl.id)) continue;
        const y = center.y - center.r - 14;
        // subtle text shadow for legibility
        c.fillStyle = "rgba(0,0,0,0.6)";
        c.fillText(cl.label.toUpperCase(), center.x + 1, y + 1);
        c.fillStyle = hexA(cl.color, 0.95);
        c.fillText(cl.label.toUpperCase(), center.x, y);
        c.fillStyle = "rgba(255,255,255,0.55)";
        c.font = "500 9px var(--font-geist-mono), monospace";
        c.fillText(cl.domain, center.x, y + 12);
        c.font = "600 11px var(--font-geist-sans), system-ui, sans-serif";
      }
    }

    /**
     * Semantic zoom: when the camera is zoomed in past 1.4x, draw small
     * file-name labels next to visible neurons. Higher zoom = more labels.
     * Also labels the selected/hovered/trace neuron regardless of zoom so the
     * user always sees what they're interacting with.
     */
    function drawNeuronLabels(c: CanvasRenderingContext2D, layout: BrainLayout, t: number) {
      const z = zoomRef.current;
      // only show labels when zoomed in (or for highlighted neurons)
      const showAll = z >= 1.4;
      if (!showAll) {
        // still label selected + hovered + traced
        const idxs = new Set<number>();
        if (hoveredIdxRef.current >= 0) idxs.add(hoveredIdxRef.current);
        if (selectedIdxRef.current >= 0) idxs.add(selectedIdxRef.current);
        if (traceIdxRef.current >= 0) idxs.add(traceIdxRef.current);
        if (idxs.size === 0) return;
        for (const i of idxs) drawOne(c, layout, i, t, true);
        return;
      }
      // when zoomed in, label every visible neuron (with culling for performance)
      for (let i = 0; i < layout.neurons.length; i++) {
        const n = layout.neurons[i];
        if (!n) continue;
        const neuron = g.neurons[i];
        if (!neuron || neuron.kind === "virtual") continue;
        if (!vc.has(neuron.cluster)) continue;
        // cull offscreen neurons (with margin)
        const screenX = w / 2 + (n.x - w / 2) * z + panRef.current.x + parallaxRef.current.x;
        const screenY = h / 2 + (n.y - h / 2) * z + panRef.current.y + parallaxRef.current.y;
        if (screenX < -100 || screenX > w + 100 || screenY < -50 || screenY > h + 50) continue;
        const isHi =
          i === hoveredIdxRef.current ||
          i === selectedIdxRef.current ||
          i === traceIdxRef.current;
        drawOne(c, layout, i, t, isHi);
      }

      function drawOne(
        c: CanvasRenderingContext2D,
        layout: BrainLayout,
        i: number,
        _t: number,
        highlighted: boolean
      ) {
        const n = layout.neurons[i];
        if (!n) return;
        const neuron = g.neurons[i];
        if (!neuron) return;
        const color = cm.get(neuron.cluster)?.color ?? "#a855f7";
        c.font = "500 10px var(--font-geist-mono), monospace";
        c.textAlign = "left";
        c.textBaseline = "middle";
        const lx = n.x + n.r + 4;
        const ly = n.y - 1;
        // background pill for highlighted neurons
        if (highlighted) {
          const tw = c.measureText(neuron.name).width;
          c.fillStyle = "rgba(0,0,0,0.7)";
          c.fillRect(lx - 3, ly - 7, tw + 6, 14);
          c.strokeStyle = hexA(color, 0.6);
          c.lineWidth = 0.8;
          c.strokeRect(lx - 3, ly - 7, tw + 6, 14);
        }
        c.fillStyle = highlighted ? "#ffffff" : hexA(color, 0.85);
        c.fillText(neuron.name, lx, ly);
      }
    }
  }, []);

  // ---- animation loop — created once; render is stable so the loop never restarts ----
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let visible = true;
    let lastRenderTime = 0;
    const THROTTLE_MS = 500; // when tab is hidden, render every 500ms instead of 60fps

    const onVisibilityChange = () => {
      visible = !document.hidden;
    };
    document.addEventListener("visibilitychange", onVisibilityChange);

    const tick = (ts: number) => {
      if (visible) {
        // normal 60fps rendering
        const dt = lastTsRef.current ? (ts - lastTsRef.current) / 1000 : 0.016;
        lastTsRef.current = ts;
        render(ctx, dt, ts / 1000);
      } else {
        // throttled: render at ~2fps when tab is hidden
        if (ts - lastRenderTime > THROTTLE_MS) {
          lastRenderTime = ts;
          render(ctx, 0.016, ts / 1000);
        }
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener("visibilitychange", onVisibilityChange);
    };
  }, [render]);

  // pointer + wheel handlers (need to be reactive to visibleClusters + parallax)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const screenToWorld = (x: number, y: number) => {
      const { w, h } = sizeRef.current;
      const z = zoomRef.current;
      const px = (x - w / 2 - panRef.current.x) / z + w / 2;
      const py = (y - h / 2 - panRef.current.y) / z + h / 2;
      return { x: px, y: py };
    };

    const pickNeuron = (x: number, y: number): number => {
      const layout = layoutRef.current;
      if (!layout) return -1;
      const w = screenToWorld(x, y);
      let best = -1;
      let bestD = Infinity;
      for (let i = 0; i < layout.neurons.length; i++) {
        const n = layout.neurons[i];
        if (!n) continue;
        const neuron = graph.neurons[i];
        if (!neuron || neuron.kind === "virtual") continue;
        if (!visibleClusters.has(neuron.cluster)) continue;
        const dx = n.x - w.x;
        const dy = n.y - w.y;
        const d2 = dx * dx + dy * dy;
        const r = n.r + 8;
        if (d2 < r * r && d2 < bestD) {
          bestD = d2;
          best = i;
        }
      }
      return best;
    };

    const pickCluster = (x: number, y: number): string | null => {
      const layout = layoutRef.current;
      if (!layout) return null;
      const w = screenToWorld(x, y);
      let best: string | null = null;
      let bestD = Infinity;
      for (const c of graph.clusters) {
        const center = layout.centers[c.id];
        if (!center) continue;
        if (!visibleClusters.has(c.id)) continue;
        const dx = center.x - w.x;
        const dy = center.y - w.y;
        const d2 = dx * dx + dy * dy;
        if (d2 < center.r * center.r && d2 < bestD) {
          bestD = d2;
          best = c.id;
        }
      }
      return best;
    };

    /**
     * Hit-test the orbital chips. Chips are in screen space (not affected by
     * pan/zoom), orbiting at radius `min(W,H)*0.42` around the screen center.
     * Returns the clusterId of the hit chip, or null. Uses the current animation
     * time (approximate — read from performance.now()/1000).
     */
    const pickOrbital = (x: number, y: number): string | null => {
      const p = ctxRef.current;
      if (!p.showOrbital) return null;
      const { w, h } = sizeRef.current;
      const cx = w / 2;
      const cy = h / 2;
      const orbitR = Math.min(w, h) * 0.42;
      const t = performance.now() / 1000;
      const visibleClustersList = graph.clusters.filter((c) => visibleClusters.has(c.id));
      const visibleCount = visibleClustersList.length;
      if (visibleCount === 0) return null;
      const chipR = 14;
      for (let vi = 0; vi < visibleClustersList.length; vi++) {
        const angle = (vi / visibleCount) * Math.PI * 2 + t * 0.08;
        const chipX = cx + Math.cos(angle) * orbitR;
        const chipY = cy + Math.sin(angle) * orbitR;
        const dx = chipX - x;
        const dy = chipY - y;
        const d2 = dx * dx + dy * dy;
        if (d2 < (chipR + 4) * (chipR + 4)) {
          return visibleClustersList[vi].id;
        }
      }
      return null;
    };

    const onMove = (e: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const cx = rect.width / 2;
      const cy = rect.height / 2;
      const dx = (x - cx) / cx;
      const dy = (y - cy) / cy;
      parallaxRef.current.tx = parallax ? -dx * 18 : 0;
      parallaxRef.current.ty = parallax ? -dy * 14 : 0;

      if (panRef.current.dragging) {
        const ddx = x - panRef.current.lastX;
        const ddy = y - panRef.current.lastY;
        panRef.current.x += ddx;
        panRef.current.y += ddy;
        panRef.current.lastX = x;
        panRef.current.lastY = y;
        return;
      }
      const hovered = pickNeuron(x, y);
      if (hovered !== hoveredIdxRef.current) {
        hoveredIdxRef.current = hovered;
        onHover(hovered >= 0 ? graph.neurons[hovered] : null);
      }
      // update cursor: pointer if over a neuron OR an orbital chip
      const orbitalHit = pickOrbital(x, y);
      canvas.style.cursor =
        hovered >= 0 ? "pointer" : orbitalHit ? "pointer" : "default";
    };
    const onLeave = () => {
      hoveredIdxRef.current = -1;
      onHover(null);
    };
    const onDown = (e: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const hit = pickNeuron(x, y);
      if (hit >= 0) {
        // shift-click → path-finder endpoint (doesn't change selection)
        if (e.shiftKey && onShiftClick) {
          onShiftClick(graph.neurons[hit]);
          return;
        }
        selectedIdxRef.current = hit;
        onSelect(graph.neurons[hit]);
        return;
      }
      // no neuron hit — check orbital chips (click-to-focus a cluster)
      const orbitalHit = pickOrbital(x, y);
      if (orbitalHit && onFocusCluster) {
        onFocusCluster(orbitalHit);
        return;
      }
      // no orbital chip — check if we hit a cluster's empty area
      const clusterHit = pickCluster(x, y);
      if (clusterHit && onFocusCluster) {
        onFocusCluster(clusterHit);
        return;
      }
      // otherwise, start panning
      panRef.current.dragging = true;
      panRef.current.lastX = x;
      panRef.current.lastY = y;
      canvas.style.cursor = "grabbing";
    };
    const onUp = () => {
      panRef.current.dragging = false;
      canvas.style.cursor = hoveredIdxRef.current >= 0 ? "pointer" : "default";
    };
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      // zoom toward cursor
      const rect = canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      const factor = e.deltaY < 0 ? 1.12 : 0.89;
      const newZoom = Math.max(0.5, Math.min(2.8, zoomRef.current * factor));
      const actualFactor = newZoom / zoomRef.current;
      // adjust pan so the world point under the cursor stays fixed
      const { w, h } = sizeRef.current;
      const cx = w / 2;
      const cy = h / 2;
      // cursor relative to canvas center + current pan
      const dx = mx - cx - panRef.current.x;
      const dy = my - cy - panRef.current.y;
      panRef.current.x -= dx * (actualFactor - 1);
      panRef.current.y -= dy * (actualFactor - 1);
      zoomRef.current = newZoom;
    };

    const onContext = (e: MouseEvent) => {
      e.preventDefault();
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const hit = pickNeuron(x, y);
      if (hit >= 0 && onContextMenu) {
        onContextMenu(graph.neurons[hit], e.clientX, e.clientY);
      }
    };

    canvas.addEventListener("pointermove", onMove);
    canvas.addEventListener("pointerleave", onLeave);
    canvas.addEventListener("pointerdown", onDown);
    canvas.addEventListener("contextmenu", onContext);
    window.addEventListener("pointerup", onUp);
    canvas.addEventListener("wheel", onWheel, { passive: false });
    return () => {
      canvas.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerleave", onLeave);
      canvas.removeEventListener("pointerdown", onDown);
      canvas.removeEventListener("contextmenu", onContext);
      window.removeEventListener("pointerup", onUp);
      canvas.removeEventListener("wheel", onWheel);
    };
  }, [graph, visibleClusters, parallax, onHover, onSelect, onFocusCluster, onContextMenu, onShiftClick]);

  return (
    <div ref={wrapRef} className="absolute inset-0">
      <canvas
        ref={canvasRef}
        className="block h-full w-full touch-none select-none"
      />
    </div>
  );
}

// ---------- utilities ----------
function hexA(hex: string, alpha: number): string {
  if (hex.startsWith("rgba") || hex.startsWith("rgb")) return hex;
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

function mulberry32(seed: number) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
