"use client";

import { useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Activity,
  ArrowDownLeft,
  ArrowUpRight,
  Code2,
  FileCode2,
  Hash,
  X,
  Layers,
  Clock,
  AlertTriangle,
  GitCommit,
} from "lucide-react";
import type { Cluster, NeuralGraph, Neuron } from "./types";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import CodePreview from "./CodePreview";
import { useFilePreview } from "@/hooks/use-file-preview";

interface InfoPanelProps {
  neuron: Neuron | null;
  graph: NeuralGraph;
  cluster?: Cluster;
  onSelectNeuron: (n: Neuron) => void;
  onClose: () => void;
}

export default function InfoPanel({
  neuron,
  graph,
  cluster,
  onSelectNeuron,
  onClose,
}: InfoPanelProps) {
  const preview = useFilePreview(neuron?.path);

  const incoming = useMemo(() => {
    if (!neuron) return [] as Neuron[];
    const targetIdx = graph.neurons.findIndex((n) => n.id === neuron.id);
    if (targetIdx < 0) return [];
    return graph.synapses
      .filter((s) => s.target === targetIdx)
      .map((s) => graph.neurons[s.source])
      .filter((n): n is Neuron => !!n && n.kind !== "virtual");
  }, [neuron, graph]);

  const outgoing = useMemo(() => {
    if (!neuron) return [] as Neuron[];
    const sourceIdx = graph.neurons.findIndex((n) => n.id === neuron.id);
    if (sourceIdx < 0) return [];
    return graph.synapses
      .filter((s) => s.source === sourceIdx)
      .map((s) => graph.neurons[s.target])
      .filter((n): n is Neuron => !!n && n.kind !== "virtual");
  }, [neuron, graph]);

  return (
    <AnimatePresence mode="wait">
      {neuron && cluster && (
        <motion.div
          key={neuron.id}
          initial={{ opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 24 }}
          transition={{ duration: 0.25, ease: "easeOut" }}
          className="pointer-events-auto absolute right-3 top-3 z-30 flex max-h-[calc(100%-1.5rem)] w-[320px] flex-col gap-3 rounded-xl border border-white/10 bg-[#0a0718]/85 p-4 shadow-2xl backdrop-blur-xl"
        >
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div
                className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.18em]"
                style={{ color: cluster.color }}
              >
                <span
                  className="inline-block h-2 w-2 rounded-full"
                  style={{ background: cluster.color, boxShadow: `0 0 10px ${cluster.color}` }}
                />
                {cluster.label}
              </div>
              <div className="mt-1 truncate text-sm font-medium text-white">
                {neuron.name}
              </div>
              <div className="mt-0.5 truncate font-mono text-[11px] text-white/45">
                {neuron.path}
              </div>
            </div>
            <button
              onClick={onClose}
              className="rounded-md p-1 text-white/50 transition hover:bg-white/10 hover:text-white"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <Stat label="LOC" value={neuron.loc} icon={<Code2 className="h-3 w-3" />} />
            <Stat label="Imports" value={outgoing.length} icon={<ArrowUpRight className="h-3 w-3" />} />
            <Stat label="Used by" value={incoming.length} icon={<ArrowDownLeft className="h-3 w-3" />} />
          </div>

          <Separator className="bg-white/10" />

          <div className="flex flex-wrap items-center gap-1.5">
            <Badge
              variant="outline"
              className="border-white/15 bg-white/5 text-[10px] font-medium text-white/70"
            >
              <Layers className="mr-1 h-3 w-3" />
              {neuron.kind}
            </Badge>
            <Badge
              variant="outline"
              className="border-white/15 bg-white/5 text-[10px] font-medium text-white/70"
            >
              <Hash className="mr-1 h-3 w-3" />
              {neuron.imports + neuron.importedBy} degree
            </Badge>
            {neuron.circular && (
              <Badge
                variant="outline"
                className="animate-pulse border-rose-400/40 bg-rose-400/10 text-[10px] font-medium text-rose-300"
                title="This file participates in a circular import chain"
              >
                <AlertTriangle className="mr-1 h-3 w-3" />
                circular
              </Badge>
            )}
            {neuron.lastCommit && (
              <Badge
                variant="outline"
                className="border-white/15 bg-white/5 text-[10px] font-medium text-white/70"
                title="Last git commit touching this file"
              >
                <GitCommit className="mr-1 h-3 w-3" />
                {formatRelative(neuron.lastCommit)}
              </Badge>
            )}
            {preview.data && (
              <Badge
                variant="outline"
                className="border-white/15 bg-white/5 text-[10px] font-medium text-white/70"
                title="Last modified on disk"
              >
                <Clock className="mr-1 h-3 w-3" />
                {formatRelative(preview.data.mtime)}
              </Badge>
            )}
          </div>

          {neuron && (
            <CodePreview path={neuron.path} preview={preview} />
          )}

          <div className="min-h-0 flex-1 overflow-hidden">
            <Section title="Outgoing synapses" count={outgoing.length} icon={<ArrowUpRight className="h-3 w-3" />}>
              <ScrollArea className="max-h-32">
                <ul className="space-y-1 pr-2">
                  {outgoing.map((n) => (
                    <li key={n.id}>
                      <button
                        onClick={() => onSelectNeuron(n)}
                        className="flex w-full items-center gap-2 truncate rounded-md px-2 py-1 text-left text-[11px] text-white/70 transition hover:bg-white/10 hover:text-white"
                      >
                        <FileCode2 className="h-3 w-3 shrink-0 text-white/40" />
                        <span className="truncate">{n.name}</span>
                        <span className="ml-auto truncate font-mono text-[10px] text-white/30">
                          {n.path}
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              </ScrollArea>
            </Section>

            <Section title="Incoming synapses" count={incoming.length} icon={<ArrowDownLeft className="h-3 w-3" />}>
              <ScrollArea className="max-h-32">
                <ul className="space-y-1 pr-2">
                  {incoming.map((n) => (
                    <li key={n.id}>
                      <button
                        onClick={() => onSelectNeuron(n)}
                        className="flex w-full items-center gap-2 truncate rounded-md px-2 py-1 text-left text-[11px] text-white/70 transition hover:bg-white/10 hover:text-white"
                      >
                        <FileCode2 className="h-3 w-3 shrink-0 text-white/40" />
                        <span className="truncate">{n.name}</span>
                        <span className="ml-auto truncate font-mono text-[10px] text-white/30">
                          {n.path}
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              </ScrollArea>
            </Section>
          </div>

          <div className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-[10px] text-white/45">
            <Activity className="h-3 w-3" style={{ color: cluster.color }} />
            <span className="truncate">
              {cluster.anatomy}
            </span>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Stat({
  label,
  value,
  icon,
}: {
  label: string;
  value: number;
  icon: React.ReactNode;
}) {
  return (
    <div className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5">
      <div className="flex items-center gap-1 text-[9px] uppercase tracking-wider text-white/40">
        {icon}
        {label}
      </div>
      <div className="mt-0.5 font-mono text-base font-semibold text-white tabular-nums">
        {value}
      </div>
    </div>
  );
}

function Section({
  title,
  count,
  icon,
  children,
}: {
  title: string;
  count: number;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="mb-2">
      <div className="mb-1 flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wider text-white/45">
        {icon}
        {title}
        <span className="rounded-full bg-white/10 px-1.5 py-px font-mono text-[9px] text-white/60">
          {count}
        </span>
      </div>
      {count === 0 ? (
        <p className="px-2 text-[11px] italic text-white/30">no connections</p>
      ) : (
        children
      )}
    </div>
  );
}

function formatRelative(iso: string): string {
  const then = new Date(iso).getTime();
  if (!Number.isFinite(then)) return "—";
  const diff = Date.now() - then;
  const sec = Math.floor(diff / 1000);
  if (sec < 60) return `${sec}s ago`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.floor(hr / 24);
  if (day < 30) return `${day}d ago`;
  const mo = Math.floor(day / 30);
  if (mo < 12) return `${mo}mo ago`;
  return `${Math.floor(mo / 12)}y ago`;
}
