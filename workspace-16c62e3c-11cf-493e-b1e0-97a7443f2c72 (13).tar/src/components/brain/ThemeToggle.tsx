"use client";

import { useState } from "react";
import { Moon, Sun } from "lucide-react";

const THEME_KEY = "codebase-brain:theme:v1";

/**
 * A theme switcher that toggles between dark (default) and light mode.
 * In dark mode, the app uses its native dark palette. In light mode, a
 * `light` class is added to the <html> element, which activates CSS
 * overrides in globals.css that switch the background to a light palette.
 * The choice is persisted in localStorage.
 */
export default function ThemeToggle() {
  // Use lazy initializer to read localStorage on first client render
  const [isLight, setIsLight] = useState(() => {
    if (typeof window === "undefined") return false;
    try {
      return window.localStorage.getItem(THEME_KEY) === "light";
    } catch {
      return false;
    }
  });

  // Apply the class on mount + when toggled (side effect, not state)
  if (typeof window !== "undefined") {
    if (isLight) {
      document.documentElement.classList.add("light");
      document.documentElement.classList.remove("dark");
    } else {
      document.documentElement.classList.remove("light");
      document.documentElement.classList.add("dark");
    }
  }

  const toggle = () => {
    const next = !isLight;
    setIsLight(next);
    try {
      window.localStorage.setItem(THEME_KEY, next ? "light" : "dark");
    } catch {
      // ignore
    }
    if (next) {
      document.documentElement.classList.add("light");
      document.documentElement.classList.remove("dark");
    } else {
      document.documentElement.classList.remove("light");
      document.documentElement.classList.add("dark");
    }
  };

  return (
    <button
      onClick={toggle}
      className="pointer-events-auto flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-medium text-white/50 transition hover:bg-white/10 hover:text-white"
      title={isLight ? "Switch to dark mode" : "Switch to light mode"}
      aria-label="Toggle theme"
    >
      {isLight ? <Moon className="h-3.5 w-3.5" /> : <Sun className="h-3.5 w-3.5" />}
      <span className="hidden sm:inline">{isLight ? "Dark" : "Light"}</span>
    </button>
  );
}
