"use client";

import { motion } from "framer-motion";
import { BrainCircuit, ChevronRight, Home, X } from "lucide-react";
import type { Cluster } from "./types";

interface BrainHeaderProps {
  lastScan: number;
  /** currently focused cluster (when user drilled into one) */
  focusCluster?: Cluster | null;
  onExitFocus?: () => void;
}

export default function BrainHeader({
  lastScan,
  focusCluster,
  onExitFocus,
}: BrainHeaderProps) {
  return (
    <motion.header
      initial={{ opacity: 0, y: -12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className="pointer-events-none absolute left-1/2 top-3 z-30 -translate-x-1/2"
    >
      <div className="pointer-events-auto flex items-center gap-2 rounded-full border border-white/10 bg-[#0a0718]/80 px-3 py-1.5 shadow-2xl backdrop-blur-xl">
        <BrainCircuit className="h-4 w-4 text-violet-300" />
        {/* Breadcrumb */}
        <button
          onClick={onExitFocus}
          className="flex items-center gap-1 text-[11px] font-medium text-white/70 transition hover:text-white"
          title="Back to whole brain"
        >
          <Home className="h-3 w-3" />
          <span className="hidden sm:inline">Codebase Brain</span>
          <span className="sm:hidden">Brain</span>
        </button>
        {focusCluster && (
          <>
            <ChevronRight className="h-3 w-3 text-white/30" />
            <button
              onClick={onExitFocus}
              className="group flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium transition"
              style={{
                background: `${focusCluster.color}22`,
                color: focusCluster.color,
              }}
              title="Exit cluster focus"
            >
              <span
                className="inline-block h-1.5 w-1.5 rounded-full"
                style={{ background: focusCluster.color, boxShadow: `0 0 6px ${focusCluster.color}` }}
              />
              {focusCluster.label}
              <X className="h-3 w-3 opacity-50 transition group-hover:opacity-100" />
            </button>
          </>
        )}
        <span className="mx-1 hidden text-[10px] text-white/40 sm:block">
          · neural clusters mapped to your repository
        </span>
        <span className="ml-1 hidden items-center gap-1 rounded-full bg-emerald-400/10 px-2 py-0.5 text-[9px] font-medium text-emerald-300 sm:flex">
          <span className="relative flex h-1.5 w-1.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400/70" />
            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-400" />
          </span>
          live · {lastScan}s ago
        </span>
      </div>
    </motion.header>
  );
}
