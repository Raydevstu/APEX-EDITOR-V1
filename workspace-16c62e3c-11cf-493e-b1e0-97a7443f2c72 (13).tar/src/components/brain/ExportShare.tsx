"use client";

import { useState } from "react";
import { Download, Share2, Check, Loader2, Clock, Grid3x3 } from "lucide-react";
import { toast } from "sonner";
import ThemeToggle from "./ThemeToggle";

interface ExportShareProps {
  /** path of the currently selected neuron (for share-link), or null */
  selectedPath: string | null;
  /** whether the recently-changed panel is open */
  showRecent: boolean;
  onToggleRecent: () => void;
  /** whether the dependency matrix is open */
  showMatrix: boolean;
  onToggleMatrix: () => void;
}

/**
 * A compact toolbar (top-right corner) with Export-PNG and Share-Link buttons.
 * Export grabs the current canvas as a PNG download. Share copies a URL with
 * `?n=<path>` that auto-selects the neuron on load.
 */
export default function ExportShare({ selectedPath, showRecent, onToggleRecent, showMatrix, onToggleMatrix }: ExportShareProps) {
  const [exporting, setExporting] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleExport = async () => {
    const canvas = document.querySelector("canvas");
    if (!canvas) {
      toast.error("Canvas not ready");
      return;
    }
    setExporting(true);
    try {
      // composite over a dark background so transparent areas don't look ugly
      const out = document.createElement("canvas");
      out.width = canvas.width;
      out.height = canvas.height;
      const ctx = out.getContext("2d");
      if (!ctx) throw new Error("no 2d context");
      ctx.fillStyle = "#02010a";
      ctx.fillRect(0, 0, out.width, out.height);
      ctx.drawImage(canvas, 0, 0);
      const blob = await new Promise<Blob | null>((resolve) =>
        out.toBlob((b) => resolve(b), "image/png")
      );
      if (!blob) throw new Error("toBlob failed");
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `codebase-brain-${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success("Exported PNG", { description: `${out.width}×${out.height} screenshot saved` });
    } catch (e) {
      toast.error("Export failed", { description: e instanceof Error ? e.message : "unknown error" });
    } finally {
      setExporting(false);
    }
  };

  const handleShare = async () => {
    if (!selectedPath) {
      toast.error("Select a neuron first", { description: "Click a neuron, then share its link" });
      return;
    }
    const url = new URL(window.location.href);
    url.searchParams.set("n", selectedPath);
    url.hash = "";
    const link = url.toString();
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
      toast.success("Share link copied", { description: selectedPath });
    } catch {
      // fallback: select the URL bar
      window.history.replaceState(null, "", link);
      toast.info("Share link set in URL bar", { description: "Copy from the address bar" });
    }
  };

  return (
    <div className="pointer-events-auto absolute right-3 top-3 z-30 flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#0a0718]/85 p-1 shadow-2xl backdrop-blur-xl">
      <button
        onClick={handleExport}
        disabled={exporting}
        className="flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-medium text-white/70 transition hover:bg-white/10 hover:text-white disabled:opacity-50"
        title="Export the current brain view as a PNG"
      >
        {exporting ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin" />
        ) : (
          <Download className="h-3.5 w-3.5" />
        )}
        <span className="hidden sm:inline">Export</span>
      </button>
      <button
        onClick={handleShare}
        className="flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-medium text-white/70 transition hover:bg-white/10 hover:text-white"
        title={selectedPath ? `Copy share link to ${selectedPath}` : "Select a neuron to share"}
      >
        {copied ? (
          <Check className="h-3.5 w-3.5 text-emerald-400" />
        ) : (
          <Share2 className="h-3.5 w-3.5" />
        )}
        <span className="hidden sm:inline">Share</span>
      </button>
      <div className="mx-0.5 h-4 w-px bg-white/10" />
      <button
        onClick={onToggleRecent}
        className={`flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-medium transition ${
          showRecent
            ? "bg-amber-400/15 text-amber-300"
            : "text-white/70 hover:bg-white/10 hover:text-white"
        }`}
        title="Toggle recently-changed files panel"
      >
        <Clock className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">Recent</span>
      </button>
      <button
        onClick={onToggleMatrix}
        className={`flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-medium transition ${
          showMatrix
            ? "bg-violet-400/15 text-violet-300"
            : "text-white/70 hover:bg-white/10 hover:text-white"
        }`}
        title="Toggle cluster dependency matrix"
      >
        <Grid3x3 className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">Matrix</span>
      </button>
      <div className="mx-0.5 h-4 w-px bg-white/10" />
      <ThemeToggle />
    </div>
  );
}
