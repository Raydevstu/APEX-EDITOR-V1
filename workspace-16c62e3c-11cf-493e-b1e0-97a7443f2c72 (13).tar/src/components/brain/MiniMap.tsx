"use client";

import { useEffect, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MapIcon } from "lucide-react";
import type { CameraState, Cluster, NeuralGraph } from "./types";
import { computeLayout } from "@/lib/brain/layout";

interface MiniMapProps {
  graph: NeuralGraph;
  visibleClusters: Set<string>;
  camera: CameraState;
  /** when true the mini-map is shown (e.g. when zoomed/panned) */
  active: boolean;
  onReset?: () => void;
}

const MAP_W = 168;
const MAP_H = 120;

/**
 * A small overview mini-map shown in the bottom-right corner when the user has
 * zoomed or panned away from the default view. Renders a scaled-down version of
 * the whole brain (clusters + neuron dots) and a viewport rectangle indicating
 * the currently visible region. Clicking it resets the camera.
 */
export default function MiniMap({
  graph,
  visibleClusters,
  camera,
  active,
  onReset,
}: MiniMapProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // mini-map uses its own fixed-size layout so it's stable regardless of the
  // main canvas size
  const layout = useMemo(
    () => computeLayout(graph, MAP_W, MAP_H),
    [graph]
  );

  const clusterMap = useMemo(() => {
    const m = new Map<string, Cluster>();
    for (const c of graph.clusters) m.set(c.id, c);
    return m;
  }, [graph.clusters]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = MAP_W * dpr;
    canvas.height = MAP_H * dpr;
    canvas.style.width = MAP_W + "px";
    canvas.style.height = MAP_H + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // clear
    ctx.clearRect(0, 0, MAP_W, MAP_H);
    // bg
    ctx.fillStyle = "rgba(8,5,24,0.85)";
    ctx.fillRect(0, 0, MAP_W, MAP_H);

    // clusters as filled blobs
    for (const c of graph.clusters) {
      const center = layout.centers[c.id];
      if (!center) continue;
      if (!visibleClusters.has(c.id)) continue;
      const r = center.r * 0.55;
      const g = ctx.createRadialGradient(center.x, center.y, 0, center.x, center.y, r);
      g.addColorStop(0, hexA(c.color, 0.55));
      g.addColorStop(1, hexA(c.color, 0));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(center.x, center.y, r, 0, Math.PI * 2);
      ctx.fill();
    }
    // neurons as tiny dots
    for (let i = 0; i < layout.neurons.length; i++) {
      const n = layout.neurons[i];
      if (!n) continue;
      const neuron = graph.neurons[i];
      if (!neuron || neuron.kind === "virtual") continue;
      if (!visibleClusters.has(neuron.cluster)) continue;
      const color = clusterMap.get(neuron.cluster)?.color ?? "#a855f7";
      ctx.fillStyle = hexA(color, 0.7);
      ctx.beginPath();
      ctx.arc(n.x, n.y, 0.8, 0, Math.PI * 2);
      ctx.fill();
    }

    // viewport rectangle: compute the visible world-region from camera state
    // The main canvas centers world (W/2, H/2) at screen (W/2 + panX, H/2 + panY)
    // and applies zoom. So a world point (wx, wy) maps to screen:
    //   sx = (wx - W/2) * zoom + W/2 + panX
    // We want the inverse for the mini-map: which world region is visible?
    // Since the mini-map is a scaled version (MAP_W x MAP_H instead of main W x H),
    // we approximate by treating the main canvas as MAP_W x MAP_H too.
    const z = camera.zoom;
    // visible world width / height (in mini-map coords)
    const visW = MAP_W / z;
    const visH = MAP_H / z;
    // panX moves the world; positive panX = world shifted right
    // visible world center in mini-map coords:
    const cx = MAP_W / 2 - camera.panX / z;
    const cy = MAP_H / 2 - camera.panY / z;
    const vx = cx - visW / 2;
    const vy = cy - visH / 2;

    // clip to map bounds
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, MAP_W, MAP_H);
    ctx.clip();
    // viewport rect
    ctx.strokeStyle = "rgba(255,255,255,0.85)";
    ctx.lineWidth = 1;
    ctx.strokeRect(vx, vy, visW, visH);
    ctx.fillStyle = "rgba(255,255,255,0.06)";
    ctx.fillRect(vx, vy, visW, visH);
    ctx.restore();

    // border
    ctx.strokeStyle = "rgba(255,255,255,0.1)";
    ctx.lineWidth = 1;
    ctx.strokeRect(0.5, 0.5, MAP_W - 1, MAP_H - 1);
  }, [graph, layout, clusterMap, visibleClusters, camera]);

  return (
    <AnimatePresence>
      {active && (
        <motion.button
          initial={{ opacity: 0, scale: 0.9, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 10 }}
          transition={{ duration: 0.2 }}
          onClick={onReset}
          title="Click to reset view"
          className="pointer-events-auto absolute bottom-3 right-3 z-30 group flex flex-col gap-1 rounded-lg border border-white/10 bg-[#0a0718]/85 p-2 shadow-2xl backdrop-blur-xl hover:border-white/25 transition"
        >
          <canvas ref={canvasRef} className="block rounded" />
          <div className="flex items-center justify-between gap-2 px-0.5">
            <div className="flex items-center gap-1 text-[9px] uppercase tracking-wider text-white/50">
              <MapIcon className="h-2.5 w-2.5" />
              minimap
            </div>
            <span className="text-[9px] font-medium text-violet-300 opacity-0 transition group-hover:opacity-100">
              reset
            </span>
          </div>
        </motion.button>
      )}
    </AnimatePresence>
  );
}

function hexA(hex: string, alpha: number): string {
  if (hex.startsWith("rgba") || hex.startsWith("rgb")) return hex;
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}
