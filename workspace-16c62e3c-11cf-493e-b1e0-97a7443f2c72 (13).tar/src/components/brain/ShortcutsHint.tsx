"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Keyboard, X, Sparkles } from "lucide-react";

// No props needed — the component is self-contained. The actual shortcut
// handling lives in page.tsx; this component only documents them.

const SHORTCUTS: { key: string; label: string }[] = [
  { key: "/", label: "Search neurons" },
  { key: "↑↓←→", label: "Navigate between connected neurons" },
  { key: "R", label: "Reset view" },
  { key: "F", label: "Toggle firing" },
  { key: "S", label: "Toggle synapses" },
  { key: "L", label: "Toggle labels" },
  { key: "P", label: "Toggle parallax" },
  { key: "G", label: "Toggle git heat" },
  { key: "O", label: "Toggle orbital nodes" },
  { key: "V", label: "Toggle region flow" },
  { key: "M", label: "Toggle dependency matrix" },
  { key: "Shift+Click", label: "Path finder (2 neurons)" },
  { key: "Right-Click", label: "Radial menu" },
  { key: "Esc", label: "Deselect / exit focus" },
];

export default function ShortcutsHint() {
  const [open, setOpen] = useState(false);

  // Close the dialog on Escape (stopImmediatePropagation so the page-level
  // shortcut handler doesn't also fire and exit the cluster focus).
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopImmediatePropagation();
        setOpen(false);
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [open]);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="pointer-events-auto absolute bottom-3 left-3 z-30 flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#0a0718]/85 px-2.5 py-1.5 text-[10px] font-medium text-white/60 shadow-2xl backdrop-blur-xl transition hover:border-white/25 hover:text-white"
        title="Keyboard shortcuts"
      >
        <Keyboard className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">Shortcuts</span>
        <kbd className="hidden rounded bg-white/10 px-1 py-px font-mono text-[9px] text-white/70 sm:inline">/</kbd>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 z-40 flex items-center justify-center bg-black/60 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.92, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.92, y: 10 }}
              transition={{ duration: 0.2 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-[340px] rounded-2xl border border-white/15 bg-[#0a0718]/95 p-5 shadow-2xl"
            >
              <button
                onClick={() => setOpen(false)}
                className="absolute right-3 top-3 rounded-md p-1 text-white/40 transition hover:bg-white/10 hover:text-white"
                aria-label="Close"
              >
                <X className="h-4 w-4" />
              </button>
              <div className="flex items-center gap-2 text-sm font-semibold text-white">
                <Keyboard className="h-4 w-4 text-violet-300" />
                Keyboard Shortcuts
              </div>
              <p className="mt-1 text-[11px] text-white/45">
                Navigate the living brain with your keyboard.
              </p>
              <ul className="mt-4 space-y-1.5">
                {SHORTCUTS.map((s) => (
                  <li
                    key={s.key}
                    className="flex items-center justify-between rounded-md px-2 py-1.5 transition hover:bg-white/5"
                  >
                    <span className="text-[12px] text-white/75">{s.label}</span>
                    <kbd className="rounded border border-white/15 bg-white/5 px-2 py-0.5 font-mono text-[10px] font-semibold text-white shadow-[0_2px_0_rgba(0,0,0,0.4)]">
                      {s.key}
                    </kbd>
                  </li>
                ))}
              </ul>
              <div className="mt-4 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-[10px] text-white/50">
                Tip: hover a neuron to fire its synapses · click a cluster to focus it · scroll to zoom · drag empty space to pan · click a matrix header to isolate a cluster · shift-click two neurons to find their import path.
              </div>
              <button
                onClick={() => {
                  window.dispatchEvent(new Event("codebase-brain:replay-tour"));
                  setOpen(false);
                }}
                className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-lg border border-violet-400/30 bg-violet-400/10 px-3 py-2 text-[11px] font-medium text-violet-300 transition hover:bg-violet-400/20"
              >
                <Sparkles className="h-3.5 w-3.5" />
                Replay onboarding tour
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
