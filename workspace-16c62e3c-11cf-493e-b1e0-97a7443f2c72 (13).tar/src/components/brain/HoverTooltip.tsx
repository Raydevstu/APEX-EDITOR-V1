"use client";

import { AnimatePresence, motion } from "framer-motion";
import type { Cluster, Neuron } from "./types";

interface HoverTooltipProps {
  neuron: Neuron | null;
  cluster?: Cluster;
  x: number;
  y: number;
}

export default function HoverTooltip({ neuron, cluster, x, y }: HoverTooltipProps) {
  return (
    <AnimatePresence>
      {neuron && (
        <motion.div
          key={neuron.id + (cluster?.id ?? "")}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          transition={{ duration: 0.12 }}
          className="pointer-events-none absolute z-40 max-w-[260px] rounded-lg border border-white/15 bg-[#0a0718]/95 px-2.5 py-1.5 shadow-xl backdrop-blur-md"
          style={{
            left: Math.min(x + 14, /* will be clamped by parent */ x),
            top: Math.max(8, y - 56),
            transform: "translateZ(0)",
          }}
        >
          <div className="flex items-center gap-1.5">
            <span
              className="inline-block h-1.5 w-1.5 rounded-full"
              style={{ background: cluster?.color ?? "#a855f7", boxShadow: `0 0 6px ${cluster?.color}` }}
            />
            <span className="text-[11px] font-medium text-white">{neuron.name}</span>
          </div>
          <div className="mt-0.5 truncate font-mono text-[10px] text-white/45">
            {neuron.path}
          </div>
          <div className="mt-1 flex items-center gap-2 text-[9px] uppercase tracking-wider text-white/40">
            <span>{neuron.loc} LOC</span>
            <span className="text-white/15">•</span>
            <span style={{ color: cluster?.color }}>{cluster?.label}</span>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
