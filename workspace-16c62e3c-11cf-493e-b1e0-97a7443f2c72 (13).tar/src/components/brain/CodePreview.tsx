"use client";

import { useMemo, useState } from "react";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { oneDark } from "react-syntax-highlighter/dist/esm/styles/prism";
import {
  ChevronDown,
  ChevronRight,
  Copy,
  FileText,
  Loader2,
  AlertTriangle,
} from "lucide-react";
import type { FilePreview } from "@/hooks/use-file-preview";

interface CodePreviewProps {
  path: string;
  preview: {
    data: FilePreview | null;
    loading: boolean;
    error: string | null;
  };
}

/**
 * A collapsible, syntax-highlighted preview of the first ~200 lines of the
 * selected neuron's file. Shown inside the InfoPanel.
 */
export default function CodePreview({ path, preview }: CodePreviewProps) {
  const [open, setOpen] = useState(true);
  const [copied, setCopied] = useState(false);

  const lang = useMemo(() => {
    if (!preview.data) {
      // best-effort guess from extension
      const p = path.toLowerCase();
      if (p.endsWith(".tsx")) return "tsx";
      if (p.endsWith(".ts")) return "ts";
      if (p.endsWith(".prisma")) return "graphql";
      if (p.endsWith(".json")) return "json";
      return "text";
    }
    return preview.data.language;
  }, [preview.data, path]);

  const handleCopy = async () => {
    if (!preview.data) return;
    try {
      await navigator.clipboard.writeText(preview.data.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // ignore
    }
  };

  return (
    <div className="rounded-lg border border-white/10 bg-black/30">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center gap-1.5 px-2.5 py-1.5 text-left transition hover:bg-white/5"
      >
        {open ? (
          <ChevronDown className="h-3.5 w-3.5 text-white/50" />
        ) : (
          <ChevronRight className="h-3.5 w-3.5 text-white/50" />
        )}
        <FileText className="h-3.5 w-3.5 text-white/50" />
        <span className="text-[10px] font-medium uppercase tracking-wider text-white/60">
          Code Preview
        </span>
        {preview.data && (
          <span className="ml-auto flex items-center gap-1.5 font-mono text-[9px] text-white/40">
            <span>{preview.data.lines}/{preview.data.totalLines} lines</span>
            {preview.data.truncated && (
              <span className="text-amber-300/70" title="truncated to 64KB">
                ⌧
              </span>
            )}
          </span>
        )}
      </button>

      {open && (
        <div className="relative border-t border-white/10">
          {preview.loading && (
            <div className="flex items-center justify-center gap-2 py-6 text-[11px] text-white/40">
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
              loading…
            </div>
          )}
          {preview.error && !preview.loading && (
            <div className="flex items-center gap-1.5 px-3 py-2 text-[11px] text-amber-300/80">
              <AlertTriangle className="h-3.5 w-3.5" />
              {preview.error}
            </div>
          )}
          {preview.data && !preview.loading && (
            <>
              {preview.data.content && (
                <button
                  onClick={handleCopy}
                  className="absolute right-2 top-2 z-10 rounded border border-white/10 bg-white/5 p-1 text-white/50 transition hover:bg-white/10 hover:text-white"
                  title="Copy code"
                  aria-label="Copy code"
                >
                  <Copy className="h-3 w-3" />
                </button>
              )}
              <div className="max-h-64 overflow-auto px-1 py-1 text-[10px] leading-relaxed">
                {preview.data.content ? (
                  <SyntaxHighlighter
                    language={lang}
                    style={oneDark}
                    customStyle={{
                      margin: 0,
                      background: "transparent",
                      padding: "8px 10px",
                      fontSize: "10px",
                      lineHeight: 1.5,
                    }}
                    codeTagProps={{
                      style: { fontFamily: "var(--font-geist-mono), monospace" },
                    }}
                    showLineNumbers
                    lineNumberStyle={{
                      color: "rgba(255,255,255,0.25)",
                      paddingRight: "8px",
                      minWidth: "2.5em",
                      userSelect: "none",
                    }}
                    wrapLongLines={false}
                  >
                    {preview.data.content}
                  </SyntaxHighlighter>
                ) : (
                  <div className="px-3 py-2 text-[11px] italic text-white/30">
                    empty file
                  </div>
                )}
                {copied && (
                  <div className="absolute bottom-2 right-2 rounded border border-emerald-400/30 bg-emerald-400/10 px-2 py-0.5 text-[9px] font-medium text-emerald-300">
                    copied!
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
